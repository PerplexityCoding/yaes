import { s as storageGet, g as getAndAssembleConfig, m as mergeOptionsDefault, d as mergeOptionsInEnv, I as INIT_DEFAULT_CONFIG } from "./utils-d4ff6b88.js";
async function getConfig({ mergeOptions, mergeDefault } = { mergeOptions: true, mergeDefault: true }) {
  let errors = {};
  let values = await storageGet(null);
  let config = await getAndAssembleConfig(values);
  if (config != null) {
    if (mergeDefault) {
      config = mergeOptionsDefault(config);
    }
    if (mergeOptions) {
      config = mergeOptionsInEnv(config);
    }
  } else {
    config = { ...INIT_DEFAULT_CONFIG };
  }
  return {
    config,
    errors
  };
}
function equalsEnv(env1, env2) {
  if (!env1 || !env2) {
    return false;
  }
  return env1.id === env2.id;
}
function hostnameFromEnv(env) {
  return new URL(env.url).hostname;
}
function isValidEnv(env) {
  return env && (env.name != null || env.shortName != null) && env.id != null;
}
function switchBaseUrl(currentUrl, newBaseUrl, { appendUrlParams, removeUrlParams }) {
  const baseUrl = new URL(newBaseUrl);
  const url = new URL(currentUrl);
  url.hostname = baseUrl.hostname;
  url.protocol = baseUrl.protocol;
  const searchParams = url.searchParams;
  if (appendUrlParams) {
    const newSearchParams = new URLSearchParams(appendUrlParams);
    newSearchParams.forEach(function(value, key) {
      searchParams.set(key, value);
    });
  }
  if (removeUrlParams) {
    const removeUrlParamsList = removeUrlParams.split(",");
    removeUrlParamsList.forEach((key) => {
      searchParams.delete(key.trim());
    });
  }
  return url.href;
}
function getCurrentEnv(url, config) {
  if (!config) {
    return;
  }
  if (url == null || !url.match(/^https?:\/\//)) {
    return null;
  }
  const envsByDomains = getEnvsByDomain(config);
  const currentUrl = new URL(url);
  const currentHostname = currentUrl.hostname;
  const currentSearchParams = currentUrl.searchParams;
  for (const [domain, domainEnvs] of Object.entries(envsByDomains)) {
    if (domain === currentHostname) {
      let mostMatchingEnv = { env: null, count: -100 };
      for (const env of domainEnvs) {
        let count = 0;
        if (env.appendUrlParams) {
          const params = new URLSearchParams(env.appendUrlParams);
          for (const [key, value] of params) {
            if (currentSearchParams.get(key) === value) {
              count += 100;
            }
            count--;
          }
        }
        if (count > mostMatchingEnv.count) {
          mostMatchingEnv = { env, count };
        }
      }
      return mostMatchingEnv.env;
    }
  }
  return null;
}
function getEnvsByDomain(config) {
  const envs = config.envs;
  return envs.reduce((result, env) => {
    const envHostname = hostnameFromEnv(env);
    result[envHostname] = result[envHostname] || [];
    result[envHostname].push(env);
    return result;
  }, {});
}
export {
  getCurrentEnv as a,
  equalsEnv as e,
  getConfig as g,
  hostnameFromEnv as h,
  isValidEnv as i,
  switchBaseUrl as s
};
//# sourceMappingURL=index-bd0333f7.js.map
