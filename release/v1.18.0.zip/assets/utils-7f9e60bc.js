function downloadAsJson(obj) {
  const data = "text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(obj, null, 2));
  const a = document.createElement("a");
  a.href = "data:" + data;
  a.download = "yeas-config.json";
  a.innerHTML = "download JSON";
  window.document.body.appendChild(a);
  a.click();
  a.remove();
}
function updateArray(arr, findIndex, cb) {
  const index = findIndex(arr);
  if (index >= 0) {
    return [...arr.slice(0, index), cb(arr[index]), ...arr.slice(index + 1)].filter(
      (el) => el != null
    );
  }
  return arr;
}
function removeUndefined(o) {
  Object.keys(o).forEach((key) => {
    if (o[key] === void 0) {
      delete o[key];
    }
  });
  return o;
}
function arrayValidator(fn) {
  return (a) => {
    return a.reduce((acc, o) => acc && fn(o), true);
  };
}
function uuidv4() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
}
function removeEmptyString(obj) {
  for (const [key, value] of Object.entries(obj)) {
    if (value === "") {
      delete obj[key];
    }
  }
  return obj;
}
export {
  removeUndefined as a,
  updateArray as b,
  arrayValidator as c,
  downloadAsJson as d,
  removeEmptyString as r,
  uuidv4 as u
};
//# sourceMappingURL=utils-7f9e60bc.js.map
