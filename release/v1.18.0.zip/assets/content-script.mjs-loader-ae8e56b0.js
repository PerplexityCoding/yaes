(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.mjs-c3fca84f.js")
    );
  })().catch(console.error);

})();
