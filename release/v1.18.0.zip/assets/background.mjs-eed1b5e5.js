import { g as getTab } from "./tabs-05aa9e80.js";
import { m as migrate, a as autoUpdate } from "./index-c2ffbe1b.js";
import { i as init } from "./sdk-506647be.js";
import { g as getConfig, a as getCurrentEnv } from "./index-bd0333f7.js";
import "./utils-d4ff6b88.js";
import "./utils-7f9e60bc.js";
function setBadgeBackgroundColor(tabId, color) {
  return (chrome.action || chrome.browserAction).setBadgeBackgroundColor({
    tabId,
    color
  });
}
function setBadgeText(tabId, text) {
  (chrome.action || chrome.browserAction).setBadgeText({
    tabId,
    text
  });
}
function updateBadgeTextFromEnv(tabId, env) {
  if (env != null && env.displayBadge !== false) {
    const color = env.badgeOptions.backgroundColor;
    setBadgeBackgroundColor(tabId, color);
    const text = (env.shortName || env.name).substring(0, 4) || "";
    setBadgeText(tabId, text);
    return;
  }
  clearBadgeText(tabId);
}
function clearBadgeText(tabId) {
  setBadgeText(tabId, "");
}
function initSentry() {
  if (typeof { "release": "yaes@1.18.0" } !== "undefined") {
    const { release } = { "release": "yaes@1.18.0" };
    init({
      dsn: "https://33de24a53cff42ae88eb254afcb71175@o475103.ingest.sentry.io/5512649",
      integrations: [],
      release,
      environment: "production",
      // We recommend adjusting this value in production, or using tracesSampler
      // for finer control
      tracesSampleRate: 1,
      ignoreErrors: [
        "TypeError: Failed to fetch",
        "TypeError: NetworkError when attempting to fetch resource."
      ]
    });
  }
}
function main() {
  initSentry();
  chrome.runtime.onInstalled.addListener(() => {
    onTabsActivatedUpdateBadge();
  });
  chrome.runtime.onUpdateAvailable.addListener(() => {
    chrome.runtime.reload();
  });
  onTabsActivatedUpdateBadge();
  updateConfig();
}
function onTabsActivatedUpdateBadge() {
  chrome.tabs.onActivated.addListener(async (activeInfo) => {
    updateTab(activeInfo.tabId);
  });
  chrome.tabs.onUpdated.addListener(async (tabId) => {
    updateTab(tabId);
  });
}
async function updateTab(tabId) {
  const tab = await getTab(tabId);
  if (tab) {
    const { config } = await getConfig();
    const env = getCurrentEnv(tab.url, config);
    if (env) {
      updateBadgeTextFromEnv(tabId, env);
    }
  }
}
async function updateConfig() {
  const { config } = await migrate();
  await autoUpdate(config);
}
main();
//# sourceMappingURL=background.mjs-eed1b5e5.js.map
