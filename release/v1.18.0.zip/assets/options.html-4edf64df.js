import { d as defineComponent, _ as _export_sfc, c as createElementBlock, a as createBlock, r as resolveDynamicComponent, b as createCommentVNode, e as renderSlot, n as normalizeClass, o as openBlock, f as ref, g as computed, h as onMounted, w as withDirectives, v as vModelDynamic, i as createBaseVNode, j as resolveComponent, k as createVNode, l as withCtx, m as vModelSelect, p as vModelCheckbox, q as createTextVNode, s as pushScopeId, t as popScopeId, u as onBeforeUnmount, x as watch, y as normalizeStyle, T as Transition, z as toRef, A as h$1, B as unref, C as isRef, D as reactive, E as nextTick, F as watchEffect, G as inject, H as markRaw, I as provide, J as getCurrentInstance, K as toDisplayString, L as withModifiers, M as Fragment, N as renderList, O as vShow, P as isDarkMode, Q as ArrowRightIcon, R as loadSentry, S as createApp, U as queueVueGlobalErrorHandler } from "./ArrowRightIcon-ac76a36d.js";
import { i as importFromUrl, b as mergeImportedConfig, c as importConfig, g as getDefaultExportFromCjs, d as commonjsGlobal, e as getProjectEnvs, f as getProjectById, n as newEnv, h as addEnv, u as updateEnv, j as getEnvById, k as deleteEnv, l as newProject, o as addProject, p as deleteProject, q as updateProject, r as getFixConfig, s as setConfig$1 } from "./index-c2ffbe1b.js";
import { c as cjs, D as DEFAULT_OPTIONS } from "./utils-d4ff6b88.js";
import { r as removeEmptyString, a as removeUndefined, d as downloadAsJson } from "./utils-7f9e60bc.js";
const Button_vue_vue_type_style_index_0_scoped_7f04b228_lang = "";
const _sfc_main$l = defineComponent({
  name: "CoreButton",
  props: {
    iconName: {
      type: String,
      default: null
    },
    variation: {
      type: String,
      default: null,
      validator: (s2) => s2.indexOf("negative") >= 0 || s2.indexOf("positive") >= 0
    },
    elevation: {
      type: Boolean,
      default: false
    }
  },
  emits: ["click"]
});
function _sfc_render$l(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("button", {
    class: normalizeClass({ [_ctx.variation]: _ctx.variation, elevation: _ctx.elevation }),
    onClick: _cache[0] || (_cache[0] = (e2) => _ctx.$emit("click", e2))
  }, [
    _ctx.iconName ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.iconName), {
      key: 0,
      height: "18px",
      width: "18px"
    })) : createCommentVNode("", true),
    renderSlot(_ctx.$slots, "default", {}, void 0, true)
  ], 2);
}
const CoreButton = /* @__PURE__ */ _export_sfc(_sfc_main$l, [["render", _sfc_render$l], ["__scopeId", "data-v-7f04b228"]]);
const Input_vue_vue_type_style_index_0_scoped_fe297646_lang = "";
const _sfc_main$k = defineComponent({
  name: "CoreInput",
  props: {
    id: {
      type: String,
      required: true
    },
    type: {
      type: String,
      default: "text"
    },
    placeholder: {
      type: String,
      default: ""
    },
    modelValue: {
      type: String,
      required: true
    },
    focusOnMounted: {
      type: Boolean,
      default: false
    },
    maxlength: {
      type: Number,
      default: void 0
    }
  },
  emits: ["update:modelValue", "erase"],
  setup(props, context) {
    const input = ref(null);
    const localeValue = computed({
      get: () => props.modelValue,
      set: (val) => {
        context.emit("update:modelValue", val);
      }
    });
    const erase = () => {
      localeValue.value = "";
      context.emit("erase");
    };
    onMounted(() => {
      if (props.focusOnMounted) {
        const inputEl = input.value;
        if (inputEl) {
          inputEl.focus();
          inputEl.setSelectionRange(0, inputEl.length);
        }
      }
    });
    return {
      erase,
      localeValue,
      input
    };
  }
});
const _hoisted_1$k = { class: "core-input" };
const _hoisted_2$j = ["id", "type", "placeholder", "maxlength"];
function _sfc_render$k(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_DeleteIcon = resolveComponent("DeleteIcon");
  return openBlock(), createElementBlock("div", _hoisted_1$k, [
    withDirectives(createBaseVNode("input", {
      class: "input",
      ref: "input",
      id: _ctx.id,
      type: _ctx.type,
      placeholder: _ctx.placeholder,
      maxlength: _ctx.maxlength,
      "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => _ctx.localeValue = $event)
    }, null, 8, _hoisted_2$j), [
      [vModelDynamic, _ctx.localeValue]
    ]),
    _ctx.localeValue !== "" ? (openBlock(), createBlock(_component_DeleteIcon, {
      key: 0,
      class: "icon",
      height: "18px",
      width: "18px",
      onClick: _ctx.erase
    }, null, 8, ["onClick"])) : createCommentVNode("", true)
  ]);
}
const CoreInput = /* @__PURE__ */ _export_sfc(_sfc_main$k, [["render", _sfc_render$k], ["__scopeId", "data-v-fe297646"]]);
const ImportConfig_vue_vue_type_style_index_0_scoped_83904d79_lang = "";
const _sfc_main$j = defineComponent({
  name: "ImportConfig",
  props: {
    config: {
      type: Object,
      default: () => ({})
    },
    options: {
      type: Object,
      default: () => ({})
    }
  },
  components: { CoreButton, CoreInput },
  emits: ["config-loaded", "download-config", "update:options"],
  setup(props, context) {
    const mergedOptions = computed(() => {
      const options = cjs(cjs({}, DEFAULT_OPTIONS), props.options || {});
      return options;
    });
    const configurationUrl = ref(props.options.import ? props.options.import.url : "");
    const importUrlStatus = ref(null);
    const importFileStatus = ref(null);
    const importConfigLoader = ref(false);
    const mergeOptionsMode = ref(mergedOptions.value.import.mergeOptionsMode);
    const autoSync = ref(mergedOptions.value.import.sync);
    const importConfig$1 = async () => {
      if (configurationUrl.value) {
        resetErrors();
        importConfigLoader.value = true;
        const importedConfig = await importFromUrl(configurationUrl.value);
        if (importedConfig) {
          const config = mergeImportedConfig(importedConfig, props.config, mergeOptionsMode.value);
          config.options = config.options || {};
          config.options.import = {
            url: configurationUrl.value,
            mergeOptionsMode: mergeOptionsMode.value,
            sync: autoSync.value
          };
          context.emit("config-loaded", config);
        }
        importUrlStatus.value = !!importedConfig;
        importConfigLoader.value = false;
      }
    };
    const importFile = (e2) => {
      resetErrors();
      const file = e2.target.files[0];
      const reader = new FileReader();
      reader.readAsText(file, "UTF-8");
      reader.onload = async (event) => {
        const data = event.target.result;
        const config = await importConfig(data);
        if (config) {
          context.emit("config-loaded", config);
        }
        importFileStatus.value = !!config;
      };
      reader.onerror = () => {
        importFileStatus.value = false;
      };
    };
    const resetErrors = () => {
      importFileStatus.value = null;
      importUrlStatus.value = null;
    };
    const updateImportOptions = () => {
      setTimeout(() => {
        context.emit("update:options", {
          import: {
            url: configurationUrl.value,
            mergeOptionsMode: mergeOptionsMode.value,
            sync: autoSync.value
          }
        });
      }, 0);
    };
    const downloadConfig = () => {
      context.emit("download-config");
    };
    return {
      importFile,
      importConfig: importConfig$1,
      updateImportOptions,
      downloadConfig,
      configurationUrl,
      importUrlStatus,
      importFileStatus,
      importConfigLoader,
      mergeOptionsMode,
      autoSync
    };
  }
});
const _withScopeId$9 = (n2) => (pushScopeId("data-v-83904d79"), n2 = n2(), popScopeId(), n2);
const _hoisted_1$j = {
  class: "import-config-section box-elevation",
  "data-intro": "This is where you can import and export your configuration. You can export and share them for instance on gist."
};
const _hoisted_2$i = { class: "import-configuration" };
const _hoisted_3$i = /* @__PURE__ */ _withScopeId$9(() => /* @__PURE__ */ createBaseVNode("strong", { class: "import-title" }, " Import configuration ", -1));
const _hoisted_4$8 = { class: "import-methods" };
const _hoisted_5$6 = { class: "import-url-field" };
const _hoisted_6$5 = { class: "label-set" };
const _hoisted_7$5 = ["for"];
const _hoisted_8$5 = {
  key: 0,
  class: "import-failed-message"
};
const _hoisted_9$4 = {
  key: 1,
  class: "import-success-message"
};
const _hoisted_10$3 = {
  key: 2,
  class: "lds-dual-ring loader"
};
const _hoisted_11$3 = { class: "import-inline-options" };
const _hoisted_12$3 = ["for"];
const _hoisted_13$3 = ["id"];
const _hoisted_14$3 = /* @__PURE__ */ _withScopeId$9(() => /* @__PURE__ */ createBaseVNode("option", { value: "default" }, "Don't keep your options", -1));
const _hoisted_15$3 = /* @__PURE__ */ _withScopeId$9(() => /* @__PURE__ */ createBaseVNode("option", { value: "merge" }, "Merge your options", -1));
const _hoisted_16$3 = /* @__PURE__ */ _withScopeId$9(() => /* @__PURE__ */ createBaseVNode("option", { value: "keep" }, "Keep your options", -1));
const _hoisted_17$3 = [
  _hoisted_14$3,
  _hoisted_15$3,
  _hoisted_16$3
];
const _hoisted_18$2 = { class: "import-inline-options" };
const _hoisted_19$2 = ["for"];
const _hoisted_20$2 = ["id"];
const _hoisted_21$2 = { class: "label-set" };
const _hoisted_22$2 = ["for"];
const _hoisted_23$2 = ["id"];
const _hoisted_24$2 = {
  key: 0,
  class: "import-failed-message"
};
const _hoisted_25$2 = {
  key: 1,
  class: "import-success-message"
};
const _hoisted_26$2 = { class: "import-configuration" };
const _hoisted_27$2 = /* @__PURE__ */ _withScopeId$9(() => /* @__PURE__ */ createBaseVNode("strong", null, " Export configuration ", -1));
const _hoisted_28$2 = /* @__PURE__ */ _withScopeId$9(() => /* @__PURE__ */ createBaseVNode("span", null, "Tips:", -1));
const _hoisted_29$2 = /* @__PURE__ */ _withScopeId$9(() => /* @__PURE__ */ createBaseVNode("a", {
  href: "https://gist.github.com/",
  target: "_blank"
}, "Share it on gist", -1));
function _sfc_render$j(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_CoreInput = resolveComponent("CoreInput");
  const _component_CoreButton = resolveComponent("CoreButton");
  return openBlock(), createElementBlock("section", _hoisted_1$j, [
    createBaseVNode("div", _hoisted_2$i, [
      _hoisted_3$i,
      createBaseVNode("div", _hoisted_4$8, [
        createBaseVNode("div", null, [
          createBaseVNode("div", _hoisted_5$6, [
            createBaseVNode("div", _hoisted_6$5, [
              createBaseVNode("label", {
                for: _ctx.$id("import-url")
              }, " Using Url ", 8, _hoisted_7$5),
              createVNode(_component_CoreInput, {
                class: "url-input",
                id: _ctx.$id("import-url"),
                type: "url",
                placeholder: "https://gist.githubusercontent.com/.../config.json",
                modelValue: _ctx.configurationUrl,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => _ctx.configurationUrl = $event),
                onErase: _ctx.updateImportOptions
              }, null, 8, ["id", "modelValue", "onErase"])
            ]),
            createVNode(_component_CoreButton, {
              elevation: "",
              "icon-name": "ImportIcon",
              onClick: _ctx.importConfig
            }, {
              default: withCtx(() => [
                createTextVNode(" import ")
              ]),
              _: 1
            }, 8, ["onClick"]),
            _ctx.importUrlStatus === false ? (openBlock(), createElementBlock("span", _hoisted_8$5, " Import from url failed ")) : createCommentVNode("", true),
            _ctx.importUrlStatus === true ? (openBlock(), createElementBlock("span", _hoisted_9$4, " Import from url successful ")) : createCommentVNode("", true),
            _ctx.importConfigLoader ? (openBlock(), createElementBlock("div", _hoisted_10$3)) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", _hoisted_11$3, [
            createBaseVNode("div", null, [
              createBaseVNode("label", {
                for: _ctx.$id("merge-options-mode")
              }, " Update options mode ", 8, _hoisted_12$3),
              withDirectives(createBaseVNode("select", {
                id: _ctx.$id("merge-options-mode"),
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => _ctx.mergeOptionsMode = $event),
                onChange: _cache[2] || (_cache[2] = (...args) => _ctx.updateImportOptions && _ctx.updateImportOptions(...args))
              }, _hoisted_17$3, 40, _hoisted_13$3), [
                [vModelSelect, _ctx.mergeOptionsMode]
              ])
            ])
          ]),
          createBaseVNode("div", _hoisted_18$2, [
            createBaseVNode("div", null, [
              createBaseVNode("label", {
                for: _ctx.$id("auto-sync")
              }, " Auto sync ", 8, _hoisted_19$2),
              withDirectives(createBaseVNode("input", {
                id: _ctx.$id("auto-sync"),
                type: "checkbox",
                "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => _ctx.autoSync = $event),
                onChange: _cache[4] || (_cache[4] = (...args) => _ctx.updateImportOptions && _ctx.updateImportOptions(...args))
              }, null, 40, _hoisted_20$2), [
                [vModelCheckbox, _ctx.autoSync]
              ])
            ])
          ])
        ]),
        createBaseVNode("div", null, [
          createBaseVNode("div", _hoisted_21$2, [
            createBaseVNode("label", {
              for: _ctx.$id("import-file")
            }, " Using File ", 8, _hoisted_22$2),
            createVNode(_component_CoreButton, {
              elevation: "",
              onClick: _cache[5] || (_cache[5] = ($event) => _ctx.$refs.importFileInput.click())
            }, {
              default: withCtx(() => [
                createTextVNode(" Choose File ")
              ]),
              _: 1
            }),
            createBaseVNode("input", {
              ref: "importFileInput",
              id: _ctx.$id("import-file"),
              type: "file",
              accept: ".json",
              onChange: _cache[6] || (_cache[6] = (...args) => _ctx.importFile && _ctx.importFile(...args))
            }, null, 40, _hoisted_23$2),
            _ctx.importFileStatus === false ? (openBlock(), createElementBlock("span", _hoisted_24$2, " Import file failed ")) : createCommentVNode("", true),
            _ctx.importFileStatus === true ? (openBlock(), createElementBlock("span", _hoisted_25$2, " Import file successful ")) : createCommentVNode("", true)
          ])
        ])
      ])
    ]),
    createBaseVNode("div", _hoisted_26$2, [
      _hoisted_27$2,
      createVNode(_component_CoreButton, {
        elevation: "",
        "icon-name": "ExportIcon",
        onClick: _ctx.downloadConfig
      }, {
        default: withCtx(() => [
          createTextVNode(" Export ")
        ]),
        _: 1
      }, 8, ["onClick"]),
      _hoisted_28$2,
      _hoisted_29$2
    ])
  ]);
}
const ImportConfig = /* @__PURE__ */ _export_sfc(_sfc_main$j, [["render", _sfc_render$j], ["__scopeId", "data-v-83904d79"]]);
var pickr_minExports = {};
var pickr_min = {
  get exports() {
    return pickr_minExports;
  },
  set exports(v2) {
    pickr_minExports = v2;
  }
};
/*! Pickr 1.8.2 MIT | https://github.com/Simonwep/pickr */
(function(module, exports) {
  !function(t3, e2) {
    module.exports = e2();
  }(self, function() {
    return (() => {
      var t3 = { d: (e3, o3) => {
        for (var n3 in o3)
          t3.o(o3, n3) && !t3.o(e3, n3) && Object.defineProperty(e3, n3, { enumerable: true, get: o3[n3] });
      }, o: (t4, e3) => Object.prototype.hasOwnProperty.call(t4, e3), r: (t4) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t4, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(t4, "__esModule", { value: true });
      } }, e2 = {};
      t3.d(e2, { default: () => L2 });
      var o2 = {};
      function n2(t4, e3, o3, n3, i3 = {}) {
        e3 instanceof HTMLCollection || e3 instanceof NodeList ? e3 = Array.from(e3) : Array.isArray(e3) || (e3 = [e3]), Array.isArray(o3) || (o3 = [o3]);
        for (const s3 of e3)
          for (const e4 of o3)
            s3[t4](e4, n3, { capture: false, ...i3 });
        return Array.prototype.slice.call(arguments, 1);
      }
      t3.r(o2), t3.d(o2, { adjustableInputNumbers: () => p2, createElementFromString: () => r2, createFromTemplate: () => a2, eventPath: () => l2, off: () => s2, on: () => i2, resolveElement: () => c2 });
      const i2 = n2.bind(null, "addEventListener"), s2 = n2.bind(null, "removeEventListener");
      function r2(t4) {
        const e3 = document.createElement("div");
        return e3.innerHTML = t4.trim(), e3.firstElementChild;
      }
      function a2(t4) {
        const e3 = (t5, e4) => {
          const o4 = t5.getAttribute(e4);
          return t5.removeAttribute(e4), o4;
        }, o3 = (t5, n3 = {}) => {
          const i3 = e3(t5, ":obj"), s3 = e3(t5, ":ref"), r3 = i3 ? n3[i3] = {} : n3;
          s3 && (n3[s3] = t5);
          for (const n4 of Array.from(t5.children)) {
            const t6 = e3(n4, ":arr"), i4 = o3(n4, t6 ? {} : r3);
            t6 && (r3[t6] || (r3[t6] = [])).push(Object.keys(i4).length ? i4 : n4);
          }
          return n3;
        };
        return o3(r2(t4));
      }
      function l2(t4) {
        let e3 = t4.path || t4.composedPath && t4.composedPath();
        if (e3)
          return e3;
        let o3 = t4.target.parentElement;
        for (e3 = [t4.target, o3]; o3 = o3.parentElement; )
          e3.push(o3);
        return e3.push(document, window), e3;
      }
      function c2(t4) {
        return t4 instanceof Element ? t4 : "string" == typeof t4 ? t4.split(/>>/g).reduce((t5, e3, o3, n3) => (t5 = t5.querySelector(e3), o3 < n3.length - 1 ? t5.shadowRoot : t5), document) : null;
      }
      function p2(t4, e3 = (t5) => t5) {
        function o3(o4) {
          const n3 = [1e-3, 0.01, 0.1][Number(o4.shiftKey || 2 * o4.ctrlKey)] * (o4.deltaY < 0 ? 1 : -1);
          let i3 = 0, s3 = t4.selectionStart;
          t4.value = t4.value.replace(/[\d.]+/g, (t5, o5) => o5 <= s3 && o5 + t5.length >= s3 ? (s3 = o5, e3(Number(t5), n3, i3)) : (i3++, t5)), t4.focus(), t4.setSelectionRange(s3, s3), o4.preventDefault(), t4.dispatchEvent(new Event("input"));
        }
        i2(t4, "focus", () => i2(window, "wheel", o3, { passive: false })), i2(t4, "blur", () => s2(window, "wheel", o3));
      }
      const { min: u2, max: h2, floor: d2, round: m2 } = Math;
      function f2(t4, e3, o3) {
        e3 /= 100, o3 /= 100;
        const n3 = d2(t4 = t4 / 360 * 6), i3 = t4 - n3, s3 = o3 * (1 - e3), r3 = o3 * (1 - i3 * e3), a3 = o3 * (1 - (1 - i3) * e3), l3 = n3 % 6;
        return [255 * [o3, r3, s3, s3, a3, o3][l3], 255 * [a3, o3, o3, r3, s3, s3][l3], 255 * [s3, s3, a3, o3, o3, r3][l3]];
      }
      function v2(t4, e3, o3) {
        const n3 = (2 - (e3 /= 100)) * (o3 /= 100) / 2;
        return 0 !== n3 && (e3 = 1 === n3 ? 0 : n3 < 0.5 ? e3 * o3 / (2 * n3) : e3 * o3 / (2 - 2 * n3)), [t4, 100 * e3, 100 * n3];
      }
      function b2(t4, e3, o3) {
        const n3 = u2(t4 /= 255, e3 /= 255, o3 /= 255), i3 = h2(t4, e3, o3), s3 = i3 - n3;
        let r3, a3;
        if (0 === s3)
          r3 = a3 = 0;
        else {
          a3 = s3 / i3;
          const n4 = ((i3 - t4) / 6 + s3 / 2) / s3, l3 = ((i3 - e3) / 6 + s3 / 2) / s3, c3 = ((i3 - o3) / 6 + s3 / 2) / s3;
          t4 === i3 ? r3 = c3 - l3 : e3 === i3 ? r3 = 1 / 3 + n4 - c3 : o3 === i3 && (r3 = 2 / 3 + l3 - n4), r3 < 0 ? r3 += 1 : r3 > 1 && (r3 -= 1);
        }
        return [360 * r3, 100 * a3, 100 * i3];
      }
      function y2(t4, e3, o3, n3) {
        e3 /= 100, o3 /= 100;
        return [...b2(255 * (1 - u2(1, (t4 /= 100) * (1 - (n3 /= 100)) + n3)), 255 * (1 - u2(1, e3 * (1 - n3) + n3)), 255 * (1 - u2(1, o3 * (1 - n3) + n3)))];
      }
      function g2(t4, e3, o3) {
        e3 /= 100;
        const n3 = 2 * (e3 *= (o3 /= 100) < 0.5 ? o3 : 1 - o3) / (o3 + e3) * 100, i3 = 100 * (o3 + e3);
        return [t4, isNaN(n3) ? 0 : n3, i3];
      }
      function _2(t4) {
        return b2(...t4.match(/.{2}/g).map((t5) => parseInt(t5, 16)));
      }
      function w2(t4) {
        t4 = t4.match(/^[a-zA-Z]+$/) ? function(t5) {
          if ("black" === t5.toLowerCase())
            return "#000";
          const e4 = document.createElement("canvas").getContext("2d");
          return e4.fillStyle = t5, "#000" === e4.fillStyle ? null : e4.fillStyle;
        }(t4) : t4;
        const e3 = { cmyk: /^cmyk[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)/i, rgba: /^((rgba)|rgb)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i, hsla: /^((hsla)|hsl)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i, hsva: /^((hsva)|hsv)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i, hexa: /^#?(([\dA-Fa-f]{3,4})|([\dA-Fa-f]{6})|([\dA-Fa-f]{8}))$/i }, o3 = (t5) => t5.map((t6) => /^(|\d+)\.\d+|\d+$/.test(t6) ? Number(t6) : void 0);
        let n3;
        t:
          for (const i3 in e3) {
            if (!(n3 = e3[i3].exec(t4)))
              continue;
            const s3 = (t5) => !!n3[2] == ("number" == typeof t5);
            switch (i3) {
              case "cmyk": {
                const [, t5, e4, s4, r3] = o3(n3);
                if (t5 > 100 || e4 > 100 || s4 > 100 || r3 > 100)
                  break t;
                return { values: y2(t5, e4, s4, r3), type: i3 };
              }
              case "rgba": {
                const [, , , t5, e4, r3, a3] = o3(n3);
                if (t5 > 255 || e4 > 255 || r3 > 255 || a3 < 0 || a3 > 1 || !s3(a3))
                  break t;
                return { values: [...b2(t5, e4, r3), a3], a: a3, type: i3 };
              }
              case "hexa": {
                let [, t5] = n3;
                4 !== t5.length && 3 !== t5.length || (t5 = t5.split("").map((t6) => t6 + t6).join(""));
                const e4 = t5.substring(0, 6);
                let o4 = t5.substring(6);
                return o4 = o4 ? parseInt(o4, 16) / 255 : void 0, { values: [..._2(e4), o4], a: o4, type: i3 };
              }
              case "hsla": {
                const [, , , t5, e4, r3, a3] = o3(n3);
                if (t5 > 360 || e4 > 100 || r3 > 100 || a3 < 0 || a3 > 1 || !s3(a3))
                  break t;
                return { values: [...g2(t5, e4, r3), a3], a: a3, type: i3 };
              }
              case "hsva": {
                const [, , , t5, e4, r3, a3] = o3(n3);
                if (t5 > 360 || e4 > 100 || r3 > 100 || a3 < 0 || a3 > 1 || !s3(a3))
                  break t;
                return { values: [t5, e4, r3, a3], a: a3, type: i3 };
              }
            }
          }
        return { values: null, type: null };
      }
      function A2(t4 = 0, e3 = 0, o3 = 0, n3 = 1) {
        const i3 = (t5, e4) => (o4 = -1) => e4(~o4 ? t5.map((t6) => Number(t6.toFixed(o4))) : t5), s3 = { h: t4, s: e3, v: o3, a: n3, toHSVA() {
          const t5 = [s3.h, s3.s, s3.v, s3.a];
          return t5.toString = i3(t5, (t6) => `hsva(${t6[0]}, ${t6[1]}%, ${t6[2]}%, ${s3.a})`), t5;
        }, toHSLA() {
          const t5 = [...v2(s3.h, s3.s, s3.v), s3.a];
          return t5.toString = i3(t5, (t6) => `hsla(${t6[0]}, ${t6[1]}%, ${t6[2]}%, ${s3.a})`), t5;
        }, toRGBA() {
          const t5 = [...f2(s3.h, s3.s, s3.v), s3.a];
          return t5.toString = i3(t5, (t6) => `rgba(${t6[0]}, ${t6[1]}, ${t6[2]}, ${s3.a})`), t5;
        }, toCMYK() {
          const t5 = function(t6, e4, o4) {
            const n4 = f2(t6, e4, o4), i4 = n4[0] / 255, s4 = n4[1] / 255, r3 = n4[2] / 255, a3 = u2(1 - i4, 1 - s4, 1 - r3);
            return [100 * (1 === a3 ? 0 : (1 - i4 - a3) / (1 - a3)), 100 * (1 === a3 ? 0 : (1 - s4 - a3) / (1 - a3)), 100 * (1 === a3 ? 0 : (1 - r3 - a3) / (1 - a3)), 100 * a3];
          }(s3.h, s3.s, s3.v);
          return t5.toString = i3(t5, (t6) => `cmyk(${t6[0]}%, ${t6[1]}%, ${t6[2]}%, ${t6[3]}%)`), t5;
        }, toHEXA() {
          const t5 = function(t6, e5, o4) {
            return f2(t6, e5, o4).map((t7) => m2(t7).toString(16).padStart(2, "0"));
          }(s3.h, s3.s, s3.v), e4 = s3.a >= 1 ? "" : Number((255 * s3.a).toFixed(0)).toString(16).toUpperCase().padStart(2, "0");
          return e4 && t5.push(e4), t5.toString = () => `#${t5.join("").toUpperCase()}`, t5;
        }, clone: () => A2(s3.h, s3.s, s3.v, s3.a) };
        return s3;
      }
      const C2 = (t4) => Math.max(Math.min(t4, 1), 0);
      function $2(t4) {
        const e3 = { options: Object.assign({ lock: null, onchange: () => 0, onstop: () => 0 }, t4), _keyboard(t5) {
          const { options: o4 } = e3, { type: n4, key: i3 } = t5;
          if (document.activeElement === o4.wrapper) {
            const { lock: o5 } = e3.options, s3 = "ArrowUp" === i3, r4 = "ArrowRight" === i3, a3 = "ArrowDown" === i3, l3 = "ArrowLeft" === i3;
            if ("keydown" === n4 && (s3 || r4 || a3 || l3)) {
              let n5 = 0, i4 = 0;
              "v" === o5 ? n5 = s3 || r4 ? 1 : -1 : "h" === o5 ? n5 = s3 || r4 ? -1 : 1 : (i4 = s3 ? -1 : a3 ? 1 : 0, n5 = l3 ? -1 : r4 ? 1 : 0), e3.update(C2(e3.cache.x + 0.01 * n5), C2(e3.cache.y + 0.01 * i4)), t5.preventDefault();
            } else
              i3.startsWith("Arrow") && (e3.options.onstop(), t5.preventDefault());
          }
        }, _tapstart(t5) {
          i2(document, ["mouseup", "touchend", "touchcancel"], e3._tapstop), i2(document, ["mousemove", "touchmove"], e3._tapmove), t5.cancelable && t5.preventDefault(), e3._tapmove(t5);
        }, _tapmove(t5) {
          const { options: o4, cache: n4 } = e3, { lock: i3, element: s3, wrapper: r4 } = o4, a3 = r4.getBoundingClientRect();
          let l3 = 0, c3 = 0;
          if (t5) {
            const e4 = t5 && t5.touches && t5.touches[0];
            l3 = t5 ? (e4 || t5).clientX : 0, c3 = t5 ? (e4 || t5).clientY : 0, l3 < a3.left ? l3 = a3.left : l3 > a3.left + a3.width && (l3 = a3.left + a3.width), c3 < a3.top ? c3 = a3.top : c3 > a3.top + a3.height && (c3 = a3.top + a3.height), l3 -= a3.left, c3 -= a3.top;
          } else
            n4 && (l3 = n4.x * a3.width, c3 = n4.y * a3.height);
          "h" !== i3 && (s3.style.left = `calc(${l3 / a3.width * 100}% - ${s3.offsetWidth / 2}px)`), "v" !== i3 && (s3.style.top = `calc(${c3 / a3.height * 100}% - ${s3.offsetHeight / 2}px)`), e3.cache = { x: l3 / a3.width, y: c3 / a3.height };
          const p3 = C2(l3 / a3.width), u3 = C2(c3 / a3.height);
          switch (i3) {
            case "v":
              return o4.onchange(p3);
            case "h":
              return o4.onchange(u3);
            default:
              return o4.onchange(p3, u3);
          }
        }, _tapstop() {
          e3.options.onstop(), s2(document, ["mouseup", "touchend", "touchcancel"], e3._tapstop), s2(document, ["mousemove", "touchmove"], e3._tapmove);
        }, trigger() {
          e3._tapmove();
        }, update(t5 = 0, o4 = 0) {
          const { left: n4, top: i3, width: s3, height: r4 } = e3.options.wrapper.getBoundingClientRect();
          "h" === e3.options.lock && (o4 = t5), e3._tapmove({ clientX: n4 + s3 * t5, clientY: i3 + r4 * o4 });
        }, destroy() {
          const { options: t5, _tapstart: o4, _keyboard: n4 } = e3;
          s2(document, ["keydown", "keyup"], n4), s2([t5.wrapper, t5.element], "mousedown", o4), s2([t5.wrapper, t5.element], "touchstart", o4, { passive: false });
        } }, { options: o3, _tapstart: n3, _keyboard: r3 } = e3;
        return i2([o3.wrapper, o3.element], "mousedown", n3), i2([o3.wrapper, o3.element], "touchstart", n3, { passive: false }), i2(document, ["keydown", "keyup"], r3), e3;
      }
      function k2(t4 = {}) {
        t4 = Object.assign({ onchange: () => 0, className: "", elements: [] }, t4);
        const e3 = i2(t4.elements, "click", (e4) => {
          t4.elements.forEach((o3) => o3.classList[e4.target === o3 ? "add" : "remove"](t4.className)), t4.onchange(e4), e4.stopPropagation();
        });
        return { destroy: () => s2(...e3) };
      }
      const S2 = { variantFlipOrder: { start: "sme", middle: "mse", end: "ems" }, positionFlipOrder: { top: "tbrl", right: "rltb", bottom: "btrl", left: "lrbt" }, position: "bottom", margin: 8 }, O2 = (t4, e3, o3) => {
        const { container: n3, margin: i3, position: s3, variantFlipOrder: r3, positionFlipOrder: a3 } = { container: document.documentElement.getBoundingClientRect(), ...S2, ...o3 }, { left: l3, top: c3 } = e3.style;
        e3.style.left = "0", e3.style.top = "0";
        const p3 = t4.getBoundingClientRect(), u3 = e3.getBoundingClientRect(), h3 = { t: p3.top - u3.height - i3, b: p3.bottom + i3, r: p3.right + i3, l: p3.left - u3.width - i3 }, d3 = { vs: p3.left, vm: p3.left + p3.width / 2 + -u3.width / 2, ve: p3.left + p3.width - u3.width, hs: p3.top, hm: p3.bottom - p3.height / 2 - u3.height / 2, he: p3.bottom - u3.height }, [m3, f3 = "middle"] = s3.split("-"), v3 = a3[m3], b3 = r3[f3], { top: y3, left: g3, bottom: _3, right: w3 } = n3;
        for (const t5 of v3) {
          const o4 = "t" === t5 || "b" === t5, n4 = h3[t5], [i4, s4] = o4 ? ["top", "left"] : ["left", "top"], [r4, a4] = o4 ? [u3.height, u3.width] : [u3.width, u3.height], [l4, c4] = o4 ? [_3, w3] : [w3, _3], [p4, m4] = o4 ? [y3, g3] : [g3, y3];
          if (!(n4 < p4 || n4 + r4 > l4))
            for (const r5 of b3) {
              const l5 = d3[(o4 ? "v" : "h") + r5];
              if (!(l5 < m4 || l5 + a4 > c4))
                return e3.style[s4] = l5 - u3[s4] + "px", e3.style[i4] = n4 - u3[i4] + "px", t5 + r5;
            }
        }
        return e3.style.left = l3, e3.style.top = c3, null;
      };
      function E2(t4, e3, o3) {
        return e3 in t4 ? Object.defineProperty(t4, e3, { value: o3, enumerable: true, configurable: true, writable: true }) : t4[e3] = o3, t4;
      }
      class L2 {
        constructor(t4) {
          E2(this, "_initializingActive", true), E2(this, "_recalc", true), E2(this, "_nanopop", null), E2(this, "_root", null), E2(this, "_color", A2()), E2(this, "_lastColor", A2()), E2(this, "_swatchColors", []), E2(this, "_setupAnimationFrame", null), E2(this, "_eventListener", { init: [], save: [], hide: [], show: [], clear: [], change: [], changestop: [], cancel: [], swatchselect: [] }), this.options = t4 = Object.assign({ ...L2.DEFAULT_OPTIONS }, t4);
          const { swatches: e3, components: o3, theme: n3, sliders: i3, lockOpacity: s3, padding: r3 } = t4;
          ["nano", "monolith"].includes(n3) && !i3 && (t4.sliders = "h"), o3.interaction || (o3.interaction = {});
          const { preview: a3, opacity: l3, hue: c3, palette: p3 } = o3;
          o3.opacity = !s3 && l3, o3.palette = p3 || a3 || l3 || c3, this._preBuild(), this._buildComponents(), this._bindEvents(), this._finalBuild(), e3 && e3.length && e3.forEach((t5) => this.addSwatch(t5));
          const { button: u3, app: h3 } = this._root;
          this._nanopop = ((t5, e4, o4) => {
            const n4 = "object" != typeof t5 || t5 instanceof HTMLElement ? { reference: t5, popper: e4, ...o4 } : t5;
            return { update(t6 = n4) {
              const { reference: e5, popper: o5 } = Object.assign(n4, t6);
              if (!o5 || !e5)
                throw new Error("Popper- or reference-element missing.");
              return O2(e5, o5, n4);
            } };
          })(u3, h3, { margin: r3 }), u3.setAttribute("role", "button"), u3.setAttribute("aria-label", this._t("btn:toggle"));
          const d3 = this;
          this._setupAnimationFrame = requestAnimationFrame(function e4() {
            if (!h3.offsetWidth)
              return requestAnimationFrame(e4);
            d3.setColor(t4.default), d3._rePositioningPicker(), t4.defaultRepresentation && (d3._representation = t4.defaultRepresentation, d3.setColorRepresentation(d3._representation)), t4.showAlways && d3.show(), d3._initializingActive = false, d3._emit("init");
          });
        }
        _preBuild() {
          const { options: t4 } = this;
          for (const e3 of ["el", "container"])
            t4[e3] = c2(t4[e3]);
          this._root = ((t5) => {
            const { components: e3, useAsButton: o3, inline: n3, appClass: i3, theme: s3, lockOpacity: r3 } = t5.options, l3 = (t6) => t6 ? "" : 'style="display:none" hidden', c3 = (e4) => t5._t(e4), p3 = a2(`
      <div :ref="root" class="pickr">

        ${o3 ? "" : '<button type="button" :ref="button" class="pcr-button"></button>'}

        <div :ref="app" class="pcr-app ${i3 || ""}" data-theme="${s3}" ${n3 ? 'style="position: unset"' : ""} aria-label="${c3("ui:dialog")}" role="window">
          <div class="pcr-selection" ${l3(e3.palette)}>
            <div :obj="preview" class="pcr-color-preview" ${l3(e3.preview)}>
              <button type="button" :ref="lastColor" class="pcr-last-color" aria-label="${c3("btn:last-color")}"></button>
              <div :ref="currentColor" class="pcr-current-color"></div>
            </div>

            <div :obj="palette" class="pcr-color-palette">
              <div :ref="picker" class="pcr-picker"></div>
              <div :ref="palette" class="pcr-palette" tabindex="0" aria-label="${c3("aria:palette")}" role="listbox"></div>
            </div>

            <div :obj="hue" class="pcr-color-chooser" ${l3(e3.hue)}>
              <div :ref="picker" class="pcr-picker"></div>
              <div :ref="slider" class="pcr-hue pcr-slider" tabindex="0" aria-label="${c3("aria:hue")}" role="slider"></div>
            </div>

            <div :obj="opacity" class="pcr-color-opacity" ${l3(e3.opacity)}>
              <div :ref="picker" class="pcr-picker"></div>
              <div :ref="slider" class="pcr-opacity pcr-slider" tabindex="0" aria-label="${c3("aria:opacity")}" role="slider"></div>
            </div>
          </div>

          <div class="pcr-swatches ${e3.palette ? "" : "pcr-last"}" :ref="swatches"></div>

          <div :obj="interaction" class="pcr-interaction" ${l3(Object.keys(e3.interaction).length)}>
            <input :ref="result" class="pcr-result" type="text" spellcheck="false" ${l3(e3.interaction.input)} aria-label="${c3("aria:input")}">

            <input :arr="options" class="pcr-type" data-type="HEXA" value="${r3 ? "HEX" : "HEXA"}" type="button" ${l3(e3.interaction.hex)}>
            <input :arr="options" class="pcr-type" data-type="RGBA" value="${r3 ? "RGB" : "RGBA"}" type="button" ${l3(e3.interaction.rgba)}>
            <input :arr="options" class="pcr-type" data-type="HSLA" value="${r3 ? "HSL" : "HSLA"}" type="button" ${l3(e3.interaction.hsla)}>
            <input :arr="options" class="pcr-type" data-type="HSVA" value="${r3 ? "HSV" : "HSVA"}" type="button" ${l3(e3.interaction.hsva)}>
            <input :arr="options" class="pcr-type" data-type="CMYK" value="CMYK" type="button" ${l3(e3.interaction.cmyk)}>

            <input :ref="save" class="pcr-save" value="${c3("btn:save")}" type="button" ${l3(e3.interaction.save)} aria-label="${c3("aria:btn:save")}">
            <input :ref="cancel" class="pcr-cancel" value="${c3("btn:cancel")}" type="button" ${l3(e3.interaction.cancel)} aria-label="${c3("aria:btn:cancel")}">
            <input :ref="clear" class="pcr-clear" value="${c3("btn:clear")}" type="button" ${l3(e3.interaction.clear)} aria-label="${c3("aria:btn:clear")}">
          </div>
        </div>
      </div>
    `), u3 = p3.interaction;
            return u3.options.find((t6) => !t6.hidden && !t6.classList.add("active")), u3.type = () => u3.options.find((t6) => t6.classList.contains("active")), p3;
          })(this), t4.useAsButton && (this._root.button = t4.el), t4.container.appendChild(this._root.root);
        }
        _finalBuild() {
          const t4 = this.options, e3 = this._root;
          if (t4.container.removeChild(e3.root), t4.inline) {
            const o3 = t4.el.parentElement;
            t4.el.nextSibling ? o3.insertBefore(e3.app, t4.el.nextSibling) : o3.appendChild(e3.app);
          } else
            t4.container.appendChild(e3.app);
          t4.useAsButton ? t4.inline && t4.el.remove() : t4.el.parentNode.replaceChild(e3.root, t4.el), t4.disabled && this.disable(), t4.comparison || (e3.button.style.transition = "none", t4.useAsButton || (e3.preview.lastColor.style.transition = "none")), this.hide();
        }
        _buildComponents() {
          const t4 = this, e3 = this.options.components, o3 = (t4.options.sliders || "v").repeat(2), [n3, i3] = o3.match(/^[vh]+$/g) ? o3 : [], s3 = () => this._color || (this._color = this._lastColor.clone()), r3 = { palette: $2({ element: t4._root.palette.picker, wrapper: t4._root.palette.palette, onstop: () => t4._emit("changestop", "slider", t4), onchange(o4, n4) {
            if (!e3.palette)
              return;
            const i4 = s3(), { _root: r4, options: a3 } = t4, { lastColor: l3, currentColor: c3 } = r4.preview;
            t4._recalc && (i4.s = 100 * o4, i4.v = 100 - 100 * n4, i4.v < 0 && (i4.v = 0), t4._updateOutput("slider"));
            const p3 = i4.toRGBA().toString(0);
            this.element.style.background = p3, this.wrapper.style.background = `
                        linear-gradient(to top, rgba(0, 0, 0, ${i4.a}), transparent),
                        linear-gradient(to left, hsla(${i4.h}, 100%, 50%, ${i4.a}), rgba(255, 255, 255, ${i4.a}))
                    `, a3.comparison ? a3.useAsButton || t4._lastColor || l3.style.setProperty("--pcr-color", p3) : (r4.button.style.setProperty("--pcr-color", p3), r4.button.classList.remove("clear"));
            const u3 = i4.toHEXA().toString();
            for (const { el: e4, color: o5 } of t4._swatchColors)
              e4.classList[u3 === o5.toHEXA().toString() ? "add" : "remove"]("pcr-active");
            c3.style.setProperty("--pcr-color", p3);
          } }), hue: $2({ lock: "v" === i3 ? "h" : "v", element: t4._root.hue.picker, wrapper: t4._root.hue.slider, onstop: () => t4._emit("changestop", "slider", t4), onchange(o4) {
            if (!e3.hue || !e3.palette)
              return;
            const n4 = s3();
            t4._recalc && (n4.h = 360 * o4), this.element.style.backgroundColor = `hsl(${n4.h}, 100%, 50%)`, r3.palette.trigger();
          } }), opacity: $2({ lock: "v" === n3 ? "h" : "v", element: t4._root.opacity.picker, wrapper: t4._root.opacity.slider, onstop: () => t4._emit("changestop", "slider", t4), onchange(o4) {
            if (!e3.opacity || !e3.palette)
              return;
            const n4 = s3();
            t4._recalc && (n4.a = Math.round(100 * o4) / 100), this.element.style.background = `rgba(0, 0, 0, ${n4.a})`, r3.palette.trigger();
          } }), selectable: k2({ elements: t4._root.interaction.options, className: "active", onchange(e4) {
            t4._representation = e4.target.getAttribute("data-type").toUpperCase(), t4._recalc && t4._updateOutput("swatch");
          } }) };
          this._components = r3;
        }
        _bindEvents() {
          const { _root: t4, options: e3 } = this, o3 = [i2(t4.interaction.clear, "click", () => this._clearColor()), i2([t4.interaction.cancel, t4.preview.lastColor], "click", () => {
            this.setHSVA(...(this._lastColor || this._color).toHSVA(), true), this._emit("cancel");
          }), i2(t4.interaction.save, "click", () => {
            !this.applyColor() && !e3.showAlways && this.hide();
          }), i2(t4.interaction.result, ["keyup", "input"], (t5) => {
            this.setColor(t5.target.value, true) && !this._initializingActive && (this._emit("change", this._color, "input", this), this._emit("changestop", "input", this)), t5.stopImmediatePropagation();
          }), i2(t4.interaction.result, ["focus", "blur"], (t5) => {
            this._recalc = "blur" === t5.type, this._recalc && this._updateOutput(null);
          }), i2([t4.palette.palette, t4.palette.picker, t4.hue.slider, t4.hue.picker, t4.opacity.slider, t4.opacity.picker], ["mousedown", "touchstart"], () => this._recalc = true, { passive: true })];
          if (!e3.showAlways) {
            const n3 = e3.closeWithKey;
            o3.push(i2(t4.button, "click", () => this.isOpen() ? this.hide() : this.show()), i2(document, "keyup", (t5) => this.isOpen() && (t5.key === n3 || t5.code === n3) && this.hide()), i2(document, ["touchstart", "mousedown"], (e4) => {
              this.isOpen() && !l2(e4).some((e5) => e5 === t4.app || e5 === t4.button) && this.hide();
            }, { capture: true }));
          }
          if (e3.adjustableNumbers) {
            const e4 = { rgba: [255, 255, 255, 1], hsva: [360, 100, 100, 1], hsla: [360, 100, 100, 1], cmyk: [100, 100, 100, 100] };
            p2(t4.interaction.result, (t5, o4, n3) => {
              const i3 = e4[this.getColorRepresentation().toLowerCase()];
              if (i3) {
                const e5 = i3[n3], s3 = t5 + (e5 >= 100 ? 1e3 * o4 : o4);
                return s3 <= 0 ? 0 : Number((s3 < e5 ? s3 : e5).toPrecision(3));
              }
              return t5;
            });
          }
          if (e3.autoReposition && !e3.inline) {
            let t5 = null;
            const n3 = this;
            o3.push(i2(window, ["scroll", "resize"], () => {
              n3.isOpen() && (e3.closeOnScroll && n3.hide(), null === t5 ? (t5 = setTimeout(() => t5 = null, 100), requestAnimationFrame(function e4() {
                n3._rePositioningPicker(), null !== t5 && requestAnimationFrame(e4);
              })) : (clearTimeout(t5), t5 = setTimeout(() => t5 = null, 100)));
            }, { capture: true }));
          }
          this._eventBindings = o3;
        }
        _rePositioningPicker() {
          const { options: t4 } = this;
          if (!t4.inline) {
            if (!this._nanopop.update({ container: document.body.getBoundingClientRect(), position: t4.position })) {
              const t5 = this._root.app, e3 = t5.getBoundingClientRect();
              t5.style.top = (window.innerHeight - e3.height) / 2 + "px", t5.style.left = (window.innerWidth - e3.width) / 2 + "px";
            }
          }
        }
        _updateOutput(t4) {
          const { _root: e3, _color: o3, options: n3 } = this;
          if (e3.interaction.type()) {
            const t5 = `to${e3.interaction.type().getAttribute("data-type")}`;
            e3.interaction.result.value = "function" == typeof o3[t5] ? o3[t5]().toString(n3.outputPrecision) : "";
          }
          !this._initializingActive && this._recalc && this._emit("change", o3, t4, this);
        }
        _clearColor(t4 = false) {
          const { _root: e3, options: o3 } = this;
          o3.useAsButton || e3.button.style.setProperty("--pcr-color", "rgba(0, 0, 0, 0.15)"), e3.button.classList.add("clear"), o3.showAlways || this.hide(), this._lastColor = null, this._initializingActive || t4 || (this._emit("save", null), this._emit("clear"));
        }
        _parseLocalColor(t4) {
          const { values: e3, type: o3, a: n3 } = w2(t4), { lockOpacity: i3 } = this.options, s3 = void 0 !== n3 && 1 !== n3;
          return e3 && 3 === e3.length && (e3[3] = void 0), { values: !e3 || i3 && s3 ? null : e3, type: o3 };
        }
        _t(t4) {
          return this.options.i18n[t4] || L2.I18N_DEFAULTS[t4];
        }
        _emit(t4, ...e3) {
          this._eventListener[t4].forEach((t5) => t5(...e3, this));
        }
        on(t4, e3) {
          return this._eventListener[t4].push(e3), this;
        }
        off(t4, e3) {
          const o3 = this._eventListener[t4] || [], n3 = o3.indexOf(e3);
          return ~n3 && o3.splice(n3, 1), this;
        }
        addSwatch(t4) {
          const { values: e3 } = this._parseLocalColor(t4);
          if (e3) {
            const { _swatchColors: t5, _root: o3 } = this, n3 = A2(...e3), s3 = r2(`<button type="button" style="--pcr-color: ${n3.toRGBA().toString(0)}" aria-label="${this._t("btn:swatch")}"/>`);
            return o3.swatches.appendChild(s3), t5.push({ el: s3, color: n3 }), this._eventBindings.push(i2(s3, "click", () => {
              this.setHSVA(...n3.toHSVA(), true), this._emit("swatchselect", n3), this._emit("change", n3, "swatch", this);
            })), true;
          }
          return false;
        }
        removeSwatch(t4) {
          const e3 = this._swatchColors[t4];
          if (e3) {
            const { el: o3 } = e3;
            return this._root.swatches.removeChild(o3), this._swatchColors.splice(t4, 1), true;
          }
          return false;
        }
        applyColor(t4 = false) {
          const { preview: e3, button: o3 } = this._root, n3 = this._color.toRGBA().toString(0);
          return e3.lastColor.style.setProperty("--pcr-color", n3), this.options.useAsButton || o3.style.setProperty("--pcr-color", n3), o3.classList.remove("clear"), this._lastColor = this._color.clone(), this._initializingActive || t4 || this._emit("save", this._color), this;
        }
        destroy() {
          cancelAnimationFrame(this._setupAnimationFrame), this._eventBindings.forEach((t4) => s2(...t4)), Object.keys(this._components).forEach((t4) => this._components[t4].destroy());
        }
        destroyAndRemove() {
          this.destroy();
          const { root: t4, app: e3 } = this._root;
          t4.parentElement && t4.parentElement.removeChild(t4), e3.parentElement.removeChild(e3), Object.keys(this).forEach((t5) => this[t5] = null);
        }
        hide() {
          return !!this.isOpen() && (this._root.app.classList.remove("visible"), this._emit("hide"), true);
        }
        show() {
          return !this.options.disabled && !this.isOpen() && (this._root.app.classList.add("visible"), this._rePositioningPicker(), this._emit("show", this._color), this);
        }
        isOpen() {
          return this._root.app.classList.contains("visible");
        }
        setHSVA(t4 = 360, e3 = 0, o3 = 0, n3 = 1, i3 = false) {
          const s3 = this._recalc;
          if (this._recalc = false, t4 < 0 || t4 > 360 || e3 < 0 || e3 > 100 || o3 < 0 || o3 > 100 || n3 < 0 || n3 > 1)
            return false;
          this._color = A2(t4, e3, o3, n3);
          const { hue: r3, opacity: a3, palette: l3 } = this._components;
          return r3.update(t4 / 360), a3.update(n3), l3.update(e3 / 100, 1 - o3 / 100), i3 || this.applyColor(), s3 && this._updateOutput(), this._recalc = s3, true;
        }
        setColor(t4, e3 = false) {
          if (null === t4)
            return this._clearColor(e3), true;
          const { values: o3, type: n3 } = this._parseLocalColor(t4);
          if (o3) {
            const t5 = n3.toUpperCase(), { options: i3 } = this._root.interaction, s3 = i3.find((e4) => e4.getAttribute("data-type") === t5);
            if (s3 && !s3.hidden)
              for (const t6 of i3)
                t6.classList[t6 === s3 ? "add" : "remove"]("active");
            return !!this.setHSVA(...o3, e3) && this.setColorRepresentation(t5);
          }
          return false;
        }
        setColorRepresentation(t4) {
          return t4 = t4.toUpperCase(), !!this._root.interaction.options.find((e3) => e3.getAttribute("data-type").startsWith(t4) && !e3.click());
        }
        getColorRepresentation() {
          return this._representation;
        }
        getColor() {
          return this._color;
        }
        getSelectedColor() {
          return this._lastColor;
        }
        getRoot() {
          return this._root;
        }
        disable() {
          return this.hide(), this.options.disabled = true, this._root.button.classList.add("disabled"), this;
        }
        enable() {
          return this.options.disabled = false, this._root.button.classList.remove("disabled"), this;
        }
      }
      return E2(L2, "utils", o2), E2(L2, "version", "1.8.2"), E2(L2, "I18N_DEFAULTS", { "ui:dialog": "color picker dialog", "btn:toggle": "toggle color picker dialog", "btn:swatch": "color swatch", "btn:last-color": "use previous color", "btn:save": "Save", "btn:cancel": "Cancel", "btn:clear": "Clear", "aria:btn:save": "save and close", "aria:btn:cancel": "cancel and close", "aria:btn:clear": "clear and close", "aria:input": "color input field", "aria:palette": "color selection area", "aria:hue": "hue selection slider", "aria:opacity": "selection slider" }), E2(L2, "DEFAULT_OPTIONS", { appClass: null, theme: "classic", useAsButton: false, padding: 8, disabled: false, comparison: true, closeOnScroll: false, outputPrecision: 0, lockOpacity: false, autoReposition: true, container: "body", components: { interaction: {} }, i18n: {}, swatches: null, inline: false, sliders: null, default: "#42445a", defaultRepresentation: null, position: "bottom-middle", adjustableNumbers: true, showAlways: false, closeWithKey: "Escape" }), E2(L2, "create", (t4) => new L2(t4)), e2 = e2.default;
    })();
  });
})(pickr_min);
const Pickr = /* @__PURE__ */ getDefaultExportFromCjs(pickr_minExports);
function createColorPicker({ elem, defaultColor, updateColor }) {
  return Pickr.create({
    el: elem,
    theme: "nano",
    default: defaultColor,
    swatches: [
      "rgba(244, 67, 54, 1)",
      "rgba(233, 30, 99, 0.95)",
      "rgba(156, 39, 176, 0.9)",
      "rgba(103, 58, 183, 0.85)",
      "rgba(63, 81, 181, 0.8)",
      "rgba(33, 150, 243, 0.75)",
      "rgba(3, 169, 244, 0.7)",
      "rgba(0, 188, 212, 0.7)",
      "rgba(0, 150, 136, 0.75)",
      "rgba(76, 175, 80, 0.8)",
      "rgba(139, 195, 74, 0.85)",
      "rgba(205, 220, 57, 0.9)",
      "rgba(255, 235, 59, 0.95)",
      "rgba(255, 193, 7, 1)"
    ],
    components: {
      // Main components
      preview: true,
      opacity: true,
      hue: true,
      // Input / output Options
      interaction: {
        hex: true
      }
    }
  }).on("changestop", (instance) => {
    updateColor(instance.getColor());
  }).on("swatchselect", (color) => {
    updateColor(color);
  });
}
const nano_min_css_vue_type_style_index_0_src_true_lang = "";
const ColorPicker_vue_vue_type_style_index_1_scoped_2a2321bd_lang = "";
function useColorPicker(pickr, pickrElem, colorValue, context) {
  if (pickrElem.value != null && pickr.value == null) {
    pickr.value = createColorPicker({
      elem: pickrElem.value,
      defaultColor: colorValue,
      updateColor(color) {
        const colorValue2 = color.toHEXA().toString();
        pickr.value.setColor(colorValue2);
        context.emit("update:color", color.toHEXA().toString());
      }
    });
  }
}
const _sfc_main$i = defineComponent({
  name: "ColorPicker",
  props: {
    color: {
      type: String,
      required: true
    }
  },
  emits: ["update:color"],
  setup(props, context) {
    const pickr = ref(null);
    const pickrElem = ref(null);
    onMounted(() => {
      window.requestIdleCallback(
        () => {
          useColorPicker(pickr, pickrElem, props.color, context);
        },
        { timeout: 500 }
      );
    });
    onBeforeUnmount(() => {
      if (pickr.value) {
        pickr.value._root.app.remove();
        pickr.value.destroy();
        pickr.value = null;
      }
    });
    watch(
      () => props.color,
      (val) => {
        pickr.value.setColor(val);
      }
    );
    return {
      pickrElem
    };
  }
});
const _hoisted_1$i = { ref: "pickrElem" };
function _sfc_render$i(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", _hoisted_1$i, [
    createBaseVNode("div", {
      class: "dummyPickr",
      style: normalizeStyle({ backgroundColor: _ctx.color })
    }, null, 4)
  ], 512);
}
const ColorPicker = /* @__PURE__ */ _export_sfc(_sfc_main$i, [["render", _sfc_render$i], ["__scopeId", "data-v-2a2321bd"]]);
function addData(element, key, value) {
  if (value === void 0) {
    return element && element.h5s && element.h5s.data && element.h5s.data[key];
  } else {
    element.h5s = element.h5s || {};
    element.h5s.data = element.h5s.data || {};
    element.h5s.data[key] = value;
  }
}
function removeData(element) {
  if (element.h5s) {
    delete element.h5s.data;
  }
}
var filter = function(nodes, selector) {
  if (!(nodes instanceof NodeList || nodes instanceof HTMLCollection || nodes instanceof Array)) {
    throw new Error("You must provide a nodeList/HTMLCollection/Array of elements to be filtered.");
  }
  if (typeof selector !== "string") {
    return Array.from(nodes);
  }
  return Array.from(nodes).filter(function(item) {
    return item.nodeType === 1 && item.matches(selector);
  });
};
var stores = /* @__PURE__ */ new Map();
var Store = (
  /** @class */
  function() {
    function Store2() {
      this._config = /* @__PURE__ */ new Map();
      this._placeholder = void 0;
      this._data = /* @__PURE__ */ new Map();
    }
    Object.defineProperty(Store2.prototype, "config", {
      /**
       * get the configuration map of a class instance
       * @method config
       * @return {object}
       */
      get: function() {
        var config = {};
        this._config.forEach(function(value, key) {
          config[key] = value;
        });
        return config;
      },
      /**
       * set the configuration of a class instance
       * @method config
       * @param {object} config object of configurations
       */
      set: function(config) {
        if (typeof config !== "object") {
          throw new Error("You must provide a valid configuration object to the config setter.");
        }
        var mergedConfig = Object.assign({}, config);
        this._config = new Map(Object.entries(mergedConfig));
      },
      enumerable: false,
      configurable: true
    });
    Store2.prototype.setConfig = function(key, value) {
      if (!this._config.has(key)) {
        throw new Error("Trying to set invalid configuration item: " + key);
      }
      this._config.set(key, value);
    };
    Store2.prototype.getConfig = function(key) {
      if (!this._config.has(key)) {
        throw new Error("Invalid configuration item requested: " + key);
      }
      return this._config.get(key);
    };
    Object.defineProperty(Store2.prototype, "placeholder", {
      /**
       * get the placeholder for a class instance
       * @method placeholder
       * @return {HTMLElement|null}
       */
      get: function() {
        return this._placeholder;
      },
      /**
       * set the placeholder for a class instance
       * @method placeholder
       * @param {HTMLElement} placeholder
       * @return {void}
       */
      set: function(placeholder) {
        if (!(placeholder instanceof HTMLElement) && placeholder !== null) {
          throw new Error("A placeholder must be an html element or null.");
        }
        this._placeholder = placeholder;
      },
      enumerable: false,
      configurable: true
    });
    Store2.prototype.setData = function(key, value) {
      if (typeof key !== "string") {
        throw new Error("The key must be a string.");
      }
      this._data.set(key, value);
    };
    Store2.prototype.getData = function(key) {
      if (typeof key !== "string") {
        throw new Error("The key must be a string.");
      }
      return this._data.get(key);
    };
    Store2.prototype.deleteData = function(key) {
      if (typeof key !== "string") {
        throw new Error("The key must be a string.");
      }
      return this._data.delete(key);
    };
    return Store2;
  }()
);
var store = function(sortableElement) {
  if (!(sortableElement instanceof HTMLElement)) {
    throw new Error("Please provide a sortable to the store function.");
  }
  if (!stores.has(sortableElement)) {
    stores.set(sortableElement, new Store());
  }
  return stores.get(sortableElement);
};
function addEventListener(element, eventName, callback) {
  if (element instanceof Array) {
    for (var i2 = 0; i2 < element.length; ++i2) {
      addEventListener(element[i2], eventName, callback);
    }
    return;
  }
  element.addEventListener(eventName, callback);
  store(element).setData("event" + eventName, callback);
}
function removeEventListener(element, eventName) {
  if (element instanceof Array) {
    for (var i2 = 0; i2 < element.length; ++i2) {
      removeEventListener(element[i2], eventName);
    }
    return;
  }
  element.removeEventListener(eventName, store(element).getData("event" + eventName));
  store(element).deleteData("event" + eventName);
}
function addAttribute(element, attribute, value) {
  if (element instanceof Array) {
    for (var i2 = 0; i2 < element.length; ++i2) {
      addAttribute(element[i2], attribute, value);
    }
    return;
  }
  element.setAttribute(attribute, value);
}
function removeAttribute(element, attribute) {
  if (element instanceof Array) {
    for (var i2 = 0; i2 < element.length; ++i2) {
      removeAttribute(element[i2], attribute);
    }
    return;
  }
  element.removeAttribute(attribute);
}
var offset = function(element) {
  if (!element.parentElement || element.getClientRects().length === 0) {
    throw new Error("target element must be part of the dom");
  }
  var rect = element.getClientRects()[0];
  return {
    left: rect.left + window.pageXOffset,
    right: rect.right + window.pageXOffset,
    top: rect.top + window.pageYOffset,
    bottom: rect.bottom + window.pageYOffset
  };
};
var debounce = function(func, wait) {
  if (wait === void 0) {
    wait = 0;
  }
  var timeout;
  return function() {
    var args = [];
    for (var _i2 = 0; _i2 < arguments.length; _i2++) {
      args[_i2] = arguments[_i2];
    }
    clearTimeout(timeout);
    timeout = setTimeout(function() {
      func.apply(void 0, args);
    }, wait);
  };
};
var getIndex = function(element, elementList) {
  if (!(element instanceof HTMLElement) || !(elementList instanceof NodeList || elementList instanceof HTMLCollection || elementList instanceof Array)) {
    throw new Error("You must provide an element and a list of elements.");
  }
  return Array.from(elementList).indexOf(element);
};
var isInDom = function(element) {
  if (!(element instanceof HTMLElement)) {
    throw new Error("Element is not a node element.");
  }
  return element.parentNode !== null;
};
var insertNode = function(referenceNode, newElement, position) {
  if (!(referenceNode instanceof HTMLElement) || !(referenceNode.parentElement instanceof HTMLElement)) {
    throw new Error("target and element must be a node");
  }
  referenceNode.parentElement.insertBefore(newElement, position === "before" ? referenceNode : referenceNode.nextElementSibling);
};
var insertBefore = function(target, element) {
  return insertNode(target, element, "before");
};
var insertAfter = function(target, element) {
  return insertNode(target, element, "after");
};
var serialize = function(sortableContainer, customItemSerializer, customContainerSerializer) {
  if (customItemSerializer === void 0) {
    customItemSerializer = function(serializedItem, sortableContainer2) {
      return serializedItem;
    };
  }
  if (customContainerSerializer === void 0) {
    customContainerSerializer = function(serializedContainer) {
      return serializedContainer;
    };
  }
  if (!(sortableContainer instanceof HTMLElement) || !sortableContainer.isSortable === true) {
    throw new Error("You need to provide a sortableContainer to be serialized.");
  }
  if (typeof customItemSerializer !== "function" || typeof customContainerSerializer !== "function") {
    throw new Error("You need to provide a valid serializer for items and the container.");
  }
  var options = addData(sortableContainer, "opts");
  var item = options.items;
  var items = filter(sortableContainer.children, item);
  var serializedItems = items.map(function(item2) {
    return {
      parent: sortableContainer,
      node: item2,
      html: item2.outerHTML,
      index: getIndex(item2, items)
    };
  });
  var container = {
    node: sortableContainer,
    itemCount: serializedItems.length
  };
  return {
    container: customContainerSerializer(container),
    items: serializedItems.map(function(item2) {
      return customItemSerializer(item2, sortableContainer);
    })
  };
};
var makePlaceholder = function(sortableElement, placeholder, placeholderClass) {
  var _a;
  if (placeholderClass === void 0) {
    placeholderClass = "sortable-placeholder";
  }
  if (!(sortableElement instanceof HTMLElement)) {
    throw new Error("You must provide a valid element as a sortable.");
  }
  if (!(placeholder instanceof HTMLElement) && placeholder !== void 0) {
    throw new Error("You must provide a valid element as a placeholder or set ot to undefined.");
  }
  if (placeholder === void 0) {
    if (["UL", "OL"].includes(sortableElement.tagName)) {
      placeholder = document.createElement("li");
    } else if (["TABLE", "TBODY"].includes(sortableElement.tagName)) {
      placeholder = document.createElement("tr");
      placeholder.innerHTML = '<td colspan="100"></td>';
    } else {
      placeholder = document.createElement("div");
    }
  }
  if (typeof placeholderClass === "string") {
    (_a = placeholder.classList).add.apply(_a, placeholderClass.split(" "));
  }
  return placeholder;
};
var getElementHeight = function(element) {
  if (!(element instanceof HTMLElement)) {
    throw new Error("You must provide a valid dom element");
  }
  var style = window.getComputedStyle(element);
  if (style.getPropertyValue("box-sizing") === "border-box") {
    return parseInt(style.getPropertyValue("height"), 10);
  }
  return ["height", "padding-top", "padding-bottom"].map(function(key) {
    var int = parseInt(style.getPropertyValue(key), 10);
    return isNaN(int) ? 0 : int;
  }).reduce(function(sum, value) {
    return sum + value;
  });
};
var getElementWidth = function(element) {
  if (!(element instanceof HTMLElement)) {
    throw new Error("You must provide a valid dom element");
  }
  var style = window.getComputedStyle(element);
  return ["width", "padding-left", "padding-right"].map(function(key) {
    var int = parseInt(style.getPropertyValue(key), 10);
    return isNaN(int) ? 0 : int;
  }).reduce(function(sum, value) {
    return sum + value;
  });
};
var getHandles = function(items, selector) {
  if (!(items instanceof Array)) {
    throw new Error("You must provide a Array of HTMLElements to be filtered.");
  }
  if (typeof selector !== "string") {
    return items;
  }
  return items.filter(function(item) {
    return item.querySelector(selector) instanceof HTMLElement || item.shadowRoot && item.shadowRoot.querySelector(selector) instanceof HTMLElement;
  }).map(function(item) {
    return item.querySelector(selector) || item.shadowRoot && item.shadowRoot.querySelector(selector);
  });
};
var getEventTarget = function(event) {
  return event.composedPath && event.composedPath()[0] || event.target;
};
var defaultDragImage = function(draggedElement, elementOffset, event) {
  return {
    element: draggedElement,
    posX: event.pageX - elementOffset.left,
    posY: event.pageY - elementOffset.top
  };
};
var setDragImage = function(event, draggedElement, customDragImage) {
  if (!(event instanceof Event)) {
    throw new Error("setDragImage requires a DragEvent as the first argument.");
  }
  if (!(draggedElement instanceof HTMLElement)) {
    throw new Error("setDragImage requires the dragged element as the second argument.");
  }
  if (!customDragImage) {
    customDragImage = defaultDragImage;
  }
  if (event.dataTransfer && event.dataTransfer.setDragImage) {
    var elementOffset = offset(draggedElement);
    var dragImage = customDragImage(draggedElement, elementOffset, event);
    if (!(dragImage.element instanceof HTMLElement) || typeof dragImage.posX !== "number" || typeof dragImage.posY !== "number") {
      throw new Error("The customDragImage function you provided must return and object with the properties element[string], posX[integer], posY[integer].");
    }
    event.dataTransfer.effectAllowed = "copyMove";
    event.dataTransfer.setData("text/plain", getEventTarget(event).id);
    event.dataTransfer.setDragImage(dragImage.element, dragImage.posX, dragImage.posY);
  }
};
var listsConnected = function(destination, origin) {
  if (destination.isSortable === true) {
    var acceptFrom = store(destination).getConfig("acceptFrom");
    if (acceptFrom !== null && acceptFrom !== false && typeof acceptFrom !== "string") {
      throw new Error('HTML5Sortable: Wrong argument, "acceptFrom" must be "null", "false", or a valid selector string.');
    }
    if (acceptFrom !== null) {
      return acceptFrom !== false && acceptFrom.split(",").filter(function(sel) {
        return sel.length > 0 && origin.matches(sel);
      }).length > 0;
    }
    if (destination === origin) {
      return true;
    }
    if (store(destination).getConfig("connectWith") !== void 0 && store(destination).getConfig("connectWith") !== null) {
      return store(destination).getConfig("connectWith") === store(origin).getConfig("connectWith");
    }
  }
  return false;
};
var defaultConfiguration = {
  items: null,
  // deprecated
  connectWith: null,
  // deprecated
  disableIEFix: null,
  acceptFrom: null,
  copy: false,
  placeholder: null,
  placeholderClass: "sortable-placeholder",
  draggingClass: "sortable-dragging",
  hoverClass: false,
  dropTargetContainerClass: false,
  debounce: 0,
  throttleTime: 100,
  maxItems: 0,
  itemSerializer: void 0,
  containerSerializer: void 0,
  customDragImage: null,
  orientation: "vertical"
};
function throttle(fn2, threshold) {
  var _this = this;
  if (threshold === void 0) {
    threshold = 250;
  }
  if (typeof fn2 !== "function") {
    throw new Error("You must provide a function as the first argument for throttle.");
  }
  if (typeof threshold !== "number") {
    throw new Error("You must provide a number as the second argument for throttle.");
  }
  var lastEventTimestamp = null;
  return function() {
    var args = [];
    for (var _i2 = 0; _i2 < arguments.length; _i2++) {
      args[_i2] = arguments[_i2];
    }
    var now = Date.now();
    if (lastEventTimestamp === null || now - lastEventTimestamp >= threshold) {
      lastEventTimestamp = now;
      fn2.apply(_this, args);
    }
  };
}
var enableHoverClass = function(sortableContainer, enable) {
  if (typeof store(sortableContainer).getConfig("hoverClass") === "string") {
    var hoverClasses_1 = store(sortableContainer).getConfig("hoverClass").split(" ");
    if (enable === true) {
      addEventListener(sortableContainer, "mousemove", throttle(function(event) {
        if (event.buttons === 0) {
          filter(sortableContainer.children, store(sortableContainer).getConfig("items")).forEach(function(item) {
            var _a, _b;
            if (item === event.target || item.contains(event.target)) {
              (_a = item.classList).add.apply(_a, hoverClasses_1);
            } else {
              (_b = item.classList).remove.apply(_b, hoverClasses_1);
            }
          });
        }
      }, store(sortableContainer).getConfig("throttleTime")));
      addEventListener(sortableContainer, "mouseleave", function() {
        filter(sortableContainer.children, store(sortableContainer).getConfig("items")).forEach(function(item) {
          var _a;
          (_a = item.classList).remove.apply(_a, hoverClasses_1);
        });
      });
    } else {
      removeEventListener(sortableContainer, "mousemove");
      removeEventListener(sortableContainer, "mouseleave");
    }
  }
};
var dragging;
var draggingHeight;
var draggingWidth;
var originContainer;
var originIndex;
var originElementIndex;
var originItemsBeforeUpdate;
var previousContainer;
var destinationItemsBeforeUpdate;
var removeItemEvents = function(items) {
  removeEventListener(items, "dragstart");
  removeEventListener(items, "dragend");
  removeEventListener(items, "dragover");
  removeEventListener(items, "dragenter");
  removeEventListener(items, "drop");
  removeEventListener(items, "mouseenter");
  removeEventListener(items, "mouseleave");
};
var removeContainerEvents = function(originContainer2, previousContainer2) {
  if (originContainer2) {
    removeEventListener(originContainer2, "dragleave");
  }
  if (previousContainer2 && previousContainer2 !== originContainer2) {
    removeEventListener(previousContainer2, "dragleave");
  }
};
var getDragging = function(draggedItem, sortable2) {
  var ditem = draggedItem;
  if (store(sortable2).getConfig("copy") === true) {
    ditem = draggedItem.cloneNode(true);
    addAttribute(ditem, "aria-copied", "true");
    draggedItem.parentElement.appendChild(ditem);
    ditem.style.display = "none";
    ditem.oldDisplay = draggedItem.style.display;
  }
  return ditem;
};
var removeSortableData = function(sortable2) {
  removeData(sortable2);
  removeAttribute(sortable2, "aria-dropeffect");
};
var removeItemData = function(items) {
  removeAttribute(items, "aria-grabbed");
  removeAttribute(items, "aria-copied");
  removeAttribute(items, "draggable");
  removeAttribute(items, "role");
};
function findSortable(element, event) {
  if (event.composedPath) {
    return event.composedPath().find(function(el) {
      return el.isSortable;
    });
  }
  while (element.isSortable !== true) {
    element = element.parentElement;
  }
  return element;
}
function findDragElement(sortableElement, element) {
  var options = addData(sortableElement, "opts");
  var items = filter(sortableElement.children, options.items);
  var itemlist = items.filter(function(ele) {
    return ele.contains(element) || ele.shadowRoot && ele.shadowRoot.contains(element);
  });
  return itemlist.length > 0 ? itemlist[0] : element;
}
var destroySortable = function(sortableElement) {
  var opts = addData(sortableElement, "opts") || {};
  var items = filter(sortableElement.children, opts.items);
  var handles = getHandles(items, opts.handle);
  enableHoverClass(sortableElement, false);
  removeEventListener(sortableElement, "dragover");
  removeEventListener(sortableElement, "dragenter");
  removeEventListener(sortableElement, "dragstart");
  removeEventListener(sortableElement, "dragend");
  removeEventListener(sortableElement, "drop");
  removeSortableData(sortableElement);
  removeEventListener(handles, "mousedown");
  removeItemEvents(items);
  removeItemData(items);
  removeContainerEvents(originContainer, previousContainer);
  sortableElement.isSortable = false;
};
var enableSortable = function(sortableElement) {
  var opts = addData(sortableElement, "opts");
  var items = filter(sortableElement.children, opts.items);
  var handles = getHandles(items, opts.handle);
  addAttribute(sortableElement, "aria-dropeffect", "move");
  addData(sortableElement, "_disabled", "false");
  addAttribute(handles, "draggable", "true");
  enableHoverClass(sortableElement, true);
  if (opts.disableIEFix === false) {
    var spanEl = (document || window.document).createElement("span");
    if (typeof spanEl.dragDrop === "function") {
      addEventListener(handles, "mousedown", function() {
        if (items.indexOf(this) !== -1) {
          this.dragDrop();
        } else {
          var parent = this.parentElement;
          while (items.indexOf(parent) === -1) {
            parent = parent.parentElement;
          }
          parent.dragDrop();
        }
      });
    }
  }
};
var disableSortable = function(sortableElement) {
  var opts = addData(sortableElement, "opts");
  var items = filter(sortableElement.children, opts.items);
  var handles = getHandles(items, opts.handle);
  addAttribute(sortableElement, "aria-dropeffect", "none");
  addData(sortableElement, "_disabled", "true");
  addAttribute(handles, "draggable", "false");
  removeEventListener(handles, "mousedown");
  enableHoverClass(sortableElement, false);
};
var reloadSortable = function(sortableElement) {
  var opts = addData(sortableElement, "opts");
  var items = filter(sortableElement.children, opts.items);
  var handles = getHandles(items, opts.handle);
  addData(sortableElement, "_disabled", "false");
  removeItemEvents(items);
  removeContainerEvents(originContainer, previousContainer);
  removeEventListener(handles, "mousedown");
  removeEventListener(sortableElement, "dragover");
  removeEventListener(sortableElement, "dragenter");
  removeEventListener(sortableElement, "drop");
};
function sortable(sortableElements, options) {
  var method = String(options);
  options = options || {};
  if (typeof sortableElements === "string") {
    sortableElements = document.querySelectorAll(sortableElements);
  }
  if (sortableElements instanceof HTMLElement) {
    sortableElements = [sortableElements];
  }
  sortableElements = Array.prototype.slice.call(sortableElements);
  if (/serialize/.test(method)) {
    return sortableElements.map(function(sortableContainer) {
      var opts = addData(sortableContainer, "opts");
      return serialize(sortableContainer, opts.itemSerializer, opts.containerSerializer);
    });
  }
  sortableElements.forEach(function(sortableElement) {
    if (/enable|disable|destroy/.test(method)) {
      return sortable[method](sortableElement);
    }
    ["connectWith", "disableIEFix"].forEach(function(configKey) {
      if (Object.prototype.hasOwnProperty.call(options, configKey) && options[configKey] !== null) {
        console.warn('HTML5Sortable: You are using the deprecated configuration "' + configKey + '". This will be removed in an upcoming version, make sure to migrate to the new options when updating.');
      }
    });
    options = Object.assign({}, defaultConfiguration, store(sortableElement).config, options);
    store(sortableElement).config = options;
    addData(sortableElement, "opts", options);
    sortableElement.isSortable = true;
    reloadSortable(sortableElement);
    var listItems = filter(sortableElement.children, options.items);
    var customPlaceholder;
    if (options.placeholder !== null && options.placeholder !== void 0) {
      var tempContainer = document.createElement(sortableElement.tagName);
      if (options.placeholder instanceof HTMLElement) {
        tempContainer.appendChild(options.placeholder);
      } else {
        tempContainer.innerHTML = options.placeholder;
      }
      customPlaceholder = tempContainer.children[0];
    }
    store(sortableElement).placeholder = makePlaceholder(sortableElement, customPlaceholder, options.placeholderClass);
    addData(sortableElement, "items", options.items);
    if (options.acceptFrom) {
      addData(sortableElement, "acceptFrom", options.acceptFrom);
    } else if (options.connectWith) {
      addData(sortableElement, "connectWith", options.connectWith);
    }
    enableSortable(sortableElement);
    addAttribute(listItems, "role", "option");
    addAttribute(listItems, "aria-grabbed", "false");
    addEventListener(sortableElement, "dragstart", function(e2) {
      var target = getEventTarget(e2);
      if (target.isSortable === true) {
        return;
      }
      e2.stopImmediatePropagation();
      if (options.handle && !target.matches(options.handle) || target.getAttribute("draggable") === "false") {
        return;
      }
      var sortableContainer = findSortable(target, e2);
      var dragItem = findDragElement(sortableContainer, target);
      originItemsBeforeUpdate = filter(sortableContainer.children, options.items);
      originIndex = originItemsBeforeUpdate.indexOf(dragItem);
      originElementIndex = getIndex(dragItem, sortableContainer.children);
      originContainer = sortableContainer;
      setDragImage(e2, dragItem, options.customDragImage);
      draggingHeight = getElementHeight(dragItem);
      draggingWidth = getElementWidth(dragItem);
      dragItem.classList.add(options.draggingClass);
      dragging = getDragging(dragItem, sortableContainer);
      addAttribute(dragging, "aria-grabbed", "true");
      sortableContainer.dispatchEvent(new CustomEvent("sortstart", {
        detail: {
          origin: {
            elementIndex: originElementIndex,
            index: originIndex,
            container: originContainer
          },
          item: dragging,
          originalTarget: target
        }
      }));
    });
    addEventListener(sortableElement, "dragenter", function(e2) {
      var target = getEventTarget(e2);
      var sortableContainer = findSortable(target, e2);
      if (sortableContainer && sortableContainer !== previousContainer) {
        destinationItemsBeforeUpdate = filter(sortableContainer.children, addData(sortableContainer, "items")).filter(function(item) {
          return item !== store(sortableElement).placeholder;
        });
        if (options.dropTargetContainerClass) {
          sortableContainer.classList.add(options.dropTargetContainerClass);
        }
        sortableContainer.dispatchEvent(new CustomEvent("sortenter", {
          detail: {
            origin: {
              elementIndex: originElementIndex,
              index: originIndex,
              container: originContainer
            },
            destination: {
              container: sortableContainer,
              itemsBeforeUpdate: destinationItemsBeforeUpdate
            },
            item: dragging,
            originalTarget: target
          }
        }));
        addEventListener(sortableContainer, "dragleave", function(e3) {
          var outTarget = e3.relatedTarget || e3.fromElement;
          if (!e3.currentTarget.contains(outTarget)) {
            if (options.dropTargetContainerClass) {
              sortableContainer.classList.remove(options.dropTargetContainerClass);
            }
            sortableContainer.dispatchEvent(new CustomEvent("sortleave", {
              detail: {
                origin: {
                  elementIndex: originElementIndex,
                  index: originIndex,
                  container: sortableContainer
                },
                item: dragging,
                originalTarget: target
              }
            }));
          }
        });
      }
      previousContainer = sortableContainer;
    });
    addEventListener(sortableElement, "dragend", function(e2) {
      if (!dragging) {
        return;
      }
      dragging.classList.remove(options.draggingClass);
      addAttribute(dragging, "aria-grabbed", "false");
      if (dragging.getAttribute("aria-copied") === "true" && addData(dragging, "dropped") !== "true") {
        dragging.remove();
      }
      if (dragging.oldDisplay !== void 0) {
        dragging.style.display = dragging.oldDisplay;
        delete dragging.oldDisplay;
      }
      var visiblePlaceholder = Array.from(stores.values()).map(function(data) {
        return data.placeholder;
      }).filter(function(placeholder) {
        return placeholder instanceof HTMLElement;
      }).filter(isInDom)[0];
      if (visiblePlaceholder) {
        visiblePlaceholder.remove();
      }
      sortableElement.dispatchEvent(new CustomEvent("sortstop", {
        detail: {
          origin: {
            elementIndex: originElementIndex,
            index: originIndex,
            container: originContainer
          },
          item: dragging
        }
      }));
      previousContainer = null;
      dragging = null;
      draggingHeight = null;
      draggingWidth = null;
    });
    addEventListener(sortableElement, "drop", function(e2) {
      if (!listsConnected(sortableElement, dragging.parentElement)) {
        return;
      }
      e2.preventDefault();
      e2.stopPropagation();
      addData(dragging, "dropped", "true");
      var visiblePlaceholder = Array.from(stores.values()).map(function(data) {
        return data.placeholder;
      }).filter(function(placeholder2) {
        return placeholder2 instanceof HTMLElement;
      }).filter(isInDom)[0];
      if (visiblePlaceholder) {
        visiblePlaceholder.replaceWith(dragging);
        if (dragging.oldDisplay !== void 0) {
          dragging.style.display = dragging.oldDisplay;
          delete dragging.oldDisplay;
        }
      } else {
        addData(dragging, "dropped", "false");
        return;
      }
      sortableElement.dispatchEvent(new CustomEvent("sortstop", {
        detail: {
          origin: {
            elementIndex: originElementIndex,
            index: originIndex,
            container: originContainer
          },
          item: dragging
        }
      }));
      var placeholder = store(sortableElement).placeholder;
      var originItems = filter(originContainer.children, options.items).filter(function(item) {
        return item !== placeholder;
      });
      var destinationContainer = this.isSortable === true ? this : this.parentElement;
      var destinationItems = filter(destinationContainer.children, addData(destinationContainer, "items")).filter(function(item) {
        return item !== placeholder;
      });
      var destinationElementIndex = getIndex(dragging, Array.from(dragging.parentElement.children).filter(function(item) {
        return item !== placeholder;
      }));
      var destinationIndex = getIndex(dragging, destinationItems);
      if (options.dropTargetContainerClass) {
        destinationContainer.classList.remove(options.dropTargetContainerClass);
      }
      if (originElementIndex !== destinationElementIndex || originContainer !== destinationContainer) {
        sortableElement.dispatchEvent(new CustomEvent("sortupdate", {
          detail: {
            origin: {
              elementIndex: originElementIndex,
              index: originIndex,
              container: originContainer,
              itemsBeforeUpdate: originItemsBeforeUpdate,
              items: originItems
            },
            destination: {
              index: destinationIndex,
              elementIndex: destinationElementIndex,
              container: destinationContainer,
              itemsBeforeUpdate: destinationItemsBeforeUpdate,
              items: destinationItems
            },
            item: dragging
          }
        }));
      }
    });
    var debouncedDragOverEnter = debounce(function(sortableElement2, element, pageX, pageY) {
      if (!dragging) {
        return;
      }
      if (options.forcePlaceholderSize) {
        store(sortableElement2).placeholder.style.height = draggingHeight + "px";
        store(sortableElement2).placeholder.style.width = draggingWidth + "px";
      }
      if (Array.from(sortableElement2.children).indexOf(element) > -1) {
        var thisHeight = getElementHeight(element);
        var thisWidth = getElementWidth(element);
        var placeholderIndex = getIndex(store(sortableElement2).placeholder, element.parentElement.children);
        var thisIndex = getIndex(element, element.parentElement.children);
        if (thisHeight > draggingHeight || thisWidth > draggingWidth) {
          var deadZoneVertical = thisHeight - draggingHeight;
          var deadZoneHorizontal = thisWidth - draggingWidth;
          var offsetTop = offset(element).top;
          var offsetLeft = offset(element).left;
          if (placeholderIndex < thisIndex && (options.orientation === "vertical" && pageY < offsetTop || options.orientation === "horizontal" && pageX < offsetLeft)) {
            return;
          }
          if (placeholderIndex > thisIndex && (options.orientation === "vertical" && pageY > offsetTop + thisHeight - deadZoneVertical || options.orientation === "horizontal" && pageX > offsetLeft + thisWidth - deadZoneHorizontal)) {
            return;
          }
        }
        if (dragging.oldDisplay === void 0) {
          dragging.oldDisplay = dragging.style.display;
        }
        if (dragging.style.display !== "none") {
          dragging.style.display = "none";
        }
        var placeAfter = false;
        try {
          var elementMiddleVertical = offset(element).top + element.offsetHeight / 2;
          var elementMiddleHorizontal = offset(element).left + element.offsetWidth / 2;
          placeAfter = options.orientation === "vertical" && pageY >= elementMiddleVertical || options.orientation === "horizontal" && pageX >= elementMiddleHorizontal;
        } catch (e2) {
          placeAfter = placeholderIndex < thisIndex;
        }
        if (placeAfter) {
          insertAfter(element, store(sortableElement2).placeholder);
        } else {
          insertBefore(element, store(sortableElement2).placeholder);
        }
        Array.from(stores.values()).filter(function(data) {
          return data.placeholder !== void 0;
        }).forEach(function(data) {
          if (data.placeholder !== store(sortableElement2).placeholder) {
            data.placeholder.remove();
          }
        });
      } else {
        var placeholders = Array.from(stores.values()).filter(function(data) {
          return data.placeholder !== void 0;
        }).map(function(data) {
          return data.placeholder;
        });
        if (placeholders.indexOf(element) === -1 && sortableElement2 === element && !filter(element.children, options.items).length) {
          placeholders.forEach(function(element2) {
            return element2.remove();
          });
          element.appendChild(store(sortableElement2).placeholder);
        }
      }
    }, options.debounce);
    var onDragOverEnter = function(e2) {
      var element = e2.target;
      var sortableElement2 = element.isSortable === true ? element : findSortable(element, e2);
      element = findDragElement(sortableElement2, element);
      if (!dragging || !listsConnected(sortableElement2, dragging.parentElement) || addData(sortableElement2, "_disabled") === "true") {
        return;
      }
      var options2 = addData(sortableElement2, "opts");
      if (parseInt(options2.maxItems) && filter(sortableElement2.children, addData(sortableElement2, "items")).length > parseInt(options2.maxItems) && dragging.parentElement !== sortableElement2) {
        return;
      }
      e2.preventDefault();
      e2.stopPropagation();
      e2.dataTransfer.dropEffect = store(sortableElement2).getConfig("copy") === true ? "copy" : "move";
      debouncedDragOverEnter(sortableElement2, element, e2.pageX, e2.pageY);
    };
    addEventListener(listItems.concat(sortableElement), "dragover", onDragOverEnter);
    addEventListener(listItems.concat(sortableElement), "dragenter", onDragOverEnter);
  });
  return sortableElements;
}
sortable.destroy = function(sortableElement) {
  destroySortable(sortableElement);
};
sortable.enable = function(sortableElement) {
  enableSortable(sortableElement);
};
sortable.disable = function(sortableElement) {
  disableSortable(sortableElement);
};
sortable.__testing = {
  // add internal methods here for testing purposes
  data: addData,
  removeItemEvents,
  removeItemData,
  removeSortableData,
  removeContainerEvents
};
var html5sortable_cjs = sortable;
function createComputedFactory(update) {
  return (getFn, setFn) => {
    return computed({
      get: () => getFn(),
      set: (val) => {
        val = val === "" ? void 0 : val;
        update(setFn(val));
      }
    });
  };
}
function updateSortableEnvs(options) {
  setTimeout(() => {
    html5sortable_cjs(".env-sortable", options);
  }, 0);
}
function updateSortableProjects(options) {
  setTimeout(() => {
    html5sortable_cjs(".project-sortable", options);
  }, 0);
}
function baseSlice$1(array, start, end) {
  var index = -1, length = array.length;
  if (start < 0) {
    start = -start > length ? 0 : length + start;
  }
  end = end > length ? length : end;
  if (end < 0) {
    end += length;
  }
  length = start > end ? 0 : end - start >>> 0;
  start >>>= 0;
  var result = Array(length);
  while (++index < length) {
    result[index] = array[index + start];
  }
  return result;
}
var _baseSlice = baseSlice$1;
var baseSlice = _baseSlice;
function castSlice$1(array, start, end) {
  var length = array.length;
  end = end === void 0 ? length : end;
  return !start && end >= length ? array : baseSlice(array, start, end);
}
var _castSlice = castSlice$1;
var rsAstralRange$1 = "\\ud800-\\udfff", rsComboMarksRange$1 = "\\u0300-\\u036f", reComboHalfMarksRange$1 = "\\ufe20-\\ufe2f", rsComboSymbolsRange$1 = "\\u20d0-\\u20ff", rsComboRange$1 = rsComboMarksRange$1 + reComboHalfMarksRange$1 + rsComboSymbolsRange$1, rsVarRange$1 = "\\ufe0e\\ufe0f";
var rsZWJ$1 = "\\u200d";
var reHasUnicode = RegExp("[" + rsZWJ$1 + rsAstralRange$1 + rsComboRange$1 + rsVarRange$1 + "]");
function hasUnicode$2(string) {
  return reHasUnicode.test(string);
}
var _hasUnicode = hasUnicode$2;
function asciiToArray$1(string) {
  return string.split("");
}
var _asciiToArray = asciiToArray$1;
var rsAstralRange = "\\ud800-\\udfff", rsComboMarksRange = "\\u0300-\\u036f", reComboHalfMarksRange = "\\ufe20-\\ufe2f", rsComboSymbolsRange = "\\u20d0-\\u20ff", rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange, rsVarRange = "\\ufe0e\\ufe0f";
var rsAstral = "[" + rsAstralRange + "]", rsCombo = "[" + rsComboRange + "]", rsFitz = "\\ud83c[\\udffb-\\udfff]", rsModifier = "(?:" + rsCombo + "|" + rsFitz + ")", rsNonAstral = "[^" + rsAstralRange + "]", rsRegional = "(?:\\ud83c[\\udde6-\\uddff]){2}", rsSurrPair = "[\\ud800-\\udbff][\\udc00-\\udfff]", rsZWJ = "\\u200d";
var reOptMod = rsModifier + "?", rsOptVar = "[" + rsVarRange + "]?", rsOptJoin = "(?:" + rsZWJ + "(?:" + [rsNonAstral, rsRegional, rsSurrPair].join("|") + ")" + rsOptVar + reOptMod + ")*", rsSeq = rsOptVar + reOptMod + rsOptJoin, rsSymbol = "(?:" + [rsNonAstral + rsCombo + "?", rsCombo, rsRegional, rsSurrPair, rsAstral].join("|") + ")";
var reUnicode = RegExp(rsFitz + "(?=" + rsFitz + ")|" + rsSymbol + rsSeq, "g");
function unicodeToArray$1(string) {
  return string.match(reUnicode) || [];
}
var _unicodeToArray = unicodeToArray$1;
var asciiToArray = _asciiToArray, hasUnicode$1 = _hasUnicode, unicodeToArray = _unicodeToArray;
function stringToArray$1(string) {
  return hasUnicode$1(string) ? unicodeToArray(string) : asciiToArray(string);
}
var _stringToArray = stringToArray$1;
var freeGlobal$1 = typeof commonjsGlobal == "object" && commonjsGlobal && commonjsGlobal.Object === Object && commonjsGlobal;
var _freeGlobal = freeGlobal$1;
var freeGlobal = _freeGlobal;
var freeSelf = typeof self == "object" && self && self.Object === Object && self;
var root$1 = freeGlobal || freeSelf || Function("return this")();
var _root = root$1;
var root = _root;
var Symbol$4 = root.Symbol;
var _Symbol = Symbol$4;
function arrayMap$1(array, iteratee) {
  var index = -1, length = array == null ? 0 : array.length, result = Array(length);
  while (++index < length) {
    result[index] = iteratee(array[index], index, array);
  }
  return result;
}
var _arrayMap = arrayMap$1;
var isArray$1 = Array.isArray;
var isArray_1 = isArray$1;
var Symbol$3 = _Symbol;
var objectProto$1 = Object.prototype;
var hasOwnProperty = objectProto$1.hasOwnProperty;
var nativeObjectToString$1 = objectProto$1.toString;
var symToStringTag$1 = Symbol$3 ? Symbol$3.toStringTag : void 0;
function getRawTag$1(value) {
  var isOwn = hasOwnProperty.call(value, symToStringTag$1), tag = value[symToStringTag$1];
  try {
    value[symToStringTag$1] = void 0;
    var unmasked = true;
  } catch (e2) {
  }
  var result = nativeObjectToString$1.call(value);
  if (unmasked) {
    if (isOwn) {
      value[symToStringTag$1] = tag;
    } else {
      delete value[symToStringTag$1];
    }
  }
  return result;
}
var _getRawTag = getRawTag$1;
var objectProto = Object.prototype;
var nativeObjectToString = objectProto.toString;
function objectToString$1(value) {
  return nativeObjectToString.call(value);
}
var _objectToString = objectToString$1;
var Symbol$2 = _Symbol, getRawTag = _getRawTag, objectToString = _objectToString;
var nullTag = "[object Null]", undefinedTag = "[object Undefined]";
var symToStringTag = Symbol$2 ? Symbol$2.toStringTag : void 0;
function baseGetTag$1(value) {
  if (value == null) {
    return value === void 0 ? undefinedTag : nullTag;
  }
  return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
}
var _baseGetTag = baseGetTag$1;
function isObjectLike$1(value) {
  return value != null && typeof value == "object";
}
var isObjectLike_1 = isObjectLike$1;
var baseGetTag = _baseGetTag, isObjectLike = isObjectLike_1;
var symbolTag = "[object Symbol]";
function isSymbol$1(value) {
  return typeof value == "symbol" || isObjectLike(value) && baseGetTag(value) == symbolTag;
}
var isSymbol_1 = isSymbol$1;
var Symbol$1 = _Symbol, arrayMap = _arrayMap, isArray = isArray_1, isSymbol = isSymbol_1;
var INFINITY = 1 / 0;
var symbolProto = Symbol$1 ? Symbol$1.prototype : void 0, symbolToString = symbolProto ? symbolProto.toString : void 0;
function baseToString$1(value) {
  if (typeof value == "string") {
    return value;
  }
  if (isArray(value)) {
    return arrayMap(value, baseToString$1) + "";
  }
  if (isSymbol(value)) {
    return symbolToString ? symbolToString.call(value) : "";
  }
  var result = value + "";
  return result == "0" && 1 / value == -INFINITY ? "-0" : result;
}
var _baseToString = baseToString$1;
var baseToString = _baseToString;
function toString$1(value) {
  return value == null ? "" : baseToString(value);
}
var toString_1 = toString$1;
var castSlice = _castSlice, hasUnicode = _hasUnicode, stringToArray = _stringToArray, toString = toString_1;
function createCaseFirst$1(methodName) {
  return function(string) {
    string = toString(string);
    var strSymbols = hasUnicode(string) ? stringToArray(string) : void 0;
    var chr = strSymbols ? strSymbols[0] : string.charAt(0);
    var trailing = strSymbols ? castSlice(strSymbols, 1).join("") : string.slice(1);
    return chr[methodName]() + trailing;
  };
}
var _createCaseFirst = createCaseFirst$1;
var createCaseFirst = _createCaseFirst;
var upperFirst = createCaseFirst("toUpperCase");
var upperFirst_1 = upperFirst;
const EditorFormRibbon_vue_vue_type_style_index_0_scoped_4c229450_lang = "";
const _sfc_main$h = defineComponent({
  name: "EditorFormRibbon",
  components: { ColorPicker },
  props: {
    env: {
      type: Object,
      default: void 0
    },
    options: {
      type: Object,
      required: true
    }
  },
  emits: ["update:options"],
  setup(props, context) {
    const isDefaulted = (key) => {
      return props.env ? props.env.ribbonOptions ? props.env.ribbonOptions[key] === void 0 : true : false;
    };
    const updateComputed = (data) => context.emit("update:options", data);
    const createComputed = createComputedFactory(updateComputed);
    const displayRibbon = createComputed(
      () => props.options.displayRibbon,
      (val) => ({ displayRibbon: val })
    );
    const ribbonOptions = ["color", "backgroundColor", "position", "type"].reduce((acc, key) => {
      acc[`ribbon${upperFirst_1(key)}`] = createComputed(
        () => props.options.ribbonOptions[key],
        (val) => ({ ribbonOptions: { [key]: val } })
      );
      return acc;
    }, {});
    return {
      displayRibbon,
      ...ribbonOptions,
      isDefaulted,
      updateComputed
    };
  }
});
const _withScopeId$8 = (n2) => (pushScopeId("data-v-4c229450"), n2 = n2(), popScopeId(), n2);
const _hoisted_1$h = ["id"];
const _hoisted_2$h = ["for"];
const _hoisted_3$h = { class: "form-options" };
const _hoisted_4$7 = {
  class: "label-set",
  "ribbon-bg-color": ""
};
const _hoisted_5$5 = /* @__PURE__ */ _withScopeId$8(() => /* @__PURE__ */ createBaseVNode("span", null, "Background Color", -1));
const _hoisted_6$4 = {
  class: "label-set",
  "ribbon-text-color": ""
};
const _hoisted_7$4 = /* @__PURE__ */ _withScopeId$8(() => /* @__PURE__ */ createBaseVNode("span", null, "Text Color", -1));
const _hoisted_8$4 = ["for"];
const _hoisted_9$3 = ["id"];
const _hoisted_10$2 = /* @__PURE__ */ _withScopeId$8(() => /* @__PURE__ */ createBaseVNode("option", { value: "left" }, "left", -1));
const _hoisted_11$2 = /* @__PURE__ */ _withScopeId$8(() => /* @__PURE__ */ createBaseVNode("option", { value: "right" }, "right", -1));
const _hoisted_12$2 = [
  _hoisted_10$2,
  _hoisted_11$2
];
const _hoisted_13$2 = ["for"];
const _hoisted_14$2 = ["id"];
const _hoisted_15$2 = /* @__PURE__ */ _withScopeId$8(() => /* @__PURE__ */ createBaseVNode("option", { value: "corner-ribbon" }, "Corner", -1));
const _hoisted_16$2 = /* @__PURE__ */ _withScopeId$8(() => /* @__PURE__ */ createBaseVNode("option", { value: "square-ribbon" }, "Square", -1));
const _hoisted_17$2 = [
  _hoisted_15$2,
  _hoisted_16$2
];
function _sfc_render$h(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_ColorPicker = resolveComponent("ColorPicker");
  return openBlock(), createElementBlock("fieldset", {
    class: normalizeClass({ "has-env": !!_ctx.env })
  }, [
    createBaseVNode("div", {
      class: normalizeClass(["label-set", { defaulted: _ctx.env ? _ctx.env.displayRibbon === void 0 : false }]),
      "display-ribbon": ""
    }, [
      withDirectives(createBaseVNode("input", {
        id: _ctx.$id("display-ribbon"),
        type: "checkbox",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => _ctx.displayRibbon = $event)
      }, null, 8, _hoisted_1$h), [
        [vModelCheckbox, _ctx.displayRibbon]
      ]),
      createBaseVNode("label", {
        for: _ctx.$id("display-ribbon")
      }, "Ribbon", 8, _hoisted_2$h)
    ], 2),
    createBaseVNode("div", _hoisted_3$h, [
      createBaseVNode("div", _hoisted_4$7, [
        createBaseVNode("label", {
          class: normalizeClass(["color-selector", {
            defaulted: _ctx.isDefaulted("backgroundColor")
          }])
        }, [
          createVNode(_component_ColorPicker, {
            color: _ctx.ribbonBackgroundColor,
            "onUpdate:color": _cache[1] || (_cache[1] = ($event) => _ctx.ribbonBackgroundColor = $event)
          }, null, 8, ["color"]),
          _hoisted_5$5
        ], 2)
      ]),
      createBaseVNode("div", _hoisted_6$4, [
        createBaseVNode("label", {
          class: normalizeClass(["color-selector", {
            defaulted: _ctx.isDefaulted("color")
          }])
        }, [
          createVNode(_component_ColorPicker, {
            color: _ctx.ribbonColor,
            "onUpdate:color": _cache[2] || (_cache[2] = ($event) => _ctx.ribbonColor = $event)
          }, null, 8, ["color"]),
          _hoisted_7$4
        ], 2)
      ]),
      createBaseVNode("div", {
        class: normalizeClass(["label-set input-selector", {
          defaulted: _ctx.isDefaulted("position")
        }]),
        "ribbon-position": ""
      }, [
        createBaseVNode("label", {
          for: _ctx.$id("ribbon-position")
        }, "Position", 8, _hoisted_8$4),
        withDirectives(createBaseVNode("select", {
          id: _ctx.$id("ribbon-position"),
          "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => _ctx.ribbonPosition = $event)
        }, _hoisted_12$2, 8, _hoisted_9$3), [
          [vModelSelect, _ctx.ribbonPosition]
        ])
      ], 2),
      createBaseVNode("div", {
        class: normalizeClass(["label-set input-selector", {
          defaulted: _ctx.isDefaulted("type")
        }]),
        "ribbon-type": ""
      }, [
        createBaseVNode("label", {
          for: _ctx.$id("ribbon-type")
        }, "Type", 8, _hoisted_13$2),
        withDirectives(createBaseVNode("select", {
          id: _ctx.$id("ribbon-type"),
          "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => _ctx.ribbonType = $event)
        }, _hoisted_17$2, 8, _hoisted_14$2), [
          [vModelSelect, _ctx.ribbonType]
        ])
      ], 2)
    ])
  ], 2);
}
const EditorFormRibbon = /* @__PURE__ */ _export_sfc(_sfc_main$h, [["render", _sfc_render$h], ["__scopeId", "data-v-4c229450"]]);
const EditorFormBadge_vue_vue_type_style_index_0_scoped_67cb7f14_lang = "";
const _sfc_main$g = defineComponent({
  name: "EditorFormBadge",
  components: { ColorPicker },
  props: {
    env: {
      type: Object,
      default: void 0
    },
    options: {
      type: Object,
      required: true
    }
  },
  emits: ["update:options"],
  setup(props, context) {
    const isBadgeDefaultBgColor = computed(() => {
      const { env } = props;
      if (!env) {
        return false;
      }
      const { badgeOptions } = env;
      return badgeOptions ? badgeOptions.backgroundColor === void 0 : false;
    });
    const emitUpdate = (data) => context.emit("update:options", data);
    const createComputed = createComputedFactory(emitUpdate);
    const displayBadge = createComputed(
      () => props.options.displayBadge,
      (val) => ({ displayBadge: val })
    );
    const badgeBgColor = createComputed(
      () => props.options.badgeOptions.backgroundColor,
      (val) => ({ badgeOptions: { backgroundColor: val } })
    );
    return {
      isBadgeDefaultBgColor,
      displayBadge,
      badgeBgColor
    };
  }
});
const _withScopeId$7 = (n2) => (pushScopeId("data-v-67cb7f14"), n2 = n2(), popScopeId(), n2);
const _hoisted_1$g = ["id"];
const _hoisted_2$g = ["for"];
const _hoisted_3$g = {
  class: "label-set",
  "badge-bg-color": ""
};
const _hoisted_4$6 = /* @__PURE__ */ _withScopeId$7(() => /* @__PURE__ */ createBaseVNode("span", null, "Background Color", -1));
function _sfc_render$g(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_ColorPicker = resolveComponent("ColorPicker");
  return openBlock(), createElementBlock("fieldset", {
    class: normalizeClass({ "has-env": !!_ctx.env })
  }, [
    createBaseVNode("div", {
      class: normalizeClass(["label-set", { defaulted: _ctx.env ? _ctx.env.displayBadge === void 0 : false }]),
      "display-badge": ""
    }, [
      withDirectives(createBaseVNode("input", {
        id: _ctx.$id("display-badge"),
        type: "checkbox",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => _ctx.displayBadge = $event)
      }, null, 8, _hoisted_1$g), [
        [vModelCheckbox, _ctx.displayBadge]
      ]),
      createBaseVNode("label", {
        for: _ctx.$id("display-badge")
      }, "Badge", 8, _hoisted_2$g)
    ], 2),
    createBaseVNode("div", _hoisted_3$g, [
      createBaseVNode("label", {
        class: normalizeClass(["badge-bg-color", { defaulted: _ctx.isBadgeDefaultBgColor }])
      }, [
        createVNode(_component_ColorPicker, {
          color: _ctx.badgeBgColor,
          "onUpdate:color": _cache[1] || (_cache[1] = ($event) => _ctx.badgeBgColor = $event)
        }, null, 8, ["color"]),
        _hoisted_4$6
      ], 2)
    ])
  ], 2);
}
const EditorFormBadge = /* @__PURE__ */ _export_sfc(_sfc_main$g, [["render", _sfc_render$g], ["__scopeId", "data-v-67cb7f14"]]);
const ConfirmationDeleteButton_vue_vue_type_style_index_0_scoped_c079f04f_lang = "";
const _sfc_main$f = defineComponent({
  name: "ConfirmationDeleteButton",
  emits: ["update:modelValue", "action"],
  components: {
    CoreButton
  },
  props: {
    modelValue: {
      type: Boolean,
      default: false
    }
  },
  setup(props, context) {
    let hideTimer = null;
    const hideDelayInSecond = 5e3;
    const hideDelay = () => {
      if (!hideTimer) {
        hideTimer = setTimeout(() => {
          hide();
          hideTimer = null;
        }, hideDelayInSecond);
      }
    };
    const stopHide = () => {
      if (hideTimer) {
        clearTimeout(hideTimer);
        hideTimer = null;
      }
    };
    const deleteConfirm = () => {
      hide();
      setTimeout(() => {
        context.emit("action");
      });
    };
    const show = () => emitUpdate(true);
    const hide = () => emitUpdate(false);
    const emitUpdate = (value) => context.emit("update:modelValue", value);
    return {
      show,
      hide,
      hideDelay,
      stopHide,
      deleteConfirm
    };
  }
});
const _withScopeId$6 = (n2) => (pushScopeId("data-v-c079f04f"), n2 = n2(), popScopeId(), n2);
const _hoisted_1$f = {
  key: 0,
  class: "buttons-wrapper"
};
const _hoisted_2$f = {
  key: 1,
  class: "delete-confirm"
};
const _hoisted_3$f = /* @__PURE__ */ _withScopeId$6(() => /* @__PURE__ */ createBaseVNode("span", { class: "confirm-title" }, " Are you sure ? ", -1));
function _sfc_render$f(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_CoreButton = resolveComponent("CoreButton");
  return openBlock(), createElementBlock("div", {
    onMouseleave: _cache[0] || (_cache[0] = (...args) => _ctx.hideDelay && _ctx.hideDelay(...args)),
    onMouseenter: _cache[1] || (_cache[1] = (...args) => _ctx.stopHide && _ctx.stopHide(...args))
  }, [
    createVNode(Transition, {
      name: "fade",
      mode: "out-in"
    }, {
      default: withCtx(() => [
        !_ctx.modelValue ? (openBlock(), createElementBlock("div", _hoisted_1$f, [
          renderSlot(_ctx.$slots, "beforeButton", {}, void 0, true),
          createVNode(_component_CoreButton, {
            elevation: "",
            class: "delete-btn button",
            "icon-name": "DeleteIcon",
            variation: "negative",
            onClick: _ctx.show
          }, {
            default: withCtx(() => [
              createTextVNode(" Delete ")
            ]),
            _: 1
          }, 8, ["onClick"]),
          renderSlot(_ctx.$slots, "afterButton", {}, void 0, true)
        ])) : (openBlock(), createElementBlock("div", _hoisted_2$f, [
          _hoisted_3$f,
          createVNode(_component_CoreButton, {
            class: "delete-confirm-btn button",
            elevation: "",
            variation: "negative",
            onClick: _ctx.deleteConfirm
          }, {
            default: withCtx(() => [
              createTextVNode(" Yes ")
            ]),
            _: 1
          }, 8, ["onClick"]),
          createVNode(_component_CoreButton, {
            class: "button",
            elevation: "",
            ref: "no",
            onClick: _ctx.hide
          }, {
            default: withCtx(() => [
              createTextVNode(" No ")
            ]),
            _: 1
          }, 8, ["onClick"])
        ]))
      ]),
      _: 3
    })
  ], 32);
}
const ConfirmationDeleteButton = /* @__PURE__ */ _export_sfc(_sfc_main$f, [["render", _sfc_render$f], ["__scopeId", "data-v-c079f04f"]]);
/**
  * vee-validate v4.7.4
  * (c) 2023 Abdelrahman Awad
  * @license MIT
  */
function isCallable(fn2) {
  return typeof fn2 === "function";
}
function isNullOrUndefined$1(value) {
  return value === null || value === void 0;
}
const isObject = (obj) => obj !== null && !!obj && typeof obj === "object" && !Array.isArray(obj);
function isIndex(value) {
  return Number(value) >= 0;
}
function toNumber(value) {
  const n2 = parseFloat(value);
  return isNaN(n2) ? value : n2;
}
const RULES = {};
function defineRule(id, validator) {
  guardExtend(id, validator);
  RULES[id] = validator;
}
function resolveRule(id) {
  return RULES[id];
}
function guardExtend(id, validator) {
  if (isCallable(validator)) {
    return;
  }
  throw new Error(`Extension Error: The validator '${id}' must be a function.`);
}
const FormContextKey = Symbol("vee-validate-form");
const FieldContextKey = Symbol("vee-validate-field-instance");
const IS_ABSENT = Symbol("Default empty value");
const isClient = typeof window !== "undefined";
function isLocator(value) {
  return isCallable(value) && !!value.__locatorRef;
}
function isYupValidator(value) {
  return !!value && isCallable(value.validate);
}
function hasCheckedAttr(type) {
  return type === "checkbox" || type === "radio";
}
function isContainerValue(value) {
  return isObject(value) || Array.isArray(value);
}
function isEmptyContainer(value) {
  if (Array.isArray(value)) {
    return value.length === 0;
  }
  return isObject(value) && Object.keys(value).length === 0;
}
function isNotNestedPath(path) {
  return /^\[.+\]$/i.test(path);
}
function isNativeMultiSelect(el) {
  return isNativeSelect(el) && el.multiple;
}
function isNativeSelect(el) {
  return el.tagName === "SELECT";
}
function isNativeMultiSelectNode(tag, attrs) {
  const hasTruthyBindingValue = ![false, null, void 0, 0].includes(attrs.multiple) && !Number.isNaN(attrs.multiple);
  return tag === "select" && "multiple" in attrs && hasTruthyBindingValue;
}
function shouldHaveValueBinding(tag, attrs) {
  return !isNativeMultiSelectNode(tag, attrs) && attrs.type !== "file" && !hasCheckedAttr(attrs.type);
}
function isFormSubmitEvent(evt) {
  return isEvent(evt) && evt.target && "submit" in evt.target;
}
function isEvent(evt) {
  if (!evt) {
    return false;
  }
  if (typeof Event !== "undefined" && isCallable(Event) && evt instanceof Event) {
    return true;
  }
  if (evt && evt.srcElement) {
    return true;
  }
  return false;
}
function isPropPresent(obj, prop) {
  return prop in obj && obj[prop] !== IS_ABSENT;
}
function isEqual(a2, b2) {
  if (a2 === b2)
    return true;
  if (a2 && b2 && typeof a2 === "object" && typeof b2 === "object") {
    if (a2.constructor !== b2.constructor)
      return false;
    var length, i2, keys;
    if (Array.isArray(a2)) {
      length = a2.length;
      if (length != b2.length)
        return false;
      for (i2 = length; i2-- !== 0; )
        if (!isEqual(a2[i2], b2[i2]))
          return false;
      return true;
    }
    if (a2 instanceof Map && b2 instanceof Map) {
      if (a2.size !== b2.size)
        return false;
      for (i2 of a2.entries())
        if (!b2.has(i2[0]))
          return false;
      for (i2 of a2.entries())
        if (!isEqual(i2[1], b2.get(i2[0])))
          return false;
      return true;
    }
    if (isFile(a2) && isFile(b2)) {
      if (a2.size !== b2.size)
        return false;
      if (a2.name !== b2.name)
        return false;
      if (a2.lastModified !== b2.lastModified)
        return false;
      if (a2.type !== b2.type)
        return false;
      return true;
    }
    if (a2 instanceof Set && b2 instanceof Set) {
      if (a2.size !== b2.size)
        return false;
      for (i2 of a2.entries())
        if (!b2.has(i2[0]))
          return false;
      return true;
    }
    if (ArrayBuffer.isView(a2) && ArrayBuffer.isView(b2)) {
      length = a2.length;
      if (length != b2.length)
        return false;
      for (i2 = length; i2-- !== 0; )
        if (a2[i2] !== b2[i2])
          return false;
      return true;
    }
    if (a2.constructor === RegExp)
      return a2.source === b2.source && a2.flags === b2.flags;
    if (a2.valueOf !== Object.prototype.valueOf)
      return a2.valueOf() === b2.valueOf();
    if (a2.toString !== Object.prototype.toString)
      return a2.toString() === b2.toString();
    keys = Object.keys(a2);
    length = keys.length;
    if (length !== Object.keys(b2).length)
      return false;
    for (i2 = length; i2-- !== 0; )
      if (!Object.prototype.hasOwnProperty.call(b2, keys[i2]))
        return false;
    for (i2 = length; i2-- !== 0; ) {
      var key = keys[i2];
      if (!isEqual(a2[key], b2[key]))
        return false;
    }
    return true;
  }
  return a2 !== a2 && b2 !== b2;
}
function isFile(a2) {
  if (!isClient) {
    return false;
  }
  return a2 instanceof File;
}
function set(obj, key, val) {
  if (typeof val.value === "object")
    val.value = klona(val.value);
  if (!val.enumerable || val.get || val.set || !val.configurable || !val.writable || key === "__proto__") {
    Object.defineProperty(obj, key, val);
  } else
    obj[key] = val.value;
}
function klona(x2) {
  if (typeof x2 !== "object")
    return x2;
  var i2 = 0, k2, list, tmp, str = Object.prototype.toString.call(x2);
  if (str === "[object Object]") {
    tmp = Object.create(x2.__proto__ || null);
  } else if (str === "[object Array]") {
    tmp = Array(x2.length);
  } else if (str === "[object Set]") {
    tmp = /* @__PURE__ */ new Set();
    x2.forEach(function(val) {
      tmp.add(klona(val));
    });
  } else if (str === "[object Map]") {
    tmp = /* @__PURE__ */ new Map();
    x2.forEach(function(val, key) {
      tmp.set(klona(key), klona(val));
    });
  } else if (str === "[object Date]") {
    tmp = new Date(+x2);
  } else if (str === "[object RegExp]") {
    tmp = new RegExp(x2.source, x2.flags);
  } else if (str === "[object DataView]") {
    tmp = new x2.constructor(klona(x2.buffer));
  } else if (str === "[object ArrayBuffer]") {
    tmp = x2.slice(0);
  } else if (str.slice(-6) === "Array]") {
    tmp = new x2.constructor(x2);
  }
  if (tmp) {
    for (list = Object.getOwnPropertySymbols(x2); i2 < list.length; i2++) {
      set(tmp, list[i2], Object.getOwnPropertyDescriptor(x2, list[i2]));
    }
    for (i2 = 0, list = Object.getOwnPropertyNames(x2); i2 < list.length; i2++) {
      if (Object.hasOwnProperty.call(tmp, k2 = list[i2]) && tmp[k2] === x2[k2])
        continue;
      set(tmp, k2, Object.getOwnPropertyDescriptor(x2, k2));
    }
  }
  return tmp || x2;
}
function cleanupNonNestedPath(path) {
  if (isNotNestedPath(path)) {
    return path.replace(/\[|\]/gi, "");
  }
  return path;
}
function getFromPath(object, path, fallback) {
  if (!object) {
    return fallback;
  }
  if (isNotNestedPath(path)) {
    return object[cleanupNonNestedPath(path)];
  }
  const resolvedValue = (path || "").split(/\.|\[(\d+)\]/).filter(Boolean).reduce((acc, propKey) => {
    if (isContainerValue(acc) && propKey in acc) {
      return acc[propKey];
    }
    return fallback;
  }, object);
  return resolvedValue;
}
function setInPath(object, path, value) {
  if (isNotNestedPath(path)) {
    object[cleanupNonNestedPath(path)] = value;
    return;
  }
  const keys = path.split(/\.|\[(\d+)\]/).filter(Boolean);
  let acc = object;
  for (let i2 = 0; i2 < keys.length; i2++) {
    if (i2 === keys.length - 1) {
      acc[keys[i2]] = value;
      return;
    }
    if (!(keys[i2] in acc) || isNullOrUndefined$1(acc[keys[i2]])) {
      acc[keys[i2]] = isIndex(keys[i2 + 1]) ? [] : {};
    }
    acc = acc[keys[i2]];
  }
}
function unset(object, key) {
  if (Array.isArray(object) && isIndex(key)) {
    object.splice(Number(key), 1);
    return;
  }
  if (isObject(object)) {
    delete object[key];
  }
}
function unsetPath(object, path) {
  if (isNotNestedPath(path)) {
    delete object[cleanupNonNestedPath(path)];
    return;
  }
  const keys = path.split(/\.|\[(\d+)\]/).filter(Boolean);
  let acc = object;
  for (let i2 = 0; i2 < keys.length; i2++) {
    if (i2 === keys.length - 1) {
      unset(acc, keys[i2]);
      break;
    }
    if (!(keys[i2] in acc) || isNullOrUndefined$1(acc[keys[i2]])) {
      break;
    }
    acc = acc[keys[i2]];
  }
  const pathValues = keys.map((_2, idx) => {
    return getFromPath(object, keys.slice(0, idx).join("."));
  });
  for (let i2 = pathValues.length - 1; i2 >= 0; i2--) {
    if (!isEmptyContainer(pathValues[i2])) {
      continue;
    }
    if (i2 === 0) {
      unset(object, keys[0]);
      continue;
    }
    unset(pathValues[i2 - 1], keys[i2 - 1]);
  }
}
function keysOf(record) {
  return Object.keys(record);
}
function injectWithSelf(symbol, def = void 0) {
  const vm = getCurrentInstance();
  return (vm === null || vm === void 0 ? void 0 : vm.provides[symbol]) || inject(symbol, def);
}
function resolveNextCheckboxValue(currentValue, checkedValue, uncheckedValue) {
  if (Array.isArray(currentValue)) {
    const newVal = [...currentValue];
    const idx = newVal.findIndex((v2) => isEqual(v2, checkedValue));
    idx >= 0 ? newVal.splice(idx, 1) : newVal.push(checkedValue);
    return newVal;
  }
  return isEqual(currentValue, checkedValue) ? uncheckedValue : checkedValue;
}
function debounceAsync(inner, ms = 0) {
  let timer = null;
  let resolves = [];
  return function(...args) {
    if (timer) {
      window.clearTimeout(timer);
    }
    timer = window.setTimeout(() => {
      const result = inner(...args);
      resolves.forEach((r2) => r2(result));
      resolves = [];
    }, ms);
    return new Promise((resolve) => resolves.push(resolve));
  };
}
function applyModelModifiers(value, modifiers) {
  if (!isObject(modifiers)) {
    return value;
  }
  if (modifiers.number) {
    return toNumber(value);
  }
  return value;
}
function withLatest(fn2, onDone) {
  let latestRun;
  return async function runLatest(...args) {
    const pending = fn2(...args);
    latestRun = pending;
    const result = await pending;
    if (pending !== latestRun) {
      return result;
    }
    latestRun = void 0;
    onDone(result, args);
    return result;
  };
}
function computedDeep({ get, set: set2 }) {
  const baseRef = ref(klona(get()));
  watch(get, (newValue) => {
    if (isEqual(newValue, baseRef.value)) {
      return;
    }
    baseRef.value = klona(newValue);
  }, {
    deep: true
  });
  watch(baseRef, (newValue) => {
    if (isEqual(newValue, get())) {
      return;
    }
    set2(klona(newValue));
  }, {
    deep: true
  });
  return baseRef;
}
const normalizeChildren = (tag, context, slotProps) => {
  if (!context.slots.default) {
    return context.slots.default;
  }
  if (typeof tag === "string" || !tag) {
    return context.slots.default(slotProps());
  }
  return {
    default: () => {
      var _a, _b;
      return (_b = (_a = context.slots).default) === null || _b === void 0 ? void 0 : _b.call(_a, slotProps());
    }
  };
};
function getBoundValue(el) {
  if (hasValueBinding(el)) {
    return el._value;
  }
  return void 0;
}
function hasValueBinding(el) {
  return "_value" in el;
}
function normalizeEventValue(value) {
  if (!isEvent(value)) {
    return value;
  }
  const input = value.target;
  if (hasCheckedAttr(input.type) && hasValueBinding(input)) {
    return getBoundValue(input);
  }
  if (input.type === "file" && input.files) {
    const files = Array.from(input.files);
    return input.multiple ? files : files[0];
  }
  if (isNativeMultiSelect(input)) {
    return Array.from(input.options).filter((opt) => opt.selected && !opt.disabled).map(getBoundValue);
  }
  if (isNativeSelect(input)) {
    const selectedOption = Array.from(input.options).find((opt) => opt.selected);
    return selectedOption ? getBoundValue(selectedOption) : input.value;
  }
  return input.value;
}
function normalizeRules(rules) {
  const acc = {};
  Object.defineProperty(acc, "_$$isNormalized", {
    value: true,
    writable: false,
    enumerable: false,
    configurable: false
  });
  if (!rules) {
    return acc;
  }
  if (isObject(rules) && rules._$$isNormalized) {
    return rules;
  }
  if (isObject(rules)) {
    return Object.keys(rules).reduce((prev, curr) => {
      const params = normalizeParams(rules[curr]);
      if (rules[curr] !== false) {
        prev[curr] = buildParams(params);
      }
      return prev;
    }, acc);
  }
  if (typeof rules !== "string") {
    return acc;
  }
  return rules.split("|").reduce((prev, rule) => {
    const parsedRule = parseRule(rule);
    if (!parsedRule.name) {
      return prev;
    }
    prev[parsedRule.name] = buildParams(parsedRule.params);
    return prev;
  }, acc);
}
function normalizeParams(params) {
  if (params === true) {
    return [];
  }
  if (Array.isArray(params)) {
    return params;
  }
  if (isObject(params)) {
    return params;
  }
  return [params];
}
function buildParams(provided) {
  const mapValueToLocator = (value) => {
    if (typeof value === "string" && value[0] === "@") {
      return createLocator(value.slice(1));
    }
    return value;
  };
  if (Array.isArray(provided)) {
    return provided.map(mapValueToLocator);
  }
  if (provided instanceof RegExp) {
    return [provided];
  }
  return Object.keys(provided).reduce((prev, key) => {
    prev[key] = mapValueToLocator(provided[key]);
    return prev;
  }, {});
}
const parseRule = (rule) => {
  let params = [];
  const name = rule.split(":")[0];
  if (rule.includes(":")) {
    params = rule.split(":").slice(1).join(":").split(",");
  }
  return { name, params };
};
function createLocator(value) {
  const locator = (crossTable) => {
    const val = getFromPath(crossTable, value) || crossTable[value];
    return val;
  };
  locator.__locatorRef = value;
  return locator;
}
function extractLocators(params) {
  if (Array.isArray(params)) {
    return params.filter(isLocator);
  }
  return keysOf(params).filter((key) => isLocator(params[key])).map((key) => params[key]);
}
const DEFAULT_CONFIG = {
  generateMessage: ({ field }) => `${field} is not valid.`,
  bails: true,
  validateOnBlur: true,
  validateOnChange: true,
  validateOnInput: false,
  validateOnModelUpdate: true
};
let currentConfig = Object.assign({}, DEFAULT_CONFIG);
const getConfig = () => currentConfig;
const setConfig = (newConf) => {
  currentConfig = Object.assign(Object.assign({}, currentConfig), newConf);
};
const configure = setConfig;
async function validate(value, rules, options = {}) {
  const shouldBail = options === null || options === void 0 ? void 0 : options.bails;
  const field = {
    name: (options === null || options === void 0 ? void 0 : options.name) || "{field}",
    rules,
    label: options === null || options === void 0 ? void 0 : options.label,
    bails: shouldBail !== null && shouldBail !== void 0 ? shouldBail : true,
    formData: (options === null || options === void 0 ? void 0 : options.values) || {}
  };
  const result = await _validate(field, value);
  const errors = result.errors;
  return {
    errors,
    valid: !errors.length
  };
}
async function _validate(field, value) {
  if (isYupValidator(field.rules)) {
    return validateFieldWithYup(value, field.rules, { bails: field.bails });
  }
  if (isCallable(field.rules) || Array.isArray(field.rules)) {
    const ctx = {
      field: field.label || field.name,
      name: field.name,
      label: field.label,
      form: field.formData,
      value
    };
    const pipeline = Array.isArray(field.rules) ? field.rules : [field.rules];
    const length2 = pipeline.length;
    const errors2 = [];
    for (let i2 = 0; i2 < length2; i2++) {
      const rule = pipeline[i2];
      const result = await rule(value, ctx);
      const isValid = typeof result !== "string" && result;
      if (isValid) {
        continue;
      }
      const message = typeof result === "string" ? result : _generateFieldError(ctx);
      errors2.push(message);
      if (field.bails) {
        return {
          errors: errors2
        };
      }
    }
    return {
      errors: errors2
    };
  }
  const normalizedContext = Object.assign(Object.assign({}, field), { rules: normalizeRules(field.rules) });
  const errors = [];
  const rulesKeys = Object.keys(normalizedContext.rules);
  const length = rulesKeys.length;
  for (let i2 = 0; i2 < length; i2++) {
    const rule = rulesKeys[i2];
    const result = await _test(normalizedContext, value, {
      name: rule,
      params: normalizedContext.rules[rule]
    });
    if (result.error) {
      errors.push(result.error);
      if (field.bails) {
        return {
          errors
        };
      }
    }
  }
  return {
    errors
  };
}
async function validateFieldWithYup(value, validator, opts) {
  var _a;
  const errors = await validator.validate(value, {
    abortEarly: (_a = opts.bails) !== null && _a !== void 0 ? _a : true
  }).then(() => []).catch((err) => {
    if (err.name === "ValidationError") {
      return err.errors;
    }
    throw err;
  });
  return {
    errors
  };
}
async function _test(field, value, rule) {
  const validator = resolveRule(rule.name);
  if (!validator) {
    throw new Error(`No such validator '${rule.name}' exists.`);
  }
  const params = fillTargetValues(rule.params, field.formData);
  const ctx = {
    field: field.label || field.name,
    name: field.name,
    label: field.label,
    value,
    form: field.formData,
    rule: Object.assign(Object.assign({}, rule), { params })
  };
  const result = await validator(value, params, ctx);
  if (typeof result === "string") {
    return {
      error: result
    };
  }
  return {
    error: result ? void 0 : _generateFieldError(ctx)
  };
}
function _generateFieldError(fieldCtx) {
  const message = getConfig().generateMessage;
  if (!message) {
    return "Field is invalid";
  }
  return message(fieldCtx);
}
function fillTargetValues(params, crossTable) {
  const normalize = (value) => {
    if (isLocator(value)) {
      return value(crossTable);
    }
    return value;
  };
  if (Array.isArray(params)) {
    return params.map(normalize);
  }
  return Object.keys(params).reduce((acc, param) => {
    acc[param] = normalize(params[param]);
    return acc;
  }, {});
}
async function validateYupSchema(schema, values) {
  const errorObjects = await schema.validate(values, { abortEarly: false }).then(() => []).catch((err) => {
    if (err.name !== "ValidationError") {
      throw err;
    }
    return err.inner || [];
  });
  const results = {};
  const errors = {};
  for (const error of errorObjects) {
    const messages = error.errors;
    results[error.path] = { valid: !messages.length, errors: messages };
    if (messages.length) {
      errors[error.path] = messages[0];
    }
  }
  return {
    valid: !errorObjects.length,
    results,
    errors
  };
}
async function validateObjectSchema(schema, values, opts) {
  const paths = keysOf(schema);
  const validations = paths.map(async (path) => {
    var _a, _b, _c;
    const strings = (_a = opts === null || opts === void 0 ? void 0 : opts.names) === null || _a === void 0 ? void 0 : _a[path];
    const fieldResult = await validate(getFromPath(values, path), schema[path], {
      name: (strings === null || strings === void 0 ? void 0 : strings.name) || path,
      label: strings === null || strings === void 0 ? void 0 : strings.label,
      values,
      bails: (_c = (_b = opts === null || opts === void 0 ? void 0 : opts.bailsMap) === null || _b === void 0 ? void 0 : _b[path]) !== null && _c !== void 0 ? _c : true
    });
    return Object.assign(Object.assign({}, fieldResult), { path });
  });
  let isAllValid = true;
  const validationResults = await Promise.all(validations);
  const results = {};
  const errors = {};
  for (const result of validationResults) {
    results[result.path] = {
      valid: result.valid,
      errors: result.errors
    };
    if (!result.valid) {
      isAllValid = false;
      errors[result.path] = result.errors[0];
    }
  }
  return {
    valid: isAllValid,
    results,
    errors
  };
}
let ID_COUNTER = 0;
function useFieldState(path, init) {
  const { value, initialValue, setInitialValue } = _useFieldValue(path, init.modelValue, init.form);
  const { errorMessage, errors, setErrors } = _useFieldErrors(path, init.form);
  const meta = _useFieldMeta(value, initialValue, errors);
  const id = ID_COUNTER >= Number.MAX_SAFE_INTEGER ? 0 : ++ID_COUNTER;
  function setState(state) {
    var _a;
    if ("value" in state) {
      value.value = state.value;
    }
    if ("errors" in state) {
      setErrors(state.errors);
    }
    if ("touched" in state) {
      meta.touched = (_a = state.touched) !== null && _a !== void 0 ? _a : meta.touched;
    }
    if ("initialValue" in state) {
      setInitialValue(state.initialValue);
    }
  }
  return {
    id,
    path,
    value,
    initialValue,
    meta,
    errors,
    errorMessage,
    setState
  };
}
function _useFieldValue(path, modelValue, form) {
  const modelRef = ref(unref(modelValue));
  function resolveInitialValue2() {
    if (!form) {
      return unref(modelRef);
    }
    return getFromPath(form.meta.value.initialValues, unref(path), unref(modelRef));
  }
  function setInitialValue(value2) {
    if (!form) {
      modelRef.value = value2;
      return;
    }
    form.stageInitialValue(unref(path), value2, true);
  }
  const initialValue = computed(resolveInitialValue2);
  if (!form) {
    const value2 = ref(resolveInitialValue2());
    return {
      value: value2,
      initialValue,
      setInitialValue
    };
  }
  const currentValue = modelValue ? unref(modelValue) : getFromPath(form.values, unref(path), unref(initialValue));
  form.stageInitialValue(unref(path), currentValue, true);
  const value = computed({
    get() {
      return getFromPath(form.values, unref(path));
    },
    set(newVal) {
      form.setFieldValue(unref(path), newVal);
    }
  });
  return {
    value,
    initialValue,
    setInitialValue
  };
}
function _useFieldMeta(currentValue, initialValue, errors) {
  const meta = reactive({
    touched: false,
    pending: false,
    valid: true,
    validated: !!unref(errors).length,
    initialValue: computed(() => unref(initialValue)),
    dirty: computed(() => {
      return !isEqual(unref(currentValue), unref(initialValue));
    })
  });
  watch(errors, (value) => {
    meta.valid = !value.length;
  }, {
    immediate: true,
    flush: "sync"
  });
  return meta;
}
function _useFieldErrors(path, form) {
  function normalizeErrors(messages) {
    if (!messages) {
      return [];
    }
    return Array.isArray(messages) ? messages : [messages];
  }
  if (!form) {
    const errors2 = ref([]);
    return {
      errors: errors2,
      errorMessage: computed(() => errors2.value[0]),
      setErrors: (messages) => {
        errors2.value = normalizeErrors(messages);
      }
    };
  }
  const errors = computed(() => form.errorBag.value[unref(path)] || []);
  return {
    errors,
    errorMessage: computed(() => errors.value[0]),
    setErrors: (messages) => {
      form.setFieldErrorBag(unref(path), normalizeErrors(messages));
    }
  };
}
function useField(name, rules, opts) {
  if (hasCheckedAttr(opts === null || opts === void 0 ? void 0 : opts.type)) {
    return useCheckboxField(name, rules, opts);
  }
  return _useField(name, rules, opts);
}
function _useField(name, rules, opts) {
  const { initialValue: modelValue, validateOnMount, bails, type, checkedValue, label, validateOnValueUpdate, uncheckedValue, controlled, keepValueOnUnmount, modelPropName, syncVModel, form: controlForm } = normalizeOptions(unref(name), opts);
  const injectedForm = controlled ? injectWithSelf(FormContextKey) : void 0;
  const form = controlForm || injectedForm;
  let markedForRemoval = false;
  const { id, value, initialValue, meta, setState, errors, errorMessage } = useFieldState(name, {
    modelValue,
    form
  });
  if (syncVModel) {
    useVModel({ value, prop: modelPropName, handleChange });
  }
  const handleBlur = () => {
    meta.touched = true;
  };
  const normalizedRules = computed(() => {
    let rulesValue = unref(rules);
    const schema = unref(form === null || form === void 0 ? void 0 : form.schema);
    if (schema && !isYupValidator(schema)) {
      rulesValue = extractRuleFromSchema(schema, unref(name)) || rulesValue;
    }
    if (isYupValidator(rulesValue) || isCallable(rulesValue) || Array.isArray(rulesValue)) {
      return rulesValue;
    }
    return normalizeRules(rulesValue);
  });
  async function validateCurrentValue(mode) {
    var _a, _b;
    if (form === null || form === void 0 ? void 0 : form.validateSchema) {
      return (_a = (await form.validateSchema(mode)).results[unref(name)]) !== null && _a !== void 0 ? _a : { valid: true, errors: [] };
    }
    return validate(value.value, normalizedRules.value, {
      name: unref(name),
      label: unref(label),
      values: (_b = form === null || form === void 0 ? void 0 : form.values) !== null && _b !== void 0 ? _b : {},
      bails
    });
  }
  const validateWithStateMutation = withLatest(async () => {
    meta.pending = true;
    meta.validated = true;
    return validateCurrentValue("validated-only");
  }, (result) => {
    if (markedForRemoval) {
      result.valid = true;
      result.errors = [];
    }
    setState({ errors: result.errors });
    meta.pending = false;
    return result;
  });
  const validateValidStateOnly = withLatest(async () => {
    return validateCurrentValue("silent");
  }, (result) => {
    if (markedForRemoval) {
      result.valid = true;
    }
    meta.valid = result.valid;
    return result;
  });
  function validate$1(opts2) {
    if ((opts2 === null || opts2 === void 0 ? void 0 : opts2.mode) === "silent") {
      return validateValidStateOnly();
    }
    return validateWithStateMutation();
  }
  function handleChange(e2, shouldValidate = true) {
    const newValue = normalizeEventValue(e2);
    value.value = newValue;
    if (!validateOnValueUpdate && shouldValidate) {
      validateWithStateMutation();
    }
  }
  onMounted(() => {
    if (validateOnMount) {
      return validateWithStateMutation();
    }
    if (!form || !form.validateSchema) {
      validateValidStateOnly();
    }
  });
  function setTouched(isTouched) {
    meta.touched = isTouched;
  }
  let unwatchValue;
  let lastWatchedValue = klona(value.value);
  function watchValue() {
    unwatchValue = watch(value, (val, oldVal) => {
      if (isEqual(val, oldVal) && isEqual(val, lastWatchedValue)) {
        return;
      }
      const validateFn = validateOnValueUpdate ? validateWithStateMutation : validateValidStateOnly;
      validateFn();
      lastWatchedValue = klona(val);
    }, {
      deep: true
    });
  }
  watchValue();
  function resetField(state) {
    var _a;
    unwatchValue === null || unwatchValue === void 0 ? void 0 : unwatchValue();
    const newValue = state && "value" in state ? state.value : initialValue.value;
    setState({
      value: klona(newValue),
      initialValue: klona(newValue),
      touched: (_a = state === null || state === void 0 ? void 0 : state.touched) !== null && _a !== void 0 ? _a : false,
      errors: (state === null || state === void 0 ? void 0 : state.errors) || []
    });
    meta.pending = false;
    meta.validated = false;
    validateValidStateOnly();
    nextTick(() => {
      watchValue();
    });
  }
  function setValue(newValue) {
    value.value = newValue;
  }
  function setErrors(errors2) {
    setState({ errors: Array.isArray(errors2) ? errors2 : [errors2] });
  }
  const field = {
    id,
    name,
    label,
    value,
    meta,
    errors,
    errorMessage,
    type,
    checkedValue,
    uncheckedValue,
    bails,
    keepValueOnUnmount,
    resetField,
    handleReset: () => resetField(),
    validate: validate$1,
    handleChange,
    handleBlur,
    setState,
    setTouched,
    setErrors,
    setValue
  };
  provide(FieldContextKey, field);
  if (isRef(rules) && typeof unref(rules) !== "function") {
    watch(rules, (value2, oldValue) => {
      if (isEqual(value2, oldValue)) {
        return;
      }
      meta.validated ? validateWithStateMutation() : validateValidStateOnly();
    }, {
      deep: true
    });
  }
  if (!form) {
    return field;
  }
  form.register(field);
  onBeforeUnmount(() => {
    markedForRemoval = true;
    form.unregister(field);
  });
  const dependencies = computed(() => {
    const rulesVal = normalizedRules.value;
    if (!rulesVal || isCallable(rulesVal) || isYupValidator(rulesVal) || Array.isArray(rulesVal)) {
      return {};
    }
    return Object.keys(rulesVal).reduce((acc, rule) => {
      const deps = extractLocators(rulesVal[rule]).map((dep) => dep.__locatorRef).reduce((depAcc, depName) => {
        const depValue = getFromPath(form.values, depName) || form.values[depName];
        if (depValue !== void 0) {
          depAcc[depName] = depValue;
        }
        return depAcc;
      }, {});
      Object.assign(acc, deps);
      return acc;
    }, {});
  });
  watch(dependencies, (deps, oldDeps) => {
    if (!Object.keys(deps).length) {
      return;
    }
    const shouldValidate = !isEqual(deps, oldDeps);
    if (shouldValidate) {
      meta.validated ? validateWithStateMutation() : validateValidStateOnly();
    }
  });
  return field;
}
function normalizeOptions(name, opts) {
  const defaults = () => ({
    initialValue: void 0,
    validateOnMount: false,
    bails: true,
    label: name,
    validateOnValueUpdate: true,
    keepValueOnUnmount: void 0,
    modelPropName: "modelValue",
    syncVModel: true,
    controlled: true
  });
  if (!opts) {
    return defaults();
  }
  const checkedValue = "valueProp" in opts ? opts.valueProp : opts.checkedValue;
  const controlled = "standalone" in opts ? !opts.standalone : opts.controlled;
  return Object.assign(Object.assign(Object.assign({}, defaults()), opts || {}), { controlled: controlled !== null && controlled !== void 0 ? controlled : true, checkedValue });
}
function extractRuleFromSchema(schema, fieldName) {
  if (!schema) {
    return void 0;
  }
  return schema[fieldName];
}
function useCheckboxField(name, rules, opts) {
  const form = !(opts === null || opts === void 0 ? void 0 : opts.standalone) ? injectWithSelf(FormContextKey) : void 0;
  const checkedValue = opts === null || opts === void 0 ? void 0 : opts.checkedValue;
  const uncheckedValue = opts === null || opts === void 0 ? void 0 : opts.uncheckedValue;
  function patchCheckboxApi(field) {
    const handleChange = field.handleChange;
    const checked = computed(() => {
      const currentValue = unref(field.value);
      const checkedVal = unref(checkedValue);
      return Array.isArray(currentValue) ? currentValue.findIndex((v2) => isEqual(v2, checkedVal)) >= 0 : isEqual(checkedVal, currentValue);
    });
    function handleCheckboxChange(e2, shouldValidate = true) {
      var _a;
      if (checked.value === ((_a = e2 === null || e2 === void 0 ? void 0 : e2.target) === null || _a === void 0 ? void 0 : _a.checked)) {
        if (shouldValidate) {
          field.validate();
        }
        return;
      }
      let newValue = normalizeEventValue(e2);
      if (!form) {
        newValue = resolveNextCheckboxValue(unref(field.value), unref(checkedValue), unref(uncheckedValue));
      }
      handleChange(newValue, shouldValidate);
    }
    return Object.assign(Object.assign({}, field), {
      checked,
      checkedValue,
      uncheckedValue,
      handleChange: handleCheckboxChange
    });
  }
  return patchCheckboxApi(_useField(name, rules, opts));
}
function useVModel({ prop, value, handleChange }) {
  const vm = getCurrentInstance();
  if (!vm) {
    return;
  }
  const propName = prop || "modelValue";
  const emitName = `update:${propName}`;
  if (!(propName in vm.props)) {
    return;
  }
  watch(value, (newValue) => {
    if (isEqual(newValue, getCurrentModelValue(vm, propName))) {
      return;
    }
    vm.emit(emitName, newValue);
  });
  watch(() => getCurrentModelValue(vm, propName), (propValue) => {
    if (propValue === IS_ABSENT && value.value === void 0) {
      return;
    }
    const newValue = propValue === IS_ABSENT ? void 0 : propValue;
    if (isEqual(newValue, applyModelModifiers(value.value, vm.props.modelModifiers))) {
      return;
    }
    handleChange(newValue);
  });
}
function getCurrentModelValue(vm, propName) {
  return vm.props[propName];
}
defineComponent({
  name: "Field",
  inheritAttrs: false,
  props: {
    as: {
      type: [String, Object],
      default: void 0
    },
    name: {
      type: String,
      required: true
    },
    rules: {
      type: [Object, String, Function],
      default: void 0
    },
    validateOnMount: {
      type: Boolean,
      default: false
    },
    validateOnBlur: {
      type: Boolean,
      default: void 0
    },
    validateOnChange: {
      type: Boolean,
      default: void 0
    },
    validateOnInput: {
      type: Boolean,
      default: void 0
    },
    validateOnModelUpdate: {
      type: Boolean,
      default: void 0
    },
    bails: {
      type: Boolean,
      default: () => getConfig().bails
    },
    label: {
      type: String,
      default: void 0
    },
    uncheckedValue: {
      type: null,
      default: void 0
    },
    modelValue: {
      type: null,
      default: IS_ABSENT
    },
    modelModifiers: {
      type: null,
      default: () => ({})
    },
    "onUpdate:modelValue": {
      type: null,
      default: void 0
    },
    standalone: {
      type: Boolean,
      default: false
    },
    keepValue: {
      type: Boolean,
      default: void 0
    }
  },
  setup(props, ctx) {
    const rules = toRef(props, "rules");
    const name = toRef(props, "name");
    const label = toRef(props, "label");
    const uncheckedValue = toRef(props, "uncheckedValue");
    const keepValue = toRef(props, "keepValue");
    const { errors, value, errorMessage, validate: validateField, handleChange, handleBlur, setTouched, resetField, handleReset, meta, checked, setErrors } = useField(name, rules, {
      validateOnMount: props.validateOnMount,
      bails: props.bails,
      standalone: props.standalone,
      type: ctx.attrs.type,
      initialValue: resolveInitialValue(props, ctx),
      // Only for checkboxes and radio buttons
      checkedValue: ctx.attrs.value,
      uncheckedValue,
      label,
      validateOnValueUpdate: false,
      keepValueOnUnmount: keepValue
    });
    const onChangeHandler = function handleChangeWithModel(e2, shouldValidate = true) {
      handleChange(e2, shouldValidate);
      ctx.emit("update:modelValue", value.value);
    };
    const handleInput = (e2) => {
      if (!hasCheckedAttr(ctx.attrs.type)) {
        value.value = normalizeEventValue(e2);
      }
    };
    const onInputHandler = function handleInputWithModel(e2) {
      handleInput(e2);
      ctx.emit("update:modelValue", value.value);
    };
    const fieldProps = computed(() => {
      const { validateOnInput, validateOnChange, validateOnBlur, validateOnModelUpdate } = resolveValidationTriggers(props);
      const baseOnBlur = [handleBlur, ctx.attrs.onBlur, validateOnBlur ? validateField : void 0].filter(Boolean);
      const baseOnInput = [(e2) => onChangeHandler(e2, validateOnInput), ctx.attrs.onInput].filter(Boolean);
      const baseOnChange = [(e2) => onChangeHandler(e2, validateOnChange), ctx.attrs.onChange].filter(Boolean);
      const attrs = {
        name: props.name,
        onBlur: baseOnBlur,
        onInput: baseOnInput,
        onChange: baseOnChange
      };
      attrs["onUpdate:modelValue"] = (e2) => onChangeHandler(e2, validateOnModelUpdate);
      if (hasCheckedAttr(ctx.attrs.type) && checked) {
        attrs.checked = checked.value;
      }
      const tag = resolveTag(props, ctx);
      if (shouldHaveValueBinding(tag, ctx.attrs)) {
        attrs.value = value.value;
      }
      return attrs;
    });
    function slotProps() {
      return {
        field: fieldProps.value,
        value: value.value,
        meta,
        errors: errors.value,
        errorMessage: errorMessage.value,
        validate: validateField,
        resetField,
        handleChange: onChangeHandler,
        handleInput: onInputHandler,
        handleReset,
        handleBlur,
        setTouched,
        setErrors
      };
    }
    ctx.expose({
      setErrors,
      setTouched,
      reset: resetField,
      validate: validateField,
      handleChange
    });
    return () => {
      const tag = resolveDynamicComponent(resolveTag(props, ctx));
      const children = normalizeChildren(tag, ctx, slotProps);
      if (tag) {
        return h$1(tag, Object.assign(Object.assign({}, ctx.attrs), fieldProps.value), children);
      }
      return children;
    };
  }
});
function resolveTag(props, ctx) {
  let tag = props.as || "";
  if (!props.as && !ctx.slots.default) {
    tag = "input";
  }
  return tag;
}
function resolveValidationTriggers(props) {
  var _a, _b, _c, _d;
  const { validateOnInput, validateOnChange, validateOnBlur, validateOnModelUpdate } = getConfig();
  return {
    validateOnInput: (_a = props.validateOnInput) !== null && _a !== void 0 ? _a : validateOnInput,
    validateOnChange: (_b = props.validateOnChange) !== null && _b !== void 0 ? _b : validateOnChange,
    validateOnBlur: (_c = props.validateOnBlur) !== null && _c !== void 0 ? _c : validateOnBlur,
    validateOnModelUpdate: (_d = props.validateOnModelUpdate) !== null && _d !== void 0 ? _d : validateOnModelUpdate
  };
}
function resolveInitialValue(props, ctx) {
  if (!hasCheckedAttr(ctx.attrs.type)) {
    return isPropPresent(props, "modelValue") ? props.modelValue : ctx.attrs.value;
  }
  return isPropPresent(props, "modelValue") ? props.modelValue : void 0;
}
let FORM_COUNTER = 0;
function useForm(opts) {
  var _a;
  const formId = FORM_COUNTER++;
  const controlledModelPaths = /* @__PURE__ */ new Set();
  let RESET_LOCK = false;
  const fieldsByPath = ref({});
  const isSubmitting = ref(false);
  const submitCount = ref(0);
  const fieldArrays = [];
  const formValues = reactive(klona(unref(opts === null || opts === void 0 ? void 0 : opts.initialValues) || {}));
  const { errorBag, setErrorBag, setFieldErrorBag } = useErrorBag(opts === null || opts === void 0 ? void 0 : opts.initialErrors);
  const errors = computed(() => {
    return keysOf(errorBag.value).reduce((acc, key) => {
      const bag = errorBag.value[key];
      if (bag && bag.length) {
        acc[key] = bag[0];
      }
      return acc;
    }, {});
  });
  function getFirstFieldAtPath(path) {
    const fieldOrGroup = fieldsByPath.value[path];
    return Array.isArray(fieldOrGroup) ? fieldOrGroup[0] : fieldOrGroup;
  }
  function fieldExists(path) {
    return !!fieldsByPath.value[path];
  }
  const fieldNames = computed(() => {
    return keysOf(fieldsByPath.value).reduce((names, path) => {
      const field = getFirstFieldAtPath(path);
      if (field) {
        names[path] = { name: unref(field.name) || "", label: unref(field.label) || "" };
      }
      return names;
    }, {});
  });
  const fieldBailsMap = computed(() => {
    return keysOf(fieldsByPath.value).reduce((map, path) => {
      var _a2;
      const field = getFirstFieldAtPath(path);
      if (field) {
        map[path] = (_a2 = field.bails) !== null && _a2 !== void 0 ? _a2 : true;
      }
      return map;
    }, {});
  });
  const initialErrors = Object.assign({}, (opts === null || opts === void 0 ? void 0 : opts.initialErrors) || {});
  const keepValuesOnUnmount = (_a = opts === null || opts === void 0 ? void 0 : opts.keepValuesOnUnmount) !== null && _a !== void 0 ? _a : false;
  const { initialValues, originalInitialValues, setInitialValues } = useFormInitialValues(fieldsByPath, formValues, opts === null || opts === void 0 ? void 0 : opts.initialValues);
  const meta = useFormMeta(fieldsByPath, formValues, originalInitialValues, errors);
  const controlledValues = computed(() => {
    return [...controlledModelPaths, ...keysOf(fieldsByPath.value)].reduce((acc, path) => {
      const value = getFromPath(formValues, path);
      setInPath(acc, path, value);
      return acc;
    }, {});
  });
  const schema = opts === null || opts === void 0 ? void 0 : opts.validationSchema;
  const debouncedSilentValidation = debounceAsync(_validateSchema, 5);
  const debouncedValidation = debounceAsync(_validateSchema, 5);
  const validateSchema = withLatest(async (mode) => {
    return await mode === "silent" ? debouncedSilentValidation() : debouncedValidation();
  }, (formResult, [mode]) => {
    const fieldsById = formCtx.fieldsByPath.value || {};
    const currentErrorsPaths = keysOf(formCtx.errorBag.value);
    const paths = [
      .../* @__PURE__ */ new Set([...keysOf(formResult.results), ...keysOf(fieldsById), ...currentErrorsPaths])
    ];
    return paths.reduce((validation, path) => {
      const field = fieldsById[path];
      const messages = (formResult.results[path] || { errors: [] }).errors;
      const fieldResult = {
        errors: messages,
        valid: !messages.length
      };
      validation.results[path] = fieldResult;
      if (!fieldResult.valid) {
        validation.errors[path] = fieldResult.errors[0];
      }
      if (!field) {
        setFieldError(path, messages);
        return validation;
      }
      applyFieldMutation(field, (f2) => f2.meta.valid = fieldResult.valid);
      if (mode === "silent") {
        return validation;
      }
      const wasValidated = Array.isArray(field) ? field.some((f2) => f2.meta.validated) : field.meta.validated;
      if (mode === "validated-only" && !wasValidated) {
        return validation;
      }
      applyFieldMutation(field, (f2) => f2.setState({ errors: fieldResult.errors }));
      return validation;
    }, { valid: formResult.valid, results: {}, errors: {} });
  });
  function makeSubmissionFactory(onlyControlled) {
    return function submitHandlerFactory(fn2, onValidationError) {
      return function submissionHandler(e2) {
        if (e2 instanceof Event) {
          e2.preventDefault();
          e2.stopPropagation();
        }
        setTouched(keysOf(fieldsByPath.value).reduce((acc, field) => {
          acc[field] = true;
          return acc;
        }, {}));
        isSubmitting.value = true;
        submitCount.value++;
        return validate2().then((result) => {
          const values = klona(formValues);
          if (result.valid && typeof fn2 === "function") {
            const controlled = klona(controlledValues.value);
            return fn2(onlyControlled ? controlled : values, {
              evt: e2,
              controlledValues: controlled,
              setErrors,
              setFieldError,
              setTouched,
              setFieldTouched,
              setValues,
              setFieldValue,
              resetForm,
              resetField
            });
          }
          if (!result.valid && typeof onValidationError === "function") {
            onValidationError({
              values,
              evt: e2,
              errors: result.errors,
              results: result.results
            });
          }
        }).then((returnVal) => {
          isSubmitting.value = false;
          return returnVal;
        }, (err) => {
          isSubmitting.value = false;
          throw err;
        });
      };
    };
  }
  const handleSubmitImpl = makeSubmissionFactory(false);
  const handleSubmit = handleSubmitImpl;
  handleSubmit.withControlled = makeSubmissionFactory(true);
  const formCtx = {
    formId,
    fieldsByPath,
    values: formValues,
    controlledValues,
    errorBag,
    errors,
    schema,
    submitCount,
    meta,
    isSubmitting,
    fieldArrays,
    keepValuesOnUnmount,
    validateSchema: unref(schema) ? validateSchema : void 0,
    validate: validate2,
    register: registerField,
    unregister: unregisterField,
    setFieldErrorBag,
    validateField,
    setFieldValue,
    setValues,
    setErrors,
    setFieldError,
    setFieldTouched,
    setTouched,
    resetForm,
    resetField,
    handleSubmit,
    stageInitialValue,
    unsetInitialValue,
    setFieldInitialValue,
    useFieldModel
  };
  function isFieldGroup(fieldOrGroup) {
    return Array.isArray(fieldOrGroup);
  }
  function applyFieldMutation(fieldOrGroup, mutation) {
    if (Array.isArray(fieldOrGroup)) {
      return fieldOrGroup.forEach(mutation);
    }
    return mutation(fieldOrGroup);
  }
  function mutateAllFields(mutation) {
    Object.values(fieldsByPath.value).forEach((field) => {
      if (!field) {
        return;
      }
      applyFieldMutation(field, mutation);
    });
  }
  function setFieldError(field, message) {
    setFieldErrorBag(field, message);
  }
  function setErrors(fields) {
    setErrorBag(fields);
  }
  function setFieldValue(field, value, { force } = { force: false }) {
    var _a2;
    const fieldInstance = fieldsByPath.value[field];
    const clonedValue = klona(value);
    if (!fieldInstance) {
      setInPath(formValues, field, clonedValue);
      return;
    }
    if (isFieldGroup(fieldInstance) && ((_a2 = fieldInstance[0]) === null || _a2 === void 0 ? void 0 : _a2.type) === "checkbox" && !Array.isArray(value)) {
      const newValue2 = klona(resolveNextCheckboxValue(getFromPath(formValues, field) || [], value, void 0));
      setInPath(formValues, field, newValue2);
      return;
    }
    let newValue = clonedValue;
    if (!isFieldGroup(fieldInstance) && fieldInstance.type === "checkbox" && !force && !RESET_LOCK) {
      newValue = klona(resolveNextCheckboxValue(getFromPath(formValues, field), value, unref(fieldInstance.uncheckedValue)));
    }
    setInPath(formValues, field, newValue);
  }
  function setValues(fields) {
    keysOf(formValues).forEach((key) => {
      delete formValues[key];
    });
    keysOf(fields).forEach((path) => {
      setFieldValue(path, fields[path]);
    });
    fieldArrays.forEach((f2) => f2 && f2.reset());
  }
  function createModel(path) {
    const { value } = _useFieldValue(path, void 0, formCtx);
    watch(value, () => {
      if (!fieldExists(unref(path))) {
        validate2({ mode: "validated-only" });
      }
    }, {
      deep: true
    });
    controlledModelPaths.add(unref(path));
    return value;
  }
  function useFieldModel(path) {
    if (!Array.isArray(path)) {
      return createModel(path);
    }
    return path.map(createModel);
  }
  function setFieldTouched(field, isTouched) {
    const fieldInstance = fieldsByPath.value[field];
    if (fieldInstance) {
      applyFieldMutation(fieldInstance, (f2) => f2.setTouched(isTouched));
    }
  }
  function setTouched(fields) {
    keysOf(fields).forEach((field) => {
      setFieldTouched(field, !!fields[field]);
    });
  }
  function resetField(field, state) {
    const fieldInstance = fieldsByPath.value[field];
    if (fieldInstance) {
      applyFieldMutation(fieldInstance, (f2) => f2.resetField(state));
    }
  }
  function resetForm(state) {
    RESET_LOCK = true;
    mutateAllFields((f2) => f2.resetField());
    const newValues = (state === null || state === void 0 ? void 0 : state.values) ? state.values : originalInitialValues.value;
    setInitialValues(newValues);
    setValues(newValues);
    if (state === null || state === void 0 ? void 0 : state.touched) {
      setTouched(state.touched);
    }
    setErrors((state === null || state === void 0 ? void 0 : state.errors) || {});
    submitCount.value = (state === null || state === void 0 ? void 0 : state.submitCount) || 0;
    nextTick(() => {
      RESET_LOCK = false;
    });
  }
  function insertFieldAtPath(field, path) {
    const rawField = markRaw(field);
    const fieldPath = path;
    if (!fieldsByPath.value[fieldPath]) {
      fieldsByPath.value[fieldPath] = rawField;
      return;
    }
    const fieldAtPath = fieldsByPath.value[fieldPath];
    if (fieldAtPath && !Array.isArray(fieldAtPath)) {
      fieldsByPath.value[fieldPath] = [fieldAtPath];
    }
    fieldsByPath.value[fieldPath] = [...fieldsByPath.value[fieldPath], rawField];
  }
  function removeFieldFromPath(field, path) {
    const fieldPath = path;
    const fieldAtPath = fieldsByPath.value[fieldPath];
    if (!fieldAtPath) {
      return;
    }
    if (!isFieldGroup(fieldAtPath) && field.id === fieldAtPath.id) {
      delete fieldsByPath.value[fieldPath];
      return;
    }
    if (isFieldGroup(fieldAtPath)) {
      const idx = fieldAtPath.findIndex((f2) => f2.id === field.id);
      if (idx === -1) {
        return;
      }
      fieldAtPath.splice(idx, 1);
      if (!fieldAtPath.length) {
        delete fieldsByPath.value[fieldPath];
      }
    }
  }
  function registerField(field) {
    const fieldPath = unref(field.name);
    insertFieldAtPath(field, fieldPath);
    if (isRef(field.name)) {
      watch(field.name, async (newPath, oldPath) => {
        await nextTick();
        removeFieldFromPath(field, oldPath);
        insertFieldAtPath(field, newPath);
        if (errors.value[oldPath] || errors.value[newPath]) {
          setFieldError(oldPath, void 0);
          validateField(newPath);
        }
        await nextTick();
        if (!fieldExists(oldPath)) {
          unsetPath(formValues, oldPath);
        }
      });
    }
    const initialErrorMessage = unref(field.errorMessage);
    if (initialErrorMessage && (initialErrors === null || initialErrors === void 0 ? void 0 : initialErrors[fieldPath]) !== initialErrorMessage) {
      validateField(fieldPath);
    }
    delete initialErrors[fieldPath];
  }
  function unregisterField(field) {
    const fieldName = unref(field.name);
    const fieldInstance = fieldsByPath.value[fieldName];
    const isGroup = !!fieldInstance && isFieldGroup(fieldInstance);
    removeFieldFromPath(field, fieldName);
    nextTick(() => {
      var _a2;
      const shouldKeepValue = (_a2 = unref(field.keepValueOnUnmount)) !== null && _a2 !== void 0 ? _a2 : unref(keepValuesOnUnmount);
      const currentGroupValue = getFromPath(formValues, fieldName);
      const isSameGroup = isGroup && (fieldInstance === fieldsByPath.value[fieldName] || !fieldsByPath.value[fieldName]);
      if (isSameGroup && !shouldKeepValue) {
        if (Array.isArray(currentGroupValue)) {
          const valueIdx = currentGroupValue.findIndex((i2) => isEqual(i2, unref(field.checkedValue)));
          if (valueIdx > -1) {
            const newVal = [...currentGroupValue];
            newVal.splice(valueIdx, 1);
            setFieldValue(fieldName, newVal, { force: true });
          }
        } else if (currentGroupValue === unref(field.checkedValue)) {
          unsetPath(formValues, fieldName);
        }
      }
      if (!fieldExists(fieldName)) {
        setFieldError(fieldName, void 0);
        if (shouldKeepValue) {
          return;
        }
        if (isGroup && Array.isArray(currentGroupValue) && !isEmptyContainer(currentGroupValue)) {
          return;
        }
        unsetPath(formValues, fieldName);
      }
    });
  }
  async function validate2(opts2) {
    const mode = (opts2 === null || opts2 === void 0 ? void 0 : opts2.mode) || "force";
    if (mode === "force") {
      mutateAllFields((f2) => f2.meta.validated = true);
    }
    if (formCtx.validateSchema) {
      return formCtx.validateSchema(mode);
    }
    const validations = await Promise.all(Object.values(fieldsByPath.value).map((field) => {
      const fieldInstance = Array.isArray(field) ? field[0] : field;
      if (!fieldInstance) {
        return Promise.resolve({ key: "", valid: true, errors: [] });
      }
      return fieldInstance.validate(opts2).then((result) => {
        return {
          key: unref(fieldInstance.name),
          valid: result.valid,
          errors: result.errors
        };
      });
    }));
    const results = {};
    const errors2 = {};
    for (const validation of validations) {
      results[validation.key] = {
        valid: validation.valid,
        errors: validation.errors
      };
      if (validation.errors.length) {
        errors2[validation.key] = validation.errors[0];
      }
    }
    return {
      valid: validations.every((r2) => r2.valid),
      results,
      errors: errors2
    };
  }
  async function validateField(field) {
    const fieldInstance = fieldsByPath.value[field];
    if (!fieldInstance) {
      return Promise.resolve({ errors: [], valid: true });
    }
    if (Array.isArray(fieldInstance)) {
      return fieldInstance.map((f2) => f2.validate())[0];
    }
    return fieldInstance.validate();
  }
  function unsetInitialValue(path) {
    unsetPath(initialValues.value, path);
  }
  function stageInitialValue(path, value, updateOriginal = false) {
    setInPath(formValues, path, value);
    setFieldInitialValue(path, value);
    if (updateOriginal && !(opts === null || opts === void 0 ? void 0 : opts.initialValues)) {
      setInPath(originalInitialValues.value, path, klona(value));
    }
  }
  function setFieldInitialValue(path, value) {
    setInPath(initialValues.value, path, klona(value));
  }
  async function _validateSchema() {
    const schemaValue = unref(schema);
    if (!schemaValue) {
      return { valid: true, results: {}, errors: {} };
    }
    const formResult = isYupValidator(schemaValue) ? await validateYupSchema(schemaValue, formValues) : await validateObjectSchema(schemaValue, formValues, {
      names: fieldNames.value,
      bailsMap: fieldBailsMap.value
    });
    return formResult;
  }
  const submitForm = handleSubmit((_2, { evt }) => {
    if (isFormSubmitEvent(evt)) {
      evt.target.submit();
    }
  });
  onMounted(() => {
    if (opts === null || opts === void 0 ? void 0 : opts.initialErrors) {
      setErrors(opts.initialErrors);
    }
    if (opts === null || opts === void 0 ? void 0 : opts.initialTouched) {
      setTouched(opts.initialTouched);
    }
    if (opts === null || opts === void 0 ? void 0 : opts.validateOnMount) {
      validate2();
      return;
    }
    if (formCtx.validateSchema) {
      formCtx.validateSchema("silent");
    }
  });
  if (isRef(schema)) {
    watch(schema, () => {
      var _a2;
      (_a2 = formCtx.validateSchema) === null || _a2 === void 0 ? void 0 : _a2.call(formCtx, "validated-only");
    });
  }
  provide(FormContextKey, formCtx);
  return Object.assign(Object.assign({}, formCtx), { handleReset: () => resetForm(), submitForm });
}
function useFormMeta(fieldsByPath, currentValues, initialValues, errors) {
  const MERGE_STRATEGIES = {
    touched: "some",
    pending: "some",
    valid: "every"
  };
  const isDirty = computed(() => {
    return !isEqual(currentValues, unref(initialValues));
  });
  function calculateFlags() {
    const fields = Object.values(fieldsByPath.value).flat(1).filter(Boolean);
    return keysOf(MERGE_STRATEGIES).reduce((acc, flag) => {
      const mergeMethod = MERGE_STRATEGIES[flag];
      acc[flag] = fields[mergeMethod]((field) => field.meta[flag]);
      return acc;
    }, {});
  }
  const flags = reactive(calculateFlags());
  watchEffect(() => {
    const value = calculateFlags();
    flags.touched = value.touched;
    flags.valid = value.valid;
    flags.pending = value.pending;
  });
  return computed(() => {
    return Object.assign(Object.assign({ initialValues: unref(initialValues) }, flags), { valid: flags.valid && !keysOf(errors.value).length, dirty: isDirty.value });
  });
}
function useFormInitialValues(fields, formValues, providedValues) {
  const initialValues = ref(klona(unref(providedValues)) || {});
  const originalInitialValues = ref(klona(unref(providedValues)) || {});
  function setInitialValues(values, updateFields = false) {
    initialValues.value = klona(values);
    originalInitialValues.value = klona(values);
    if (!updateFields) {
      return;
    }
    keysOf(fields.value).forEach((fieldPath) => {
      const field = fields.value[fieldPath];
      const wasTouched = Array.isArray(field) ? field.some((f2) => f2.meta.touched) : field === null || field === void 0 ? void 0 : field.meta.touched;
      if (!field || wasTouched) {
        return;
      }
      const newValue = getFromPath(initialValues.value, fieldPath);
      setInPath(formValues, fieldPath, klona(newValue));
    });
  }
  if (isRef(providedValues)) {
    watch(providedValues, (value) => {
      setInitialValues(value, true);
    }, {
      deep: true
    });
  }
  return {
    initialValues,
    originalInitialValues,
    setInitialValues
  };
}
function useErrorBag(initialErrors) {
  const errorBag = ref({});
  function normalizeErrorItem(message) {
    return Array.isArray(message) ? message : message ? [message] : [];
  }
  function setFieldErrorBag(field, message) {
    if (!message) {
      delete errorBag.value[field];
      return;
    }
    errorBag.value[field] = normalizeErrorItem(message);
  }
  function setErrorBag(fields) {
    errorBag.value = keysOf(fields).reduce((acc, key) => {
      const message = fields[key];
      if (message) {
        acc[key] = normalizeErrorItem(message);
      }
      return acc;
    }, {});
  }
  if (initialErrors) {
    setErrorBag(initialErrors);
  }
  return {
    errorBag,
    setErrorBag,
    setFieldErrorBag
  };
}
defineComponent({
  name: "Form",
  inheritAttrs: false,
  props: {
    as: {
      type: String,
      default: "form"
    },
    validationSchema: {
      type: Object,
      default: void 0
    },
    initialValues: {
      type: Object,
      default: void 0
    },
    initialErrors: {
      type: Object,
      default: void 0
    },
    initialTouched: {
      type: Object,
      default: void 0
    },
    validateOnMount: {
      type: Boolean,
      default: false
    },
    onSubmit: {
      type: Function,
      default: void 0
    },
    onInvalidSubmit: {
      type: Function,
      default: void 0
    },
    keepValues: {
      type: Boolean,
      default: false
    }
  },
  setup(props, ctx) {
    const initialValues = toRef(props, "initialValues");
    const validationSchema = toRef(props, "validationSchema");
    const keepValues = toRef(props, "keepValues");
    const { errors, values, meta, isSubmitting, submitCount, controlledValues, validate: validate2, validateField, handleReset, resetForm, handleSubmit, setErrors, setFieldError, setFieldValue, setValues, setFieldTouched, setTouched, resetField } = useForm({
      validationSchema: validationSchema.value ? validationSchema : void 0,
      initialValues,
      initialErrors: props.initialErrors,
      initialTouched: props.initialTouched,
      validateOnMount: props.validateOnMount,
      keepValuesOnUnmount: keepValues
    });
    const submitForm = handleSubmit((_2, { evt }) => {
      if (isFormSubmitEvent(evt)) {
        evt.target.submit();
      }
    }, props.onInvalidSubmit);
    const onSubmit = props.onSubmit ? handleSubmit(props.onSubmit, props.onInvalidSubmit) : submitForm;
    function handleFormReset(e2) {
      if (isEvent(e2)) {
        e2.preventDefault();
      }
      handleReset();
      if (typeof ctx.attrs.onReset === "function") {
        ctx.attrs.onReset();
      }
    }
    function handleScopedSlotSubmit(evt, onSubmit2) {
      const onSuccess = typeof evt === "function" && !onSubmit2 ? evt : onSubmit2;
      return handleSubmit(onSuccess, props.onInvalidSubmit)(evt);
    }
    function getValues() {
      return klona(values);
    }
    function getMeta() {
      return klona(meta.value);
    }
    function getErrors() {
      return klona(errors.value);
    }
    function slotProps() {
      return {
        meta: meta.value,
        errors: errors.value,
        values,
        isSubmitting: isSubmitting.value,
        submitCount: submitCount.value,
        controlledValues: controlledValues.value,
        validate: validate2,
        validateField,
        handleSubmit: handleScopedSlotSubmit,
        handleReset,
        submitForm,
        setErrors,
        setFieldError,
        setFieldValue,
        setValues,
        setFieldTouched,
        setTouched,
        resetForm,
        resetField,
        getValues,
        getMeta,
        getErrors
      };
    }
    ctx.expose({
      setFieldError,
      setErrors,
      setFieldValue,
      setValues,
      setFieldTouched,
      setTouched,
      resetForm,
      validate: validate2,
      validateField,
      resetField,
      getValues,
      getMeta,
      getErrors
    });
    return function renderForm() {
      const tag = props.as === "form" ? props.as : resolveDynamicComponent(props.as);
      const children = normalizeChildren(tag, ctx, slotProps);
      if (!props.as) {
        return children;
      }
      const formAttrs = props.as === "form" ? {
        // Disables native validation as vee-validate will handle it.
        novalidate: true
      } : {};
      return h$1(tag, Object.assign(Object.assign(Object.assign({}, formAttrs), ctx.attrs), { onSubmit, onReset: handleFormReset }), children);
    };
  }
});
function useFieldArray(arrayPath) {
  const form = injectWithSelf(FormContextKey, void 0);
  const fields = ref([]);
  const noOp = () => {
  };
  const noOpApi = {
    fields,
    remove: noOp,
    push: noOp,
    swap: noOp,
    insert: noOp,
    update: noOp,
    replace: noOp,
    prepend: noOp,
    move: noOp
  };
  if (!form) {
    return noOpApi;
  }
  if (!unref(arrayPath)) {
    return noOpApi;
  }
  const alreadyExists = form.fieldArrays.find((a2) => unref(a2.path) === unref(arrayPath));
  if (alreadyExists) {
    return alreadyExists;
  }
  let entryCounter = 0;
  function initFields() {
    const currentValues = getFromPath(form === null || form === void 0 ? void 0 : form.values, unref(arrayPath), []) || [];
    fields.value = currentValues.map(createEntry);
    updateEntryFlags();
  }
  initFields();
  function updateEntryFlags() {
    const fieldsLength = fields.value.length;
    for (let i2 = 0; i2 < fieldsLength; i2++) {
      const entry = fields.value[i2];
      entry.isFirst = i2 === 0;
      entry.isLast = i2 === fieldsLength - 1;
    }
  }
  function createEntry(value) {
    const key = entryCounter++;
    const entry = {
      key,
      value: computedDeep({
        get() {
          const currentValues = getFromPath(form === null || form === void 0 ? void 0 : form.values, unref(arrayPath), []) || [];
          const idx = fields.value.findIndex((e2) => e2.key === key);
          return idx === -1 ? value : currentValues[idx];
        },
        set(value2) {
          const idx = fields.value.findIndex((e2) => e2.key === key);
          if (idx === -1) {
            return;
          }
          update(idx, value2);
        }
      }),
      isFirst: false,
      isLast: false
    };
    return entry;
  }
  function remove(idx) {
    const pathName = unref(arrayPath);
    const pathValue = getFromPath(form === null || form === void 0 ? void 0 : form.values, pathName);
    if (!pathValue || !Array.isArray(pathValue)) {
      return;
    }
    const newValue = [...pathValue];
    newValue.splice(idx, 1);
    form === null || form === void 0 ? void 0 : form.unsetInitialValue(pathName + `[${idx}]`);
    form === null || form === void 0 ? void 0 : form.setFieldValue(pathName, newValue);
    fields.value.splice(idx, 1);
    updateEntryFlags();
  }
  function push(value) {
    const pathName = unref(arrayPath);
    const pathValue = getFromPath(form === null || form === void 0 ? void 0 : form.values, pathName);
    const normalizedPathValue = isNullOrUndefined$1(pathValue) ? [] : pathValue;
    if (!Array.isArray(normalizedPathValue)) {
      return;
    }
    const newValue = [...normalizedPathValue];
    newValue.push(value);
    form === null || form === void 0 ? void 0 : form.stageInitialValue(pathName + `[${newValue.length - 1}]`, value);
    form === null || form === void 0 ? void 0 : form.setFieldValue(pathName, newValue);
    fields.value.push(createEntry(value));
    updateEntryFlags();
  }
  function swap(indexA, indexB) {
    const pathName = unref(arrayPath);
    const pathValue = getFromPath(form === null || form === void 0 ? void 0 : form.values, pathName);
    if (!Array.isArray(pathValue) || !(indexA in pathValue) || !(indexB in pathValue)) {
      return;
    }
    const newValue = [...pathValue];
    const newFields = [...fields.value];
    const temp = newValue[indexA];
    newValue[indexA] = newValue[indexB];
    newValue[indexB] = temp;
    const tempEntry = newFields[indexA];
    newFields[indexA] = newFields[indexB];
    newFields[indexB] = tempEntry;
    form === null || form === void 0 ? void 0 : form.setFieldValue(pathName, newValue);
    fields.value = newFields;
    updateEntryFlags();
  }
  function insert(idx, value) {
    const pathName = unref(arrayPath);
    const pathValue = getFromPath(form === null || form === void 0 ? void 0 : form.values, pathName);
    if (!Array.isArray(pathValue) || pathValue.length < idx) {
      return;
    }
    const newValue = [...pathValue];
    const newFields = [...fields.value];
    newValue.splice(idx, 0, value);
    newFields.splice(idx, 0, createEntry(value));
    form === null || form === void 0 ? void 0 : form.setFieldValue(pathName, newValue);
    fields.value = newFields;
    updateEntryFlags();
  }
  function replace(arr) {
    const pathName = unref(arrayPath);
    form === null || form === void 0 ? void 0 : form.setFieldValue(pathName, arr);
    initFields();
  }
  function update(idx, value) {
    const pathName = unref(arrayPath);
    const pathValue = getFromPath(form === null || form === void 0 ? void 0 : form.values, pathName);
    if (!Array.isArray(pathValue) || pathValue.length - 1 < idx) {
      return;
    }
    form === null || form === void 0 ? void 0 : form.setFieldValue(`${pathName}[${idx}]`, value);
    form === null || form === void 0 ? void 0 : form.validate({ mode: "validated-only" });
  }
  function prepend(value) {
    const pathName = unref(arrayPath);
    const pathValue = getFromPath(form === null || form === void 0 ? void 0 : form.values, pathName);
    const normalizedPathValue = isNullOrUndefined$1(pathValue) ? [] : pathValue;
    if (!Array.isArray(normalizedPathValue)) {
      return;
    }
    const newValue = [value, ...normalizedPathValue];
    form === null || form === void 0 ? void 0 : form.stageInitialValue(pathName + `[${newValue.length - 1}]`, value);
    form === null || form === void 0 ? void 0 : form.setFieldValue(pathName, newValue);
    fields.value.unshift(createEntry(value));
    updateEntryFlags();
  }
  function move(oldIdx, newIdx) {
    const pathName = unref(arrayPath);
    const pathValue = getFromPath(form === null || form === void 0 ? void 0 : form.values, pathName);
    const newValue = isNullOrUndefined$1(pathValue) ? [] : [...pathValue];
    if (!Array.isArray(pathValue) || !(oldIdx in pathValue) || !(newIdx in pathValue)) {
      return;
    }
    const newFields = [...fields.value];
    const movedItem = newFields[oldIdx];
    newFields.splice(oldIdx, 1);
    newFields.splice(newIdx, 0, movedItem);
    const movedValue = newValue[oldIdx];
    newValue.splice(oldIdx, 1);
    newValue.splice(newIdx, 0, movedValue);
    form === null || form === void 0 ? void 0 : form.setFieldValue(pathName, newValue);
    fields.value = newFields;
    updateEntryFlags();
  }
  const fieldArrayCtx = {
    fields,
    remove,
    push,
    swap,
    insert,
    update,
    replace,
    prepend,
    move
  };
  form.fieldArrays.push(Object.assign({ path: arrayPath, reset: initFields }, fieldArrayCtx));
  onBeforeUnmount(() => {
    const idx = form.fieldArrays.findIndex((i2) => unref(i2.path) === unref(arrayPath));
    if (idx >= 0) {
      form.fieldArrays.splice(idx, 1);
    }
  });
  return fieldArrayCtx;
}
defineComponent({
  name: "FieldArray",
  inheritAttrs: false,
  props: {
    name: {
      type: String,
      required: true
    }
  },
  setup(props, ctx) {
    const { push, remove, swap, insert, replace, update, prepend, move, fields } = useFieldArray(toRef(props, "name"));
    function slotProps() {
      return {
        fields: fields.value,
        push,
        remove,
        swap,
        insert,
        update,
        replace,
        prepend,
        move
      };
    }
    ctx.expose({
      push,
      remove,
      swap,
      insert,
      update,
      replace,
      prepend,
      move
    });
    return () => {
      const children = normalizeChildren(void 0, ctx, slotProps);
      return children;
    };
  }
});
defineComponent({
  name: "ErrorMessage",
  props: {
    as: {
      type: String,
      default: void 0
    },
    name: {
      type: String,
      required: true
    }
  },
  setup(props, ctx) {
    const form = inject(FormContextKey, void 0);
    const message = computed(() => {
      return form === null || form === void 0 ? void 0 : form.errors.value[props.name];
    });
    function slotProps() {
      return {
        message: message.value
      };
    }
    return () => {
      if (!message.value) {
        return void 0;
      }
      const tag = props.as ? resolveDynamicComponent(props.as) : props.as;
      const children = normalizeChildren(tag, ctx, slotProps);
      const attrs = Object.assign({ role: "alert" }, ctx.attrs);
      if (!tag && (Array.isArray(children) || !children) && (children === null || children === void 0 ? void 0 : children.length)) {
        return children;
      }
      if ((Array.isArray(children) || !children) && !(children === null || children === void 0 ? void 0 : children.length)) {
        return h$1(tag || "span", attrs, message.value);
      }
      return h$1(tag, attrs, children);
    };
  }
});
const EditorFormConfigEnv_vue_vue_type_style_index_0_scoped_41d5bd73_lang = "";
function useFormValidation(mergedEnv) {
  const { handleSubmit, errors, values, validate: validate2 } = useForm();
  const { value: fieldName } = useField("name", "required", {
    initialValue: mergedEnv.value.name || ""
  });
  const { value: fieldShortName } = useField("shortName", "", {
    initialValue: mergedEnv.value.shortName || ""
  });
  const { value: fieldUrl } = useField("url", "required|url", {
    initialValue: mergedEnv.value.url || ""
  });
  const { value: fieldAppendUrlParams } = useField("appendUrlParams", "urlParams", {
    initialValue: mergedEnv.value.appendUrlParams || ""
  });
  const { value: fieldRemoveUrlParams } = useField("removeUrlParams", "list", {
    initialValue: mergedEnv.value.removeUrlParams || ""
  });
  return {
    handleSubmit,
    values,
    validate: validate2,
    fields: {
      errors,
      fieldName,
      fieldShortName,
      fieldUrl,
      fieldAppendUrlParams,
      fieldRemoveUrlParams
    }
  };
}
const _sfc_main$e = defineComponent({
  name: "EditorFormConfigEnv",
  components: {
    CoreButton,
    CoreInput,
    ConfirmationDeleteButton,
    EditorFormBadge,
    EditorFormRibbon
  },
  props: {
    newEnv: {
      type: Boolean,
      default: false
    },
    env: {
      type: Object,
      required: true
    },
    config: {
      type: Object,
      required: true
    },
    projectName: {
      type: String,
      required: false,
      default: ""
    }
  },
  emits: ["update-env", "delete-env", "clone-env", "create-new-env", "cancel-new-env"],
  setup(props, context) {
    const deleteConfirm = ref(false);
    const ribbonEnabled = !window.ENV || window.ENV.WITHOUT_RIBBON !== true;
    const mergedEnv = computed(() => {
      const env = props.env ? cjs(cjs(cjs({}, DEFAULT_OPTIONS), props.config.options), props.env) : {};
      return env;
    });
    const { handleSubmit, values, validate: validate2, fields } = useFormValidation(mergedEnv);
    const hasOverrides = computed(() => {
      const env = props.env;
      if (env) {
        const hasBadgeOverrides = env.displayBadge !== void 0 || env.badgeOptions !== void 0;
        const hasRibbonOverrides = env.displayRibbon !== void 0 || env.ribbonOptions !== void 0;
        const hasDisplayDomainOverrides = env.displayDomain !== void 0;
        const hasDisplayPingOverrides = env.pingUrl !== void 0;
        return hasBadgeOverrides || hasRibbonOverrides || hasDisplayDomainOverrides || hasDisplayPingOverrides;
      }
      return false;
    });
    const updateComputed = (data) => {
      const mergedEnv2 = cjs(cjs({}, props.env), data);
      context.emit("update-env", mergedEnv2);
    };
    const resetToGlobalOptions = () => {
      const { id, name, shortName, url, appendUrlParams, removeUrlParams } = props.env;
      const newEnv2 = {
        id,
        name,
        shortName,
        url,
        appendUrlParams,
        removeUrlParams
      };
      removeUndefined(newEnv2);
      context.emit("update-env", newEnv2);
    };
    const submit = handleSubmit(async () => {
      const isValid = await validate2();
      if (isValid && props.newEnv) {
        const mergedEnv2 = cjs(cjs({}, props.env), values);
        removeEmptyString(mergedEnv2);
        context.emit("create-new-env", mergedEnv2);
      }
    });
    const update = async () => {
      if (!props.newEnv) {
        const isValid = await validate2();
        if (isValid) {
          const mergedEnv2 = cjs(cjs({}, props.env), values);
          removeEmptyString(mergedEnv2);
          context.emit("update-env", mergedEnv2);
        }
      }
    };
    const createComputed = createComputedFactory(update);
    const displayDomain = createComputed(
      () => mergedEnv.value.displayDomain,
      (val) => ({ displayDomain: val })
    );
    const pingUrl = createComputed(
      () => mergedEnv.value.pingUrl,
      (val) => ({ pingUrl: val })
    );
    return {
      displayDomain,
      pingUrl,
      hasOverrides,
      deleteConfirm,
      ribbonEnabled,
      mergedEnv,
      updateComputed,
      resetToGlobalOptions,
      submit,
      update,
      ...fields
    };
  }
});
const _withScopeId$5 = (n2) => (pushScopeId("data-v-41d5bd73"), n2 = n2(), popScopeId(), n2);
const _hoisted_1$e = { key: 0 };
const _hoisted_2$e = { key: 0 };
const _hoisted_3$e = /* @__PURE__ */ _withScopeId$5(() => /* @__PURE__ */ createBaseVNode("span", null, " Environment settings ", -1));
const _hoisted_4$5 = { class: "env-btns" };
const _hoisted_5$4 = { class: "basis-settings" };
const _hoisted_6$3 = /* @__PURE__ */ _withScopeId$5(() => /* @__PURE__ */ createBaseVNode("p", { class: "mandatory-field-message" }, [
  /* @__PURE__ */ createBaseVNode("i", null, [
    /* @__PURE__ */ createTextVNode("Fields with "),
    /* @__PURE__ */ createBaseVNode("b", null, "*"),
    /* @__PURE__ */ createTextVNode(" are mandatory")
  ])
], -1));
const _hoisted_7$3 = { class: "label-set" };
const _hoisted_8$3 = ["for"];
const _hoisted_9$2 = /* @__PURE__ */ _withScopeId$5(() => /* @__PURE__ */ createBaseVNode("b", null, "*", -1));
const _hoisted_10$1 = {
  key: 0,
  class: "error"
};
const _hoisted_11$1 = {
  key: 0,
  class: "label-set"
};
const _hoisted_12$1 = ["for"];
const _hoisted_13$1 = { class: "label-set" };
const _hoisted_14$1 = ["for"];
const _hoisted_15$1 = /* @__PURE__ */ _withScopeId$5(() => /* @__PURE__ */ createBaseVNode("b", null, "*", -1));
const _hoisted_16$1 = {
  key: 0,
  class: "error"
};
const _hoisted_17$1 = { key: 0 };
const _hoisted_18$1 = { class: "label-set" };
const _hoisted_19$1 = ["for"];
const _hoisted_20$1 = {
  key: 0,
  class: "error"
};
const _hoisted_21$1 = { class: "label-set" };
const _hoisted_22$1 = ["for"];
const _hoisted_23$1 = {
  key: 0,
  class: "error"
};
const _hoisted_24$1 = {
  key: 0,
  class: "create-btns"
};
const _hoisted_25$1 = {
  key: 0,
  class: "override-options"
};
const _hoisted_26$1 = { class: "override-message" };
const _hoisted_27$1 = /* @__PURE__ */ _withScopeId$5(() => /* @__PURE__ */ createBaseVNode("span", null, [
  /* @__PURE__ */ createTextVNode(" Overrides global options for this environment "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createBaseVNode("i", null, "Fields with * are using global options, change to override")
], -1));
const _hoisted_28$1 = { class: "field-domain" };
const _hoisted_29$1 = { class: "label-set" };
const _hoisted_30$1 = ["id"];
const _hoisted_31$1 = ["for"];
const _hoisted_32$1 = { class: "field-domain" };
const _hoisted_33$1 = { class: "label-set" };
const _hoisted_34$1 = ["id"];
const _hoisted_35$1 = ["for"];
function _sfc_render$e(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_CoreButton = resolveComponent("CoreButton");
  const _component_ConfirmationDeleteButton = resolveComponent("ConfirmationDeleteButton");
  const _component_CoreInput = resolveComponent("CoreInput");
  const _component_EditorFormBadge = resolveComponent("EditorFormBadge");
  const _component_EditorFormRibbon = resolveComponent("EditorFormRibbon");
  return openBlock(), createElementBlock("div", {
    class: normalizeClass(["side-panel", { "has-env": !!_ctx.env }])
  }, [
    createBaseVNode("h3", null, [
      _ctx.newEnv ? (openBlock(), createElementBlock("span", _hoisted_1$e, [
        createTextVNode(" Create a new environment for "),
        createBaseVNode("i", null, toDisplayString(_ctx.projectName), 1),
        createTextVNode(" project ")
      ])) : createCommentVNode("", true),
      createVNode(Transition, { name: "fade-in" }, {
        default: withCtx(() => [
          !_ctx.newEnv ? (openBlock(), createElementBlock("div", _hoisted_2$e, [
            _hoisted_3$e,
            createBaseVNode("div", _hoisted_4$5, [
              createVNode(_component_ConfirmationDeleteButton, {
                modelValue: _ctx.deleteConfirm,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => _ctx.deleteConfirm = $event),
                onAction: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("delete-env", _ctx.env.id))
              }, {
                beforeButton: withCtx(() => [
                  createVNode(_component_CoreButton, {
                    elevation: "",
                    class: "clone-env",
                    "icon-name": "CloneIcon",
                    onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("clone-env", _ctx.env.id))
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Clone ")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ])
          ])) : createCommentVNode("", true)
        ]),
        _: 1
      })
    ]),
    createBaseVNode("form", {
      onSubmit: _cache[21] || (_cache[21] = ($event) => _ctx.submit($event))
    }, [
      createBaseVNode("fieldset", _hoisted_5$4, [
        _hoisted_6$3,
        createBaseVNode("div", _hoisted_7$3, [
          createBaseVNode("label", {
            for: _ctx.$id("name")
          }, [
            createTextVNode(" Name "),
            _hoisted_9$2
          ], 8, _hoisted_8$3),
          createBaseVNode("div", null, [
            createVNode(_component_CoreInput, {
              type: "text",
              class: normalizeClass({ error: _ctx.errors.name }),
              id: _ctx.$id("name"),
              onFocusout: _cache[3] || (_cache[3] = ($event) => _ctx.update()),
              onErase: _cache[4] || (_cache[4] = ($event) => _ctx.update()),
              "focus-on-mounted": _ctx.newEnv,
              modelValue: _ctx.fieldName,
              "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => _ctx.fieldName = $event)
            }, null, 8, ["class", "id", "focus-on-mounted", "modelValue"]),
            _ctx.errors.name ? (openBlock(), createElementBlock("div", _hoisted_10$1, "Name field is required.")) : createCommentVNode("", true)
          ])
        ]),
        createVNode(Transition, { name: "fade-in" }, {
          default: withCtx(() => [
            !_ctx.newEnv ? (openBlock(), createElementBlock("div", _hoisted_11$1, [
              createBaseVNode("label", {
                for: _ctx.$id("short-name")
              }, " Short name ", 8, _hoisted_12$1),
              createVNode(_component_CoreInput, {
                id: _ctx.$id("short-name"),
                type: "text",
                maxlength: 4,
                onFocusout: _cache[6] || (_cache[6] = ($event) => _ctx.update()),
                onErase: _cache[7] || (_cache[7] = ($event) => _ctx.update()),
                modelValue: _ctx.fieldShortName,
                "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => _ctx.fieldShortName = $event)
              }, null, 8, ["id", "modelValue"])
            ])) : createCommentVNode("", true)
          ]),
          _: 1
        }),
        createBaseVNode("div", _hoisted_13$1, [
          createBaseVNode("label", {
            for: _ctx.$id("url")
          }, [
            createTextVNode(" Url "),
            _hoisted_15$1
          ], 8, _hoisted_14$1),
          createBaseVNode("div", null, [
            createVNode(_component_CoreInput, {
              class: normalizeClass({ error: _ctx.errors.url }),
              id: _ctx.$id("url"),
              type: "text",
              placeholder: "eg: https://www.ecosia.org",
              onFocusout: _cache[9] || (_cache[9] = ($event) => _ctx.update()),
              onErase: _cache[10] || (_cache[10] = ($event) => _ctx.update()),
              modelValue: _ctx.fieldUrl,
              "onUpdate:modelValue": _cache[11] || (_cache[11] = ($event) => _ctx.fieldUrl = $event)
            }, null, 8, ["class", "id", "modelValue"]),
            _ctx.errors.url ? (openBlock(), createElementBlock("div", _hoisted_16$1, " Url field is required and must have an url format. ")) : createCommentVNode("", true)
          ])
        ]),
        createVNode(Transition, { name: "fade-in" }, {
          default: withCtx(() => [
            !_ctx.newEnv ? (openBlock(), createElementBlock("div", _hoisted_17$1, [
              createBaseVNode("div", _hoisted_18$1, [
                createBaseVNode("label", {
                  for: _ctx.$id("append-url-params")
                }, " Append url params ", 8, _hoisted_19$1),
                createBaseVNode("div", null, [
                  createVNode(_component_CoreInput, {
                    class: normalizeClass({ error: _ctx.errors.appendUrlParams }),
                    id: _ctx.$id("append-url-params"),
                    type: "text",
                    placeholder: "eg: search=true&query=dev&...",
                    name: "appendUrlParams",
                    onFocusout: _cache[12] || (_cache[12] = ($event) => _ctx.update()),
                    onErase: _cache[13] || (_cache[13] = ($event) => _ctx.update()),
                    modelValue: _ctx.fieldAppendUrlParams,
                    "onUpdate:modelValue": _cache[14] || (_cache[14] = ($event) => _ctx.fieldAppendUrlParams = $event)
                  }, null, 8, ["class", "id", "modelValue"]),
                  _ctx.errors.appendUrlParams ? (openBlock(), createElementBlock("div", _hoisted_20$1, " Append url params is not valid. (eg: search=true&query=dev ) ")) : createCommentVNode("", true)
                ])
              ]),
              createBaseVNode("div", _hoisted_21$1, [
                createBaseVNode("label", {
                  for: _ctx.$id("remove-url-params")
                }, " Remove url params ", 8, _hoisted_22$1),
                createBaseVNode("div", null, [
                  createVNode(_component_CoreInput, {
                    id: _ctx.$id("remove-url-params"),
                    class: normalizeClass({ error: _ctx.errors.removeUrlParams }),
                    type: "text",
                    placeholder: "eg: search,query,...",
                    onFocusout: _cache[15] || (_cache[15] = ($event) => _ctx.update()),
                    onErase: _cache[16] || (_cache[16] = ($event) => _ctx.update()),
                    modelValue: _ctx.fieldRemoveUrlParams,
                    "onUpdate:modelValue": _cache[17] || (_cache[17] = ($event) => _ctx.fieldRemoveUrlParams = $event)
                  }, null, 8, ["id", "class", "modelValue"]),
                  _ctx.errors.removeUrlParams ? (openBlock(), createElementBlock("div", _hoisted_23$1, " Remove url params is not valid. (eg: search,query ) ")) : createCommentVNode("", true)
                ])
              ])
            ])) : createCommentVNode("", true)
          ]),
          _: 1
        }),
        _ctx.newEnv ? (openBlock(), createElementBlock("div", _hoisted_24$1, [
          createVNode(_component_CoreButton, {
            "icon-name": "AddIcon",
            variation: "positive",
            class: "create-env-btn"
          }, {
            default: withCtx(() => [
              createTextVNode(" Create and configure ")
            ]),
            _: 1
          }),
          createVNode(_component_CoreButton, {
            class: "cancel-btn",
            onClick: _cache[18] || (_cache[18] = withModifiers(($event) => _ctx.$emit("cancel-new-env"), ["stop", "prevent"]))
          }, {
            default: withCtx(() => [
              createTextVNode(" Cancel ")
            ]),
            _: 1
          })
        ])) : createCommentVNode("", true)
      ]),
      createVNode(Transition, { name: "fade-in" }, {
        default: withCtx(() => [
          !_ctx.newEnv ? (openBlock(), createElementBlock("div", _hoisted_25$1, [
            createBaseVNode("div", _hoisted_26$1, [
              _hoisted_27$1,
              _ctx.hasOverrides ? (openBlock(), createBlock(_component_CoreButton, {
                key: 0,
                elevation: "",
                "icon-name": "GoBackIcon",
                onClick: withModifiers(_ctx.resetToGlobalOptions, ["prevent"])
              }, {
                default: withCtx(() => [
                  createTextVNode(" Reset ")
                ]),
                _: 1
              }, 8, ["onClick"])) : createCommentVNode("", true)
            ]),
            _ctx.env ? (openBlock(), createBlock(_component_EditorFormBadge, {
              key: 0,
              options: _ctx.mergedEnv,
              env: _ctx.env,
              "onUpdate:options": _ctx.updateComputed
            }, null, 8, ["options", "env", "onUpdate:options"])) : createCommentVNode("", true),
            _ctx.env && _ctx.ribbonEnabled ? (openBlock(), createBlock(_component_EditorFormRibbon, {
              key: 1,
              class: "form-ribbon",
              options: _ctx.mergedEnv,
              env: _ctx.env,
              "onUpdate:options": _ctx.updateComputed
            }, null, 8, ["options", "env", "onUpdate:options"])) : createCommentVNode("", true),
            createBaseVNode("fieldset", _hoisted_28$1, [
              createBaseVNode("div", _hoisted_29$1, [
                withDirectives(createBaseVNode("input", {
                  id: _ctx.$id("display-domain"),
                  type: "checkbox",
                  "onUpdate:modelValue": _cache[19] || (_cache[19] = ($event) => _ctx.displayDomain = $event)
                }, null, 8, _hoisted_30$1), [
                  [vModelCheckbox, _ctx.displayDomain]
                ]),
                createBaseVNode("label", {
                  for: _ctx.$id("display-domain"),
                  class: normalizeClass({ defaulted: _ctx.env.displayDomain === void 0 })
                }, " Display domain ", 10, _hoisted_31$1)
              ])
            ]),
            createBaseVNode("fieldset", _hoisted_32$1, [
              createBaseVNode("div", _hoisted_33$1, [
                withDirectives(createBaseVNode("input", {
                  id: _ctx.$id("ping-url"),
                  type: "checkbox",
                  "onUpdate:modelValue": _cache[20] || (_cache[20] = ($event) => _ctx.pingUrl = $event)
                }, null, 8, _hoisted_34$1), [
                  [vModelCheckbox, _ctx.pingUrl]
                ]),
                createBaseVNode("label", {
                  for: _ctx.$id("ping-url"),
                  class: normalizeClass({ defaulted: _ctx.env.pingUrl === void 0 })
                }, " Check if environment url is up ", 10, _hoisted_35$1)
              ])
            ])
          ])) : createCommentVNode("", true)
        ]),
        _: 1
      })
    ], 32)
  ], 2);
}
const EditorFormConfigEnv = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["render", _sfc_render$e], ["__scopeId", "data-v-41d5bd73"]]);
const EditorFormConfigProject_vue_vue_type_style_index_0_lang = "";
const EditorFormConfigProject_vue_vue_type_style_index_1_scoped_8ad937f2_lang = "";
const _sfc_main$d = defineComponent({
  name: "EditorFormConfigProject",
  components: {
    CoreButton,
    ConfirmationDeleteButton
  },
  props: {
    projectId: {
      type: [Number, String],
      default: () => {
      }
    },
    config: {
      type: Object,
      default: () => {
      }
    },
    selectedEnvId: {
      type: [Number, String],
      default: null
    },
    selectedProjectId: {
      type: [Number, String],
      default: null
    }
  },
  emits: ["select-env", "new-env", "drop-env", "delete-project", "update-project"],
  setup(props, context) {
    const deleteConfirm = ref(false);
    const projectNameEditable = ref(false);
    onMounted(() => {
      updateSortableEnvs();
    });
    const projectEnvs = computed(() => {
      return getProjectEnvs(props.config, props.projectId);
    });
    const projectName = computed(() => {
      const project = getProjectById(props.config, props.projectId);
      return project.name;
    });
    const updateProject2 = (data) => {
      context.emit("update-project", {
        projectId: props.projectId,
        data
      });
    };
    const onDrop = (e2) => {
      const { detail } = e2;
      const { origin, destination } = detail;
      context.emit("drop-env", {
        projectId: props.projectId,
        origin,
        destination
      });
    };
    return {
      projectEnvs,
      projectName,
      updateProject: updateProject2,
      onDrop,
      deleteConfirm,
      projectNameEditable
    };
  }
});
const _withScopeId$4 = (n2) => (pushScopeId("data-v-8ad937f2"), n2 = n2(), popScopeId(), n2);
const _hoisted_1$d = { class: "project-sortable-handle" };
const _hoisted_2$d = { class: "project-name" };
const _hoisted_3$d = ["value"];
const _hoisted_4$4 = { key: 1 };
const _hoisted_5$3 = ["onClick"];
const _hoisted_6$2 = { class: "env-name" };
const _hoisted_7$2 = { key: 1 };
const _hoisted_8$2 = /* @__PURE__ */ _withScopeId$4(() => /* @__PURE__ */ createBaseVNode("br", null, null, -1));
const _hoisted_9$1 = { class: "action-buttons" };
function _sfc_render$d(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_DragListIcon = resolveComponent("DragListIcon");
  const _component_CoreButton = resolveComponent("CoreButton");
  const _component_ConfirmationDeleteButton = resolveComponent("ConfirmationDeleteButton");
  const _component_ArrowRightIcon = resolveComponent("ArrowRightIcon");
  return openBlock(), createElementBlock("li", {
    class: normalizeClass(["project-item", { "selected-project": _ctx.projectId === _ctx.selectedProjectId }])
  }, [
    createBaseVNode("header", null, [
      createBaseVNode("span", _hoisted_1$d, [
        createVNode(_component_DragListIcon, {
          height: "16px",
          width: "16px"
        })
      ]),
      createBaseVNode("div", _hoisted_2$d, [
        _ctx.projectNameEditable ? (openBlock(), createElementBlock("input", {
          key: 0,
          value: _ctx.projectName,
          onFocusout: _cache[0] || (_cache[0] = ($event) => _ctx.projectNameEditable = false),
          onInput: _cache[1] || (_cache[1] = (e2) => _ctx.updateProject({ name: e2.target.value }))
        }, null, 40, _hoisted_3$d)) : (openBlock(), createElementBlock("span", _hoisted_4$4, toDisplayString(_ctx.projectName), 1))
      ]),
      createVNode(_component_ConfirmationDeleteButton, {
        class: "delete-project",
        modelValue: _ctx.deleteConfirm,
        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => _ctx.deleteConfirm = $event),
        onAction: _cache[4] || (_cache[4] = ($event) => _ctx.$emit("delete-project", _ctx.projectId))
      }, {
        beforeButton: withCtx(() => [
          !_ctx.projectNameEditable ? (openBlock(), createBlock(_component_CoreButton, {
            key: 0,
            elevation: "",
            class: "edit-project-name",
            "icon-name": "EditTextIcon",
            onClick: _cache[2] || (_cache[2] = ($event) => _ctx.projectNameEditable = true)
          }, {
            default: withCtx(() => [
              createTextVNode(" Edit ")
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ]),
        _: 1
      }, 8, ["modelValue"])
    ]),
    _ctx.projectEnvs.length > 0 ? (openBlock(), createElementBlock("ul", {
      key: 0,
      class: "env-sortable",
      onSortupdate: _cache[5] || (_cache[5] = (...args) => _ctx.onDrop && _ctx.onDrop(...args))
    }, [
      (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.projectEnvs, (env) => {
        return openBlock(), createElementBlock("li", {
          key: "env-" + env.id,
          class: normalizeClass(["project-env", {
            "selected-env": _ctx.selectedEnvId != null ? env.id === _ctx.selectedEnvId : false
          }]),
          onClick: ($event) => _ctx.$emit("select-env", { envId: env.id, projectId: _ctx.projectId })
        }, [
          createBaseVNode("span", _hoisted_6$2, toDisplayString(env.name || env.shortName), 1),
          createVNode(_component_ArrowRightIcon, {
            height: "14px",
            width: "14px"
          })
        ], 10, _hoisted_5$3);
      }), 128))
    ], 32)) : (openBlock(), createElementBlock("h3", _hoisted_7$2, [
      createTextVNode(" There is currently no envs configured for this project. "),
      _hoisted_8$2,
      createTextVNode(' Click on "Add new env" button to add one. ')
    ])),
    createBaseVNode("div", _hoisted_9$1, [
      createVNode(_component_CoreButton, {
        "icon-name": "AddIcon",
        class: "add-new-env",
        variation: "positive",
        onClick: _cache[6] || (_cache[6] = ($event) => _ctx.$emit("new-env", _ctx.projectId)),
        "data-hint": "Try to add a new env. It will be attached to the project."
      }, {
        default: withCtx(() => [
          createTextVNode(" Add new env ")
        ]),
        _: 1
      })
    ])
  ], 2);
}
const EditorFormConfigProject = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["render", _sfc_render$d], ["__scopeId", "data-v-8ad937f2"]]);
const EditorFormConfigProjects_vue_vue_type_style_index_0_scoped_e4868766_lang = "";
const _sfc_main$c = defineComponent({
  name: "EditorFormConfigProjects",
  components: { CoreButton, EditorFormConfigProject },
  props: {
    config: {
      type: Object,
      default: () => {
      }
    },
    selectedEnvId: {
      type: [Number, String],
      default: null
    },
    selectedProjectId: {
      type: [Number, String],
      default: null
    }
  },
  emits: [
    "select-env",
    "new-env",
    "delete-project",
    "drop-env",
    "new-project",
    "update-project",
    "drop-project"
  ],
  setup(props, context) {
    onMounted(() => {
      setTimeout(() => {
        updateSortableProjects({
          handle: ".project-sortable-handle"
        });
      }, 100);
    });
    const hasProjects = computed(() => props.config.projects && props.config.projects.length > 0);
    const onDrop = (e2) => {
      const { detail } = e2;
      const { origin, destination } = detail;
      context.emit("drop-project", { origin, destination });
    };
    return {
      hasProjects,
      onDrop
    };
  }
});
const _withScopeId$3 = (n2) => (pushScopeId("data-v-e4868766"), n2 = n2(), popScopeId(), n2);
const _hoisted_1$c = { key: 0 };
const _hoisted_2$c = { key: 1 };
const _hoisted_3$c = /* @__PURE__ */ _withScopeId$3(() => /* @__PURE__ */ createBaseVNode("br", null, null, -1));
function _sfc_render$c(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_EditorFormConfigProject = resolveComponent("EditorFormConfigProject");
  const _component_CoreButton = resolveComponent("CoreButton");
  return openBlock(), createElementBlock("div", {
    class: normalizeClass({ "has-projects": _ctx.hasProjects })
  }, [
    _ctx.hasProjects ? (openBlock(), createElementBlock("div", _hoisted_1$c, [
      createBaseVNode("ul", {
        class: "project-sortable",
        onSortupdate: _cache[5] || (_cache[5] = (...args) => _ctx.onDrop && _ctx.onDrop(...args))
      }, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.config.projects, (project) => {
          return openBlock(), createBlock(_component_EditorFormConfigProject, {
            key: "project-" + project.id,
            config: _ctx.config,
            "project-id": project.id,
            "selected-env-id": _ctx.selectedEnvId,
            "selected-project-id": _ctx.selectedProjectId,
            onSelectEnv: _cache[0] || (_cache[0] = (data) => _ctx.$emit("select-env", data)),
            onDeleteProject: _cache[1] || (_cache[1] = (data) => _ctx.$emit("delete-project", data)),
            onNewEnv: _cache[2] || (_cache[2] = (data) => _ctx.$emit("new-env", data)),
            onDropEnv: _cache[3] || (_cache[3] = (data) => _ctx.$emit("drop-env", data)),
            onUpdateProject: _cache[4] || (_cache[4] = (data) => _ctx.$emit("update-project", data))
          }, null, 8, ["config", "project-id", "selected-env-id", "selected-project-id"]);
        }), 128))
      ], 32)
    ])) : (openBlock(), createElementBlock("h3", _hoisted_2$c, [
      createTextVNode(" There is currently no projects. "),
      _hoisted_3$c,
      createTextVNode(" Create one by clicking on the create button. ")
    ])),
    createBaseVNode("footer", null, [
      createVNode(_component_CoreButton, {
        "icon-name": "AddIcon",
        variation: "positive",
        class: "new-project",
        onClick: _cache[6] || (_cache[6] = ($event) => _ctx.$emit("new-project")),
        "data-hint": "Add fresh empty project. You can add new env after."
      }, {
        default: withCtx(() => [
          createTextVNode(" Add new project ")
        ]),
        _: 1
      })
    ])
  ], 2);
}
const EditorFormConfigProjects = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["render", _sfc_render$c], ["__scopeId", "data-v-e4868766"]]);
const EditorFormConfigGlobalOptions_vue_vue_type_style_index_0_scoped_66c0263b_lang = "";
const _sfc_main$b = defineComponent({
  name: "EditorFormConfigGlobalOptions",
  components: { CoreButton, EditorFormBadge, EditorFormRibbon },
  props: {
    options: {
      type: Object,
      default: () => {
      }
    }
  },
  emits: ["update:options"],
  setup(props, context) {
    const ribbonEnabled = ref(!window.ENV || window.ENV.WITHOUT_RIBBON !== true);
    const updateComputed = (data) => context.emit("update:options", cjs({ ...props.options }, data));
    const createComputed = createComputedFactory(updateComputed);
    const resetToDefaultOptions = () => context.emit("update:options", {});
    const mergedOptions = computed(() => {
      const options = cjs(cjs({}, DEFAULT_OPTIONS), props.options || {});
      return options;
    });
    const hasOptions = computed(() => {
      return Object.keys(props.options).length > 0;
    });
    const localOptions = [
      "displayDomain",
      "displayHeader",
      "displayFooter",
      "displaySeeProjectsLink",
      "colorScheme",
      "allowBugTrackerReporting",
      "pingUrl",
      "displayStyle",
      "switchEnvBetweenProjects"
    ].reduce((acc, key) => {
      acc[key] = createComputed(
        () => mergedOptions.value[key],
        (val) => ({ [key]: val })
      );
      return acc;
    }, {});
    return {
      mergedOptions,
      hasOptions,
      ribbonEnabled,
      ...localOptions,
      resetToDefaultOptions,
      updateComputed
    };
  }
});
const _withScopeId$2 = (n2) => (pushScopeId("data-v-66c0263b"), n2 = n2(), popScopeId(), n2);
const _hoisted_1$b = { class: "options-selector" };
const _hoisted_2$b = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("h2", null, "Global Options", -1));
const _hoisted_3$b = {
  class: "box-elevation",
  "data-intro": "This is where you configure your global options. Some options can be overrode per environment."
};
const _hoisted_4$3 = { class: "left-col" };
const _hoisted_5$2 = {
  class: "label-set",
  "display-style": ""
};
const _hoisted_6$1 = ["for"];
const _hoisted_7$1 = ["id"];
const _hoisted_8$1 = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("option", { value: "list" }, "List", -1));
const _hoisted_9 = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("option", { value: "grid" }, "Grid", -1));
const _hoisted_10 = [
  _hoisted_8$1,
  _hoisted_9
];
const _hoisted_11 = {
  class: "label-set",
  "display-domain": ""
};
const _hoisted_12 = ["id"];
const _hoisted_13 = ["for"];
const _hoisted_14 = {
  class: "label-set",
  "display-header": ""
};
const _hoisted_15 = ["id"];
const _hoisted_16 = ["for"];
const _hoisted_17 = {
  class: "label-set",
  "display-footer": ""
};
const _hoisted_18 = ["id"];
const _hoisted_19 = ["for"];
const _hoisted_20 = {
  class: "label-set",
  "display-projects-links": ""
};
const _hoisted_21 = ["id"];
const _hoisted_22 = ["for"];
const _hoisted_23 = {
  class: "label-set",
  "color-scheme": ""
};
const _hoisted_24 = ["for"];
const _hoisted_25 = ["id"];
const _hoisted_26 = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("option", { value: "system" }, "System preferences", -1));
const _hoisted_27 = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("option", { value: "light" }, "Light", -1));
const _hoisted_28 = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("option", { value: "dark" }, "Dark", -1));
const _hoisted_29 = [
  _hoisted_26,
  _hoisted_27,
  _hoisted_28
];
const _hoisted_30 = {
  class: "label-set",
  "allow-tracking": ""
};
const _hoisted_31 = ["id"];
const _hoisted_32 = ["for"];
const _hoisted_33 = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("br", null, null, -1));
const _hoisted_34 = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("i", null, "No personal information are collected. Not now Not ever.", -1));
const _hoisted_35 = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("br", null, null, -1));
const _hoisted_36 = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("i", null, "Please consider keeping it on, as it is every useful to improve the quality of this extension.", -1));
const _hoisted_37 = {
  class: "label-set",
  "ping-url": ""
};
const _hoisted_38 = ["id"];
const _hoisted_39 = ["for"];
const _hoisted_40 = {
  class: "label-set",
  "switch-env-projects": ""
};
const _hoisted_41 = ["id"];
const _hoisted_42 = ["for"];
const _hoisted_43 = { class: "right-col" };
const _hoisted_44 = { class: "third-col" };
function _sfc_render$b(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_EditorFormBadge = resolveComponent("EditorFormBadge");
  const _component_EditorFormRibbon = resolveComponent("EditorFormRibbon");
  const _component_CoreButton = resolveComponent("CoreButton");
  return openBlock(), createElementBlock("div", _hoisted_1$b, [
    _hoisted_2$b,
    createBaseVNode("form", _hoisted_3$b, [
      createBaseVNode("div", _hoisted_4$3, [
        createBaseVNode("div", _hoisted_5$2, [
          createBaseVNode("label", {
            for: _ctx.$id("display-style")
          }, "Display Style", 8, _hoisted_6$1),
          withDirectives(createBaseVNode("select", {
            id: _ctx.$id("display-style"),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => _ctx.displayStyle = $event)
          }, _hoisted_10, 8, _hoisted_7$1), [
            [vModelSelect, _ctx.displayStyle]
          ])
        ]),
        createBaseVNode("div", _hoisted_11, [
          withDirectives(createBaseVNode("input", {
            id: _ctx.$id("display-domain"),
            type: "checkbox",
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => _ctx.displayDomain = $event)
          }, null, 8, _hoisted_12), [
            [vModelCheckbox, _ctx.displayDomain]
          ]),
          createBaseVNode("label", {
            for: _ctx.$id("display-domain")
          }, " Display domain ", 8, _hoisted_13)
        ]),
        createBaseVNode("div", _hoisted_14, [
          withDirectives(createBaseVNode("input", {
            id: _ctx.$id("display-header"),
            type: "checkbox",
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => _ctx.displayHeader = $event)
          }, null, 8, _hoisted_15), [
            [vModelCheckbox, _ctx.displayHeader]
          ]),
          createBaseVNode("label", {
            for: _ctx.$id("display-header")
          }, " Display header ", 8, _hoisted_16)
        ]),
        createBaseVNode("div", _hoisted_17, [
          withDirectives(createBaseVNode("input", {
            id: _ctx.$id("display-footer"),
            type: "checkbox",
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => _ctx.displayFooter = $event)
          }, null, 8, _hoisted_18), [
            [vModelCheckbox, _ctx.displayFooter]
          ]),
          createBaseVNode("label", {
            for: _ctx.$id("display-footer")
          }, " Display footer ", 8, _hoisted_19)
        ]),
        createBaseVNode("div", _hoisted_20, [
          withDirectives(createBaseVNode("input", {
            id: _ctx.$id("display-projects-links"),
            type: "checkbox",
            "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => _ctx.displaySeeProjectsLink = $event)
          }, null, 8, _hoisted_21), [
            [vModelCheckbox, _ctx.displaySeeProjectsLink]
          ]),
          createBaseVNode("label", {
            for: _ctx.$id("display-projects-links")
          }, "Display see projects link", 8, _hoisted_22)
        ]),
        createBaseVNode("div", _hoisted_23, [
          createBaseVNode("label", {
            for: _ctx.$id("color-scheme")
          }, "Color Scheme", 8, _hoisted_24),
          withDirectives(createBaseVNode("select", {
            id: _ctx.$id("color-scheme"),
            "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => _ctx.colorScheme = $event)
          }, _hoisted_29, 8, _hoisted_25), [
            [vModelSelect, _ctx.colorScheme]
          ])
        ]),
        createBaseVNode("div", _hoisted_30, [
          withDirectives(createBaseVNode("input", {
            id: _ctx.$id("allow-tracking"),
            type: "checkbox",
            "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => _ctx.allowBugTrackerReporting = $event)
          }, null, 8, _hoisted_31), [
            [vModelCheckbox, _ctx.allowBugTrackerReporting]
          ]),
          createBaseVNode("label", {
            for: _ctx.$id("allow-tracking")
          }, [
            createTextVNode(" Allow bugs to be reported "),
            _hoisted_33,
            _hoisted_34,
            _hoisted_35,
            _hoisted_36
          ], 8, _hoisted_32)
        ]),
        createBaseVNode("div", _hoisted_37, [
          withDirectives(createBaseVNode("input", {
            id: _ctx.$id("ping-url"),
            type: "checkbox",
            "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => _ctx.pingUrl = $event)
          }, null, 8, _hoisted_38), [
            [vModelCheckbox, _ctx.pingUrl]
          ]),
          createBaseVNode("label", {
            for: _ctx.$id("ping-url")
          }, " Check if environment url is up ", 8, _hoisted_39)
        ]),
        createBaseVNode("div", _hoisted_40, [
          withDirectives(createBaseVNode("input", {
            id: _ctx.$id("switch-env-projects"),
            type: "checkbox",
            "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => _ctx.switchEnvBetweenProjects = $event)
          }, null, 8, _hoisted_41), [
            [vModelCheckbox, _ctx.switchEnvBetweenProjects]
          ]),
          createBaseVNode("label", {
            for: _ctx.$id("switch-env-projects")
          }, " Switch environments between projects ", 8, _hoisted_42)
        ])
      ]),
      createBaseVNode("fieldset", _hoisted_43, [
        createVNode(_component_EditorFormBadge, {
          options: _ctx.mergedOptions,
          "onUpdate:options": _ctx.updateComputed
        }, null, 8, ["options", "onUpdate:options"]),
        _ctx.ribbonEnabled ? (openBlock(), createBlock(_component_EditorFormRibbon, {
          key: 0,
          class: "form-ribbon",
          options: _ctx.mergedOptions,
          "onUpdate:options": _ctx.updateComputed
        }, null, 8, ["options", "onUpdate:options"])) : createCommentVNode("", true)
      ]),
      createBaseVNode("div", _hoisted_44, [
        withDirectives(createVNode(_component_CoreButton, {
          elevation: "",
          "icon-name": "GoBackIcon",
          onClick: withModifiers(_ctx.resetToDefaultOptions, ["prevent"]),
          "data-hint": "Reset all options with default global options"
        }, {
          default: withCtx(() => [
            createTextVNode(" Reset ")
          ]),
          _: 1
        }, 8, ["onClick"]), [
          [vShow, _ctx.hasOptions]
        ])
      ])
    ])
  ]);
}
const EditorFormConfigGlobalOptions = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["render", _sfc_render$b], ["__scopeId", "data-v-66c0263b"]]);
const EditorFormConfig_vue_vue_type_style_index_0_scoped_b5995fdd_lang = "";
const _sfc_main$a = defineComponent({
  name: "EditorFormConfig",
  components: {
    EditorFormConfigGlobalOptions,
    EditorFormConfigProjects,
    EditorFormConfigEnv
  },
  props: {
    config: {
      type: Object,
      default: () => {
      }
    }
  },
  emits: ["update:config"],
  setup(props, context) {
    let newEnv$1 = ref(null);
    let selectedEnvId = ref(null);
    let selectedProjectId = ref(null);
    onMounted(() => {
      const projects = props.config.projects;
      if (projects.length > 0) {
        const firstProject = projects[0];
        selectedProjectId.value = firstProject.id;
        if (firstProject.envs && firstProject.envs.length > 0) {
          selectedEnvId.value = firstProject.envs[0];
        }
      }
    });
    const addNewEnv = (projectId) => {
      const env = newEnv(props.config, {});
      selectEnv({ projectId, newEnv: env });
    };
    const cancelNewEnv = () => selectFirstEnv(props.config);
    const createNewEnv = (env) => {
      const config = addEnv(props.config, selectedProjectId.value, env);
      updateConfig(config);
      setTimeout(() => {
        selectEnv({ envId: env.id });
        updateSortableEnvs();
      }, 0);
    };
    const updateEnv$1 = (env, options) => {
      if (newEnv$1.value) {
        newEnv$1.value = {
          ...newEnv$1.value,
          ...env
        };
      } else {
        const config = updateEnv(props.config, env);
        updateConfig(config, options);
      }
    };
    const cloneEnv = (envId) => {
      const env = getEnvById(props.config, envId);
      const clonedEnv = newEnv(props.config, cjs({}, env));
      const config = addEnv(props.config, selectedProjectId.value, clonedEnv);
      updateConfig(config);
      selectEnv({ envId: clonedEnv.id });
      updateSortableEnvs();
    };
    const deleteEnv$1 = (envId) => {
      const projectEnvs = getProjectEnvs(props.config, selectedProjectId.value);
      const envIdx = projectEnvs.findIndex((env) => env.id === envId);
      const config = deleteEnv(props.config, envId);
      updateConfig(config);
      selectNextEnv(config, envIdx);
      updateSortableEnvs();
    };
    const dropEnv = ({ projectId, origin, destination }) => {
      const project = getProjectById(props.config, projectId);
      const { envs } = project;
      envs.splice(destination.index, 0, envs.splice(origin.index, 1)[0]);
      updateProject$1({
        projectId,
        data: {
          envs
        }
      });
    };
    const addNewProject = () => {
      const project = newProject(props.config, {
        name: "New Project"
      });
      const config = addProject(props.config, project);
      updateConfig(config);
      updateSortableProjects();
    };
    const deleteProject$1 = (projectId) => {
      const config = deleteProject(props.config, projectId);
      updateConfig(config);
      selectEnv(null);
      updateSortableProjects();
    };
    const dropProject = ({ origin, destination }) => {
      const { projects } = props.config;
      projects.splice(destination.index, 0, projects.splice(origin.index, 1)[0]);
      updateConfig({
        ...props.config,
        projects
      });
    };
    const selectNextEnv = (config, envIdx) => {
      const projectEnvs = getProjectEnvs(config, selectedProjectId.value);
      if (projectEnvs.length > 0) {
        const env = projectEnvs[envIdx] || projectEnvs[projectEnvs.length - 1];
        selectEnv({
          envId: env.id
        });
      } else {
        selectEnv(null);
      }
    };
    const selectFirstEnv = (config) => {
      const projectEnvs = getProjectEnvs(config, selectedProjectId.value);
      if (projectEnvs.length > 0) {
        const env = projectEnvs[0];
        selectEnv({
          envId: env.id
        });
      } else {
        selectEnv(null);
      }
    };
    const selectEnv = (data) => {
      if (data != null) {
        const { envId, projectId, newEnv: newEnvData } = data;
        selectedEnvId.value = envId;
        if (projectId != null) {
          selectedProjectId.value = projectId;
        }
        newEnv$1.value = newEnvData;
      } else {
        selectedEnvId.value = null;
        selectedProjectId.value = null;
        newEnv$1.value = null;
      }
    };
    const updateProject$1 = ({ projectId, data }) => {
      const project = getProjectById(props.config, projectId);
      const updatedProject = {
        ...project,
        ...data
      };
      const config = updateProject(props.config, updatedProject);
      updateConfig(config);
    };
    const updateOptions = (options) => updateConfig({ ...props.config, options });
    const updateConfig = (config, options) => context.emit("update:config", config, options);
    const selectedEnv = computed(() => getEnvById(props.config, selectedEnvId.value));
    const selectedProject = computed(() => getProjectById(props.config, selectedProjectId.value));
    return {
      newEnv: newEnv$1,
      addNewEnv,
      cloneEnv,
      dropEnv,
      addNewProject,
      deleteProject: deleteProject$1,
      dropProject,
      cancelNewEnv,
      createNewEnv,
      deleteEnv: deleteEnv$1,
      updateEnv: updateEnv$1,
      updateProject: updateProject$1,
      updateOptions,
      updateConfig,
      selectEnv,
      selectedEnv,
      selectedProject,
      selectedEnvId,
      selectedProjectId
    };
  }
});
const _withScopeId$1 = (n2) => (pushScopeId("data-v-b5995fdd"), n2 = n2(), popScopeId(), n2);
const _hoisted_1$a = {
  class: "editor-form box-elevation",
  "data-intro": "You can add, delete, drag&drop and edit your projects and environments here."
};
const _hoisted_2$a = { class: "left-pane" };
const _hoisted_3$a = {
  key: 0,
  class: "blocking-mask"
};
const _hoisted_4$2 = {
  key: 1,
  class: "empty-env"
};
const _hoisted_5$1 = /* @__PURE__ */ _withScopeId$1(() => /* @__PURE__ */ createBaseVNode("br", null, null, -1));
function _sfc_render$a(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_EditorFormConfigProjects = resolveComponent("EditorFormConfigProjects");
  const _component_EditorFormConfigEnv = resolveComponent("EditorFormConfigEnv");
  const _component_EditorFormConfigGlobalOptions = resolveComponent("EditorFormConfigGlobalOptions");
  return openBlock(), createElementBlock("div", null, [
    createBaseVNode("div", _hoisted_1$a, [
      createBaseVNode("div", _hoisted_2$a, [
        !!_ctx.newEnv ? (openBlock(), createElementBlock("div", _hoisted_3$a)) : createCommentVNode("", true),
        createVNode(_component_EditorFormConfigProjects, {
          config: _ctx.config,
          "selected-env-id": _ctx.selectedEnvId,
          "selected-project-id": _ctx.selectedProjectId,
          onSelectEnv: _ctx.selectEnv,
          onNewEnv: _ctx.addNewEnv,
          onDeleteEnv: _ctx.deleteEnv,
          onDropEnv: _ctx.dropEnv,
          onNewProject: _ctx.addNewProject,
          onDeleteProject: _ctx.deleteProject,
          onUpdateProject: _ctx.updateProject,
          onDropProject: _ctx.dropProject,
          "onUpdate:config": _ctx.updateConfig
        }, null, 8, ["config", "selected-env-id", "selected-project-id", "onSelectEnv", "onNewEnv", "onDeleteEnv", "onDropEnv", "onNewProject", "onDeleteProject", "onUpdateProject", "onDropProject", "onUpdate:config"])
      ]),
      createBaseVNode("div", {
        class: normalizeClass(["right-pane", { "right-pane-empty": _ctx.selectedEnvId == null && !_ctx.newEnv }])
      }, [
        _ctx.selectedEnv != null || _ctx.newEnv != null ? (openBlock(), createBlock(_component_EditorFormConfigEnv, {
          env: _ctx.newEnv || _ctx.selectedEnv,
          key: `env-${(_ctx.newEnv || _ctx.selectedEnv).id}`,
          config: _ctx.config,
          "new-env": !!_ctx.newEnv,
          "project-name": _ctx.selectedProject.name,
          onDeleteEnv: _ctx.deleteEnv,
          onCloneEnv: _ctx.cloneEnv,
          onUpdateEnv: _ctx.updateEnv,
          onCancelNewEnv: _ctx.cancelNewEnv,
          onCreateNewEnv: _ctx.createNewEnv
        }, null, 8, ["env", "config", "new-env", "project-name", "onDeleteEnv", "onCloneEnv", "onUpdateEnv", "onCancelNewEnv", "onCreateNewEnv"])) : createCommentVNode("", true),
        _ctx.selectedEnvId == null && !_ctx.newEnv ? (openBlock(), createElementBlock("div", _hoisted_4$2, [
          createTextVNode(" No env currently selected. "),
          _hoisted_5$1,
          createTextVNode(" Select one on the left side to edit ")
        ])) : createCommentVNode("", true)
      ], 2)
    ]),
    createVNode(_component_EditorFormConfigGlobalOptions, {
      options: _ctx.config.options,
      "onUpdate:options": _ctx.updateOptions
    }, null, 8, ["options", "onUpdate:options"])
  ]);
}
const EditorFormConfig = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["render", _sfc_render$a], ["__scopeId", "data-v-b5995fdd"]]);
/*!
 * Intro.js v6.0.0
 * https://introjs.com
 *
 * Copyright (C) 2012-2022 Afshin Mehrabani (@afshinmeh).
 * https://introjs.com
 *
 * Date: Sun, 10 Jul 2022 10:05:59 GMT
 */
function t() {
  /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */
  t = function() {
    return e2;
  };
  var e2 = {}, n2 = Object.prototype, r2 = n2.hasOwnProperty, i2 = "function" == typeof Symbol ? Symbol : {}, o2 = i2.iterator || "@@iterator", a2 = i2.asyncIterator || "@@asyncIterator", s2 = i2.toStringTag || "@@toStringTag";
  function c2(t3, e3, n3) {
    return Object.defineProperty(t3, e3, { value: n3, enumerable: true, configurable: true, writable: true }), t3[e3];
  }
  try {
    c2({}, "");
  } catch (t3) {
    c2 = function(t4, e3, n3) {
      return t4[e3] = n3;
    };
  }
  function l2(t3, e3, n3, r3) {
    var i3 = e3 && e3.prototype instanceof p2 ? e3 : p2, o3 = Object.create(i3.prototype), a3 = new S2(r3 || []);
    return o3._invoke = function(t4, e4, n4) {
      var r4 = "suspendedStart";
      return function(i4, o4) {
        if ("executing" === r4)
          throw new Error("Generator is already running");
        if ("completed" === r4) {
          if ("throw" === i4)
            throw o4;
          return C2();
        }
        for (n4.method = i4, n4.arg = o4; ; ) {
          var a4 = n4.delegate;
          if (a4) {
            var s3 = x2(a4, n4);
            if (s3) {
              if (s3 === h2)
                continue;
              return s3;
            }
          }
          if ("next" === n4.method)
            n4.sent = n4._sent = n4.arg;
          else if ("throw" === n4.method) {
            if ("suspendedStart" === r4)
              throw r4 = "completed", n4.arg;
            n4.dispatchException(n4.arg);
          } else
            "return" === n4.method && n4.abrupt("return", n4.arg);
          r4 = "executing";
          var c3 = u2(t4, e4, n4);
          if ("normal" === c3.type) {
            if (r4 = n4.done ? "completed" : "suspendedYield", c3.arg === h2)
              continue;
            return { value: c3.arg, done: n4.done };
          }
          "throw" === c3.type && (r4 = "completed", n4.method = "throw", n4.arg = c3.arg);
        }
      };
    }(t3, n3, a3), o3;
  }
  function u2(t3, e3, n3) {
    try {
      return { type: "normal", arg: t3.call(e3, n3) };
    } catch (t4) {
      return { type: "throw", arg: t4 };
    }
  }
  e2.wrap = l2;
  var h2 = {};
  function p2() {
  }
  function f2() {
  }
  function d2() {
  }
  var b2 = {};
  c2(b2, o2, function() {
    return this;
  });
  var m2 = Object.getPrototypeOf, v2 = m2 && m2(m2(j2([])));
  v2 && v2 !== n2 && r2.call(v2, o2) && (b2 = v2);
  var g2 = d2.prototype = p2.prototype = Object.create(b2);
  function y2(t3) {
    ["next", "throw", "return"].forEach(function(e3) {
      c2(t3, e3, function(t4) {
        return this._invoke(e3, t4);
      });
    });
  }
  function w2(t3, e3) {
    function n3(i4, o3, a3, s3) {
      var c3 = u2(t3[i4], t3, o3);
      if ("throw" !== c3.type) {
        var l3 = c3.arg, h3 = l3.value;
        return h3 && "object" == typeof h3 && r2.call(h3, "__await") ? e3.resolve(h3.__await).then(function(t4) {
          n3("next", t4, a3, s3);
        }, function(t4) {
          n3("throw", t4, a3, s3);
        }) : e3.resolve(h3).then(function(t4) {
          l3.value = t4, a3(l3);
        }, function(t4) {
          return n3("throw", t4, a3, s3);
        });
      }
      s3(c3.arg);
    }
    var i3;
    this._invoke = function(t4, r3) {
      function o3() {
        return new e3(function(e4, i4) {
          n3(t4, r3, e4, i4);
        });
      }
      return i3 = i3 ? i3.then(o3, o3) : o3();
    };
  }
  function x2(t3, e3) {
    var n3 = t3.iterator[e3.method];
    if (void 0 === n3) {
      if (e3.delegate = null, "throw" === e3.method) {
        if (t3.iterator.return && (e3.method = "return", e3.arg = void 0, x2(t3, e3), "throw" === e3.method))
          return h2;
        e3.method = "throw", e3.arg = new TypeError("The iterator does not provide a 'throw' method");
      }
      return h2;
    }
    var r3 = u2(n3, t3.iterator, e3.arg);
    if ("throw" === r3.type)
      return e3.method = "throw", e3.arg = r3.arg, e3.delegate = null, h2;
    var i3 = r3.arg;
    return i3 ? i3.done ? (e3[t3.resultName] = i3.value, e3.next = t3.nextLoc, "return" !== e3.method && (e3.method = "next", e3.arg = void 0), e3.delegate = null, h2) : i3 : (e3.method = "throw", e3.arg = new TypeError("iterator result is not an object"), e3.delegate = null, h2);
  }
  function _2(t3) {
    var e3 = { tryLoc: t3[0] };
    1 in t3 && (e3.catchLoc = t3[1]), 2 in t3 && (e3.finallyLoc = t3[2], e3.afterLoc = t3[3]), this.tryEntries.push(e3);
  }
  function k2(t3) {
    var e3 = t3.completion || {};
    e3.type = "normal", delete e3.arg, t3.completion = e3;
  }
  function S2(t3) {
    this.tryEntries = [{ tryLoc: "root" }], t3.forEach(_2, this), this.reset(true);
  }
  function j2(t3) {
    if (t3) {
      var e3 = t3[o2];
      if (e3)
        return e3.call(t3);
      if ("function" == typeof t3.next)
        return t3;
      if (!isNaN(t3.length)) {
        var n3 = -1, i3 = function e4() {
          for (; ++n3 < t3.length; )
            if (r2.call(t3, n3))
              return e4.value = t3[n3], e4.done = false, e4;
          return e4.value = void 0, e4.done = true, e4;
        };
        return i3.next = i3;
      }
    }
    return { next: C2 };
  }
  function C2() {
    return { value: void 0, done: true };
  }
  return f2.prototype = d2, c2(g2, "constructor", d2), c2(d2, "constructor", f2), f2.displayName = c2(d2, s2, "GeneratorFunction"), e2.isGeneratorFunction = function(t3) {
    var e3 = "function" == typeof t3 && t3.constructor;
    return !!e3 && (e3 === f2 || "GeneratorFunction" === (e3.displayName || e3.name));
  }, e2.mark = function(t3) {
    return Object.setPrototypeOf ? Object.setPrototypeOf(t3, d2) : (t3.__proto__ = d2, c2(t3, s2, "GeneratorFunction")), t3.prototype = Object.create(g2), t3;
  }, e2.awrap = function(t3) {
    return { __await: t3 };
  }, y2(w2.prototype), c2(w2.prototype, a2, function() {
    return this;
  }), e2.AsyncIterator = w2, e2.async = function(t3, n3, r3, i3, o3) {
    void 0 === o3 && (o3 = Promise);
    var a3 = new w2(l2(t3, n3, r3, i3), o3);
    return e2.isGeneratorFunction(n3) ? a3 : a3.next().then(function(t4) {
      return t4.done ? t4.value : a3.next();
    });
  }, y2(g2), c2(g2, s2, "Generator"), c2(g2, o2, function() {
    return this;
  }), c2(g2, "toString", function() {
    return "[object Generator]";
  }), e2.keys = function(t3) {
    var e3 = [];
    for (var n3 in t3)
      e3.push(n3);
    return e3.reverse(), function n4() {
      for (; e3.length; ) {
        var r3 = e3.pop();
        if (r3 in t3)
          return n4.value = r3, n4.done = false, n4;
      }
      return n4.done = true, n4;
    };
  }, e2.values = j2, S2.prototype = { constructor: S2, reset: function(t3) {
    if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = false, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(k2), !t3)
      for (var e3 in this)
        "t" === e3.charAt(0) && r2.call(this, e3) && !isNaN(+e3.slice(1)) && (this[e3] = void 0);
  }, stop: function() {
    this.done = true;
    var t3 = this.tryEntries[0].completion;
    if ("throw" === t3.type)
      throw t3.arg;
    return this.rval;
  }, dispatchException: function(t3) {
    if (this.done)
      throw t3;
    var e3 = this;
    function n3(n4, r3) {
      return a3.type = "throw", a3.arg = t3, e3.next = n4, r3 && (e3.method = "next", e3.arg = void 0), !!r3;
    }
    for (var i3 = this.tryEntries.length - 1; i3 >= 0; --i3) {
      var o3 = this.tryEntries[i3], a3 = o3.completion;
      if ("root" === o3.tryLoc)
        return n3("end");
      if (o3.tryLoc <= this.prev) {
        var s3 = r2.call(o3, "catchLoc"), c3 = r2.call(o3, "finallyLoc");
        if (s3 && c3) {
          if (this.prev < o3.catchLoc)
            return n3(o3.catchLoc, true);
          if (this.prev < o3.finallyLoc)
            return n3(o3.finallyLoc);
        } else if (s3) {
          if (this.prev < o3.catchLoc)
            return n3(o3.catchLoc, true);
        } else {
          if (!c3)
            throw new Error("try statement without catch or finally");
          if (this.prev < o3.finallyLoc)
            return n3(o3.finallyLoc);
        }
      }
    }
  }, abrupt: function(t3, e3) {
    for (var n3 = this.tryEntries.length - 1; n3 >= 0; --n3) {
      var i3 = this.tryEntries[n3];
      if (i3.tryLoc <= this.prev && r2.call(i3, "finallyLoc") && this.prev < i3.finallyLoc) {
        var o3 = i3;
        break;
      }
    }
    o3 && ("break" === t3 || "continue" === t3) && o3.tryLoc <= e3 && e3 <= o3.finallyLoc && (o3 = null);
    var a3 = o3 ? o3.completion : {};
    return a3.type = t3, a3.arg = e3, o3 ? (this.method = "next", this.next = o3.finallyLoc, h2) : this.complete(a3);
  }, complete: function(t3, e3) {
    if ("throw" === t3.type)
      throw t3.arg;
    return "break" === t3.type || "continue" === t3.type ? this.next = t3.arg : "return" === t3.type ? (this.rval = this.arg = t3.arg, this.method = "return", this.next = "end") : "normal" === t3.type && e3 && (this.next = e3), h2;
  }, finish: function(t3) {
    for (var e3 = this.tryEntries.length - 1; e3 >= 0; --e3) {
      var n3 = this.tryEntries[e3];
      if (n3.finallyLoc === t3)
        return this.complete(n3.completion, n3.afterLoc), k2(n3), h2;
    }
  }, catch: function(t3) {
    for (var e3 = this.tryEntries.length - 1; e3 >= 0; --e3) {
      var n3 = this.tryEntries[e3];
      if (n3.tryLoc === t3) {
        var r3 = n3.completion;
        if ("throw" === r3.type) {
          var i3 = r3.arg;
          k2(n3);
        }
        return i3;
      }
    }
    throw new Error("illegal catch attempt");
  }, delegateYield: function(t3, e3, n3) {
    return this.delegate = { iterator: j2(t3), resultName: e3, nextLoc: n3 }, "next" === this.method && (this.arg = void 0), h2;
  } }, e2;
}
function e(t3) {
  return e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t4) {
    return typeof t4;
  } : function(t4) {
    return t4 && "function" == typeof Symbol && t4.constructor === Symbol && t4 !== Symbol.prototype ? "symbol" : typeof t4;
  }, e(t3);
}
function n(t3, e2, n2, r2, i2, o2, a2) {
  try {
    var s2 = t3[o2](a2), c2 = s2.value;
  } catch (t4) {
    return void n2(t4);
  }
  s2.done ? e2(c2) : Promise.resolve(c2).then(r2, i2);
}
function r(t3) {
  return function() {
    var e2 = this, r2 = arguments;
    return new Promise(function(i2, o2) {
      var a2 = t3.apply(e2, r2);
      function s2(t4) {
        n(a2, i2, o2, s2, c2, "next", t4);
      }
      function c2(t4) {
        n(a2, i2, o2, s2, c2, "throw", t4);
      }
      s2(void 0);
    });
  };
}
function i(t3, e2, n2) {
  return e2 in t3 ? Object.defineProperty(t3, e2, { value: n2, enumerable: true, configurable: true, writable: true }) : t3[e2] = n2, t3;
}
function o(t3, e2) {
  return function(t4) {
    if (Array.isArray(t4))
      return t4;
  }(t3) || function(t4, e3) {
    var n2 = null == t4 ? null : "undefined" != typeof Symbol && t4[Symbol.iterator] || t4["@@iterator"];
    if (null == n2)
      return;
    var r2, i2, o2 = [], a2 = true, s2 = false;
    try {
      for (n2 = n2.call(t4); !(a2 = (r2 = n2.next()).done) && (o2.push(r2.value), !e3 || o2.length !== e3); a2 = true)
        ;
    } catch (t5) {
      s2 = true, i2 = t5;
    } finally {
      try {
        a2 || null == n2.return || n2.return();
      } finally {
        if (s2)
          throw i2;
      }
    }
    return o2;
  }(t3, e2) || function(t4, e3) {
    if (!t4)
      return;
    if ("string" == typeof t4)
      return a(t4, e3);
    var n2 = Object.prototype.toString.call(t4).slice(8, -1);
    "Object" === n2 && t4.constructor && (n2 = t4.constructor.name);
    if ("Map" === n2 || "Set" === n2)
      return Array.from(t4);
    if ("Arguments" === n2 || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n2))
      return a(t4, e3);
  }(t3, e2) || function() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }();
}
function a(t3, e2) {
  (null == e2 || e2 > t3.length) && (e2 = t3.length);
  for (var n2 = 0, r2 = new Array(e2); n2 < e2; n2++)
    r2[n2] = t3[n2];
  return r2;
}
var s = function() {
  var t3 = {};
  return function(e2) {
    var n2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "introjs-stamp";
    return t3[n2] = t3[n2] || 0, void 0 === e2[n2] && (e2[n2] = t3[n2]++), e2[n2];
  };
}();
function c(t3, e2, n2) {
  if (t3)
    for (var r2 = 0, i2 = t3.length; r2 < i2; r2++)
      e2(t3[r2], r2);
  "function" == typeof n2 && n2();
}
var l = new function() {
  var t3 = "introjs_event";
  this._id = function(t4, e2, n2, r2) {
    return e2 + s(n2) + (r2 ? "_".concat(s(r2)) : "");
  }, this.on = function(e2, n2, r2, i2, o2) {
    var a2 = this._id.apply(this, arguments), s2 = function(t4) {
      return r2.call(i2 || e2, t4 || window.event);
    };
    "addEventListener" in e2 ? e2.addEventListener(n2, s2, o2) : "attachEvent" in e2 && e2.attachEvent("on".concat(n2), s2), e2[t3] = e2[t3] || {}, e2[t3][a2] = s2;
  }, this.off = function(e2, n2, r2, i2, o2) {
    var a2 = this._id.apply(this, arguments), s2 = e2[t3] && e2[t3][a2];
    s2 && ("removeEventListener" in e2 ? e2.removeEventListener(n2, s2, o2) : "detachEvent" in e2 && e2.detachEvent("on".concat(n2), s2), e2[t3][a2] = null);
  };
}();
function u(t3, e2) {
  if (t3 instanceof SVGElement) {
    var n2 = t3.getAttribute("class") || "";
    n2.match(e2) || t3.setAttribute("class", "".concat(n2, " ").concat(e2));
  } else {
    if (void 0 !== t3.classList)
      c(e2.split(" "), function(e3) {
        t3.classList.add(e3);
      });
    else
      t3.className.match(e2) || (t3.className += " ".concat(e2));
  }
}
function h(t3, e2) {
  var n2 = "";
  return t3.currentStyle ? n2 = t3.currentStyle[e2] : document.defaultView && document.defaultView.getComputedStyle && (n2 = document.defaultView.getComputedStyle(t3, null).getPropertyValue(e2)), n2 && n2.toLowerCase ? n2.toLowerCase() : n2;
}
function p(t3) {
  var e2 = t3.element;
  u(e2, "introjs-showElement");
  var n2 = h(e2, "position");
  "absolute" !== n2 && "relative" !== n2 && "sticky" !== n2 && "fixed" !== n2 && u(e2, "introjs-relativePosition");
}
function f(t3) {
  var e2 = t3.element;
  if (this._options.scrollToElement) {
    var n2 = function(t4) {
      var e3 = window.getComputedStyle(t4), n3 = "absolute" === e3.position, r2 = /(auto|scroll)/;
      if ("fixed" === e3.position)
        return document.body;
      for (var i2 = t4; i2 = i2.parentElement; )
        if (e3 = window.getComputedStyle(i2), (!n3 || "static" !== e3.position) && r2.test(e3.overflow + e3.overflowY + e3.overflowX))
          return i2;
      return document.body;
    }(e2);
    n2 !== document.body && (n2.scrollTop = e2.offsetTop - n2.offsetTop);
  }
}
function d() {
  if (void 0 !== window.innerWidth)
    return { width: window.innerWidth, height: window.innerHeight };
  var t3 = document.documentElement;
  return { width: t3.clientWidth, height: t3.clientHeight };
}
function b(t3, e2, n2) {
  var r2, i2 = e2.element;
  if ("off" !== t3 && (this._options.scrollToElement && (r2 = "tooltip" === t3 ? n2.getBoundingClientRect() : i2.getBoundingClientRect(), !function(t4) {
    var e3 = t4.getBoundingClientRect();
    return e3.top >= 0 && e3.left >= 0 && e3.bottom + 80 <= window.innerHeight && e3.right <= window.innerWidth;
  }(i2)))) {
    var o2 = d().height;
    r2.bottom - (r2.bottom - r2.top) < 0 || i2.clientHeight > o2 ? window.scrollBy(0, r2.top - (o2 / 2 - r2.height / 2) - this._options.scrollPadding) : window.scrollBy(0, r2.top - (o2 / 2 - r2.height / 2) + this._options.scrollPadding);
  }
}
function m(t3) {
  t3.setAttribute("role", "button"), t3.tabIndex = 0;
}
function v(t3) {
  var e2 = t3.parentNode;
  return !(!e2 || "HTML" === e2.nodeName) && ("fixed" === h(t3, "position") || v(e2));
}
function g(t3, e2) {
  var n2 = document.body, r2 = document.documentElement, i2 = window.pageYOffset || r2.scrollTop || n2.scrollTop, o2 = window.pageXOffset || r2.scrollLeft || n2.scrollLeft;
  e2 = e2 || n2;
  var a2 = t3.getBoundingClientRect(), s2 = e2.getBoundingClientRect(), c2 = h(e2, "position"), l2 = { width: a2.width, height: a2.height };
  return "body" !== e2.tagName.toLowerCase() && "relative" === c2 || "sticky" === c2 ? Object.assign(l2, { top: a2.top - s2.top, left: a2.left - s2.left }) : v(t3) ? Object.assign(l2, { top: a2.top, left: a2.left }) : Object.assign(l2, { top: a2.top + i2, left: a2.left + o2 });
}
var y = function(t3) {
  try {
    return !!t3();
  } catch (t4) {
    return true;
  }
}, w = !y(function() {
  var t3 = function() {
  }.bind();
  return "function" != typeof t3 || t3.hasOwnProperty("prototype");
}), x = Function.prototype, _ = x.apply, k = x.call, S = "object" == typeof Reflect && Reflect.apply || (w ? k.bind(_) : function() {
  return k.apply(_, arguments);
}), j = Function.prototype.call, C = w ? j.bind(j) : function() {
  return j.apply(j, arguments);
}, A = Function.prototype, E = A.bind, N = A.call, I = w && E.bind(N, N), L = w ? function(t3) {
  return t3 && I(t3);
} : function(t3) {
  return t3 && function() {
    return N.apply(t3, arguments);
  };
}, O = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
function T(t3, e2) {
  return t3(e2 = { exports: {} }, e2.exports), e2.exports;
}
var P, R, q = function(t3) {
  return t3 && t3.Math == Math && t3;
}, B = q("object" == typeof globalThis && globalThis) || q("object" == typeof window && window) || q("object" == typeof self && self) || q("object" == typeof O && O) || function() {
  return this;
}() || Function("return this")(), M = !y(function() {
  return 7 != Object.defineProperty({}, 1, { get: function() {
    return 7;
  } })[1];
}), H = {}.propertyIsEnumerable, F = Object.getOwnPropertyDescriptor, D = { f: F && !H.call({ 1: 2 }, 1) ? function(t3) {
  var e2 = F(this, t3);
  return !!e2 && e2.enumerable;
} : H }, $ = function(t3, e2) {
  return { enumerable: !(1 & t3), configurable: !(2 & t3), writable: !(4 & t3), value: e2 };
}, z = L({}.toString), G = L("".slice), W = function(t3) {
  return G(z(t3), 8, -1);
}, V = Object, U = L("".split), Y = y(function() {
  return !V("z").propertyIsEnumerable(0);
}) ? function(t3) {
  return "String" == W(t3) ? U(t3, "") : V(t3);
} : V, K = TypeError, X = function(t3) {
  if (null == t3)
    throw K("Can't call method on " + t3);
  return t3;
}, Q = function(t3) {
  return Y(X(t3));
}, Z = function(t3) {
  return "function" == typeof t3;
}, J = function(t3) {
  return "object" == typeof t3 ? null !== t3 : Z(t3);
}, tt = function(t3) {
  return Z(t3) ? t3 : void 0;
}, et = function(t3, e2) {
  return arguments.length < 2 ? tt(B[t3]) : B[t3] && B[t3][e2];
}, nt = L({}.isPrototypeOf), rt = et("navigator", "userAgent") || "", it = B.process, ot = B.Deno, at = it && it.versions || ot && ot.version, st = at && at.v8;
st && (R = (P = st.split("."))[0] > 0 && P[0] < 4 ? 1 : +(P[0] + P[1])), !R && rt && (!(P = rt.match(/Edge\/(\d+)/)) || P[1] >= 74) && (P = rt.match(/Chrome\/(\d+)/)) && (R = +P[1]);
var ct = R, lt = !!Object.getOwnPropertySymbols && !y(function() {
  var t3 = Symbol();
  return !String(t3) || !(Object(t3) instanceof Symbol) || !Symbol.sham && ct && ct < 41;
}), ut = lt && !Symbol.sham && "symbol" == typeof Symbol.iterator, ht = Object, pt = ut ? function(t3) {
  return "symbol" == typeof t3;
} : function(t3) {
  var e2 = et("Symbol");
  return Z(e2) && nt(e2.prototype, ht(t3));
}, ft = String, dt = TypeError, bt = function(t3) {
  if (Z(t3))
    return t3;
  throw dt(function(t4) {
    try {
      return ft(t4);
    } catch (t5) {
      return "Object";
    }
  }(t3) + " is not a function");
}, mt = function(t3, e2) {
  var n2 = t3[e2];
  return null == n2 ? void 0 : bt(n2);
}, vt = TypeError, gt = Object.defineProperty, yt = function(t3, e2) {
  try {
    gt(B, t3, { value: e2, configurable: true, writable: true });
  } catch (n2) {
    B[t3] = e2;
  }
  return e2;
}, wt = B["__core-js_shared__"] || yt("__core-js_shared__", {}), xt = T(function(t3) {
  (t3.exports = function(t4, e2) {
    return wt[t4] || (wt[t4] = void 0 !== e2 ? e2 : {});
  })("versions", []).push({ version: "3.23.3", mode: "global", copyright: "© 2014-2022 Denis Pushkarev (zloirock.ru)", license: "https://github.com/zloirock/core-js/blob/v3.23.3/LICENSE", source: "https://github.com/zloirock/core-js" });
}), _t = Object, kt = function(t3) {
  return _t(X(t3));
}, St = L({}.hasOwnProperty), jt = Object.hasOwn || function(t3, e2) {
  return St(kt(t3), e2);
}, Ct = 0, At = Math.random(), Et = L(1 .toString), Nt = function(t3) {
  return "Symbol(" + (void 0 === t3 ? "" : t3) + ")_" + Et(++Ct + At, 36);
}, It = xt("wks"), Lt = B.Symbol, Ot = Lt && Lt.for, Tt = ut ? Lt : Lt && Lt.withoutSetter || Nt, Pt = function(t3) {
  if (!jt(It, t3) || !lt && "string" != typeof It[t3]) {
    var e2 = "Symbol." + t3;
    lt && jt(Lt, t3) ? It[t3] = Lt[t3] : It[t3] = ut && Ot ? Ot(e2) : Tt(e2);
  }
  return It[t3];
}, Rt = TypeError, qt = Pt("toPrimitive"), Bt = function(t3, e2) {
  if (!J(t3) || pt(t3))
    return t3;
  var n2, r2 = mt(t3, qt);
  if (r2) {
    if (void 0 === e2 && (e2 = "default"), n2 = C(r2, t3, e2), !J(n2) || pt(n2))
      return n2;
    throw Rt("Can't convert object to primitive value");
  }
  return void 0 === e2 && (e2 = "number"), function(t4, e3) {
    var n3, r3;
    if ("string" === e3 && Z(n3 = t4.toString) && !J(r3 = C(n3, t4)))
      return r3;
    if (Z(n3 = t4.valueOf) && !J(r3 = C(n3, t4)))
      return r3;
    if ("string" !== e3 && Z(n3 = t4.toString) && !J(r3 = C(n3, t4)))
      return r3;
    throw vt("Can't convert object to primitive value");
  }(t3, e2);
}, Mt = function(t3) {
  var e2 = Bt(t3, "string");
  return pt(e2) ? e2 : e2 + "";
}, Ht = B.document, Ft = J(Ht) && J(Ht.createElement), Dt = function(t3) {
  return Ft ? Ht.createElement(t3) : {};
}, $t = !M && !y(function() {
  return 7 != Object.defineProperty(Dt("div"), "a", { get: function() {
    return 7;
  } }).a;
}), zt = Object.getOwnPropertyDescriptor, Gt = { f: M ? zt : function(t3, e2) {
  if (t3 = Q(t3), e2 = Mt(e2), $t)
    try {
      return zt(t3, e2);
    } catch (t4) {
    }
  if (jt(t3, e2))
    return $(!C(D.f, t3, e2), t3[e2]);
} }, Wt = M && y(function() {
  return 42 != Object.defineProperty(function() {
  }, "prototype", { value: 42, writable: false }).prototype;
}), Vt = String, Ut = TypeError, Yt = function(t3) {
  if (J(t3))
    return t3;
  throw Ut(Vt(t3) + " is not an object");
}, Kt = TypeError, Xt = Object.defineProperty, Qt = Object.getOwnPropertyDescriptor, Zt = { f: M ? Wt ? function(t3, e2, n2) {
  if (Yt(t3), e2 = Mt(e2), Yt(n2), "function" == typeof t3 && "prototype" === e2 && "value" in n2 && "writable" in n2 && !n2.writable) {
    var r2 = Qt(t3, e2);
    r2 && r2.writable && (t3[e2] = n2.value, n2 = { configurable: "configurable" in n2 ? n2.configurable : r2.configurable, enumerable: "enumerable" in n2 ? n2.enumerable : r2.enumerable, writable: false });
  }
  return Xt(t3, e2, n2);
} : Xt : function(t3, e2, n2) {
  if (Yt(t3), e2 = Mt(e2), Yt(n2), $t)
    try {
      return Xt(t3, e2, n2);
    } catch (t4) {
    }
  if ("get" in n2 || "set" in n2)
    throw Kt("Accessors not supported");
  return "value" in n2 && (t3[e2] = n2.value), t3;
} }, Jt = M ? function(t3, e2, n2) {
  return Zt.f(t3, e2, $(1, n2));
} : function(t3, e2, n2) {
  return t3[e2] = n2, t3;
}, te = Function.prototype, ee = M && Object.getOwnPropertyDescriptor, ne = jt(te, "name"), re = { EXISTS: ne, PROPER: ne && "something" === function() {
}.name, CONFIGURABLE: ne && (!M || M && ee(te, "name").configurable) }, ie = L(Function.toString);
Z(wt.inspectSource) || (wt.inspectSource = function(t3) {
  return ie(t3);
});
var oe, ae, se, ce = wt.inspectSource, le = B.WeakMap, ue = Z(le) && /native code/.test(ce(le)), he = xt("keys"), pe = function(t3) {
  return he[t3] || (he[t3] = Nt(t3));
}, fe = {}, de = B.TypeError, be = B.WeakMap;
if (ue || wt.state) {
  var me = wt.state || (wt.state = new be()), ve = L(me.get), ge = L(me.has), ye = L(me.set);
  oe = function(t3, e2) {
    if (ge(me, t3))
      throw new de("Object already initialized");
    return e2.facade = t3, ye(me, t3, e2), e2;
  }, ae = function(t3) {
    return ve(me, t3) || {};
  }, se = function(t3) {
    return ge(me, t3);
  };
} else {
  var we = pe("state");
  fe[we] = true, oe = function(t3, e2) {
    if (jt(t3, we))
      throw new de("Object already initialized");
    return e2.facade = t3, Jt(t3, we, e2), e2;
  }, ae = function(t3) {
    return jt(t3, we) ? t3[we] : {};
  }, se = function(t3) {
    return jt(t3, we);
  };
}
var xe = { set: oe, get: ae, has: se, enforce: function(t3) {
  return se(t3) ? ae(t3) : oe(t3, {});
}, getterFor: function(t3) {
  return function(e2) {
    var n2;
    if (!J(e2) || (n2 = ae(e2)).type !== t3)
      throw de("Incompatible receiver, " + t3 + " required");
    return n2;
  };
} }, _e = T(function(t3) {
  var e2 = re.CONFIGURABLE, n2 = xe.enforce, r2 = xe.get, i2 = Object.defineProperty, o2 = M && !y(function() {
    return 8 !== i2(function() {
    }, "length", { value: 8 }).length;
  }), a2 = String(String).split("String"), s2 = t3.exports = function(t4, r3, s3) {
    "Symbol(" === String(r3).slice(0, 7) && (r3 = "[" + String(r3).replace(/^Symbol\(([^)]*)\)/, "$1") + "]"), s3 && s3.getter && (r3 = "get " + r3), s3 && s3.setter && (r3 = "set " + r3), (!jt(t4, "name") || e2 && t4.name !== r3) && (M ? i2(t4, "name", { value: r3, configurable: true }) : t4.name = r3), o2 && s3 && jt(s3, "arity") && t4.length !== s3.arity && i2(t4, "length", { value: s3.arity });
    try {
      s3 && jt(s3, "constructor") && s3.constructor ? M && i2(t4, "prototype", { writable: false }) : t4.prototype && (t4.prototype = void 0);
    } catch (t5) {
    }
    var c2 = n2(t4);
    return jt(c2, "source") || (c2.source = a2.join("string" == typeof r3 ? r3 : "")), t4;
  };
  Function.prototype.toString = s2(function() {
    return Z(this) && r2(this).source || ce(this);
  }, "toString");
}), ke = function(t3, e2, n2, r2) {
  r2 || (r2 = {});
  var i2 = r2.enumerable, o2 = void 0 !== r2.name ? r2.name : e2;
  if (Z(n2) && _e(n2, o2, r2), r2.global)
    i2 ? t3[e2] = n2 : yt(e2, n2);
  else {
    try {
      r2.unsafe ? t3[e2] && (i2 = true) : delete t3[e2];
    } catch (t4) {
    }
    i2 ? t3[e2] = n2 : Zt.f(t3, e2, { value: n2, enumerable: false, configurable: !r2.nonConfigurable, writable: !r2.nonWritable });
  }
  return t3;
}, Se = Math.ceil, je = Math.floor, Ce = Math.trunc || function(t3) {
  var e2 = +t3;
  return (e2 > 0 ? je : Se)(e2);
}, Ae = function(t3) {
  var e2 = +t3;
  return e2 != e2 || 0 === e2 ? 0 : Ce(e2);
}, Ee = Math.max, Ne = Math.min, Ie = Math.min, Le = function(t3) {
  return t3 > 0 ? Ie(Ae(t3), 9007199254740991) : 0;
}, Oe = function(t3) {
  return function(e2, n2, r2) {
    var i2, o2 = Q(e2), a2 = Le(o2.length), s2 = function(t4, e3) {
      var n3 = Ae(t4);
      return n3 < 0 ? Ee(n3 + e3, 0) : Ne(n3, e3);
    }(r2, a2);
    if (t3 && n2 != n2) {
      for (; a2 > s2; )
        if ((i2 = o2[s2++]) != i2)
          return true;
    } else
      for (; a2 > s2; s2++)
        if ((t3 || s2 in o2) && o2[s2] === n2)
          return t3 || s2 || 0;
    return !t3 && -1;
  };
}, Te = { includes: Oe(true), indexOf: Oe(false) }, Pe = Te.indexOf, Re = L([].push), qe = function(t3, e2) {
  var n2, r2 = Q(t3), i2 = 0, o2 = [];
  for (n2 in r2)
    !jt(fe, n2) && jt(r2, n2) && Re(o2, n2);
  for (; e2.length > i2; )
    jt(r2, n2 = e2[i2++]) && (~Pe(o2, n2) || Re(o2, n2));
  return o2;
}, Be = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"], Me = Be.concat("length", "prototype"), He = { f: Object.getOwnPropertyNames || function(t3) {
  return qe(t3, Me);
} }, Fe = { f: Object.getOwnPropertySymbols }, De = L([].concat), $e = et("Reflect", "ownKeys") || function(t3) {
  var e2 = He.f(Yt(t3)), n2 = Fe.f;
  return n2 ? De(e2, n2(t3)) : e2;
}, ze = function(t3, e2, n2) {
  for (var r2 = $e(e2), i2 = Zt.f, o2 = Gt.f, a2 = 0; a2 < r2.length; a2++) {
    var s2 = r2[a2];
    jt(t3, s2) || n2 && jt(n2, s2) || i2(t3, s2, o2(e2, s2));
  }
}, Ge = /#|\.prototype\./, We = function(t3, e2) {
  var n2 = Ue[Ve(t3)];
  return n2 == Ke || n2 != Ye && (Z(e2) ? y(e2) : !!e2);
}, Ve = We.normalize = function(t3) {
  return String(t3).replace(Ge, ".").toLowerCase();
}, Ue = We.data = {}, Ye = We.NATIVE = "N", Ke = We.POLYFILL = "P", Xe = We, Qe = Gt.f, Ze = function(t3, e2) {
  var n2, r2, i2, o2, a2, s2 = t3.target, c2 = t3.global, l2 = t3.stat;
  if (n2 = c2 ? B : l2 ? B[s2] || yt(s2, {}) : (B[s2] || {}).prototype)
    for (r2 in e2) {
      if (o2 = e2[r2], i2 = t3.dontCallGetSet ? (a2 = Qe(n2, r2)) && a2.value : n2[r2], !Xe(c2 ? r2 : s2 + (l2 ? "." : "#") + r2, t3.forced) && void 0 !== i2) {
        if (typeof o2 == typeof i2)
          continue;
        ze(o2, i2);
      }
      (t3.sham || i2 && i2.sham) && Jt(o2, "sham", true), ke(n2, r2, o2, t3);
    }
}, Je = {};
Je[Pt("toStringTag")] = "z";
var tn, en = "[object z]" === String(Je), nn = Pt("toStringTag"), rn = Object, on = "Arguments" == W(function() {
  return arguments;
}()), an = en ? W : function(t3) {
  var e2, n2, r2;
  return void 0 === t3 ? "Undefined" : null === t3 ? "Null" : "string" == typeof (n2 = function(t4, e3) {
    try {
      return t4[e3];
    } catch (t5) {
    }
  }(e2 = rn(t3), nn)) ? n2 : on ? W(e2) : "Object" == (r2 = W(e2)) && Z(e2.callee) ? "Arguments" : r2;
}, sn = String, cn = function(t3) {
  if ("Symbol" === an(t3))
    throw TypeError("Cannot convert a Symbol value to a string");
  return sn(t3);
}, ln = function() {
  var t3 = Yt(this), e2 = "";
  return t3.hasIndices && (e2 += "d"), t3.global && (e2 += "g"), t3.ignoreCase && (e2 += "i"), t3.multiline && (e2 += "m"), t3.dotAll && (e2 += "s"), t3.unicode && (e2 += "u"), t3.unicodeSets && (e2 += "v"), t3.sticky && (e2 += "y"), e2;
}, un = B.RegExp, hn = y(function() {
  var t3 = un("a", "y");
  return t3.lastIndex = 2, null != t3.exec("abcd");
}), pn = hn || y(function() {
  return !un("a", "y").sticky;
}), fn = { BROKEN_CARET: hn || y(function() {
  var t3 = un("^r", "gy");
  return t3.lastIndex = 2, null != t3.exec("str");
}), MISSED_STICKY: pn, UNSUPPORTED_Y: hn }, dn = Object.keys || function(t3) {
  return qe(t3, Be);
}, bn = M && !Wt ? Object.defineProperties : function(t3, e2) {
  Yt(t3);
  for (var n2, r2 = Q(e2), i2 = dn(e2), o2 = i2.length, a2 = 0; o2 > a2; )
    Zt.f(t3, n2 = i2[a2++], r2[n2]);
  return t3;
}, mn = { f: bn }, vn = et("document", "documentElement"), gn = pe("IE_PROTO"), yn = function() {
}, wn = function(t3) {
  return "<script>" + t3 + "<\/script>";
}, xn = function(t3) {
  t3.write(wn("")), t3.close();
  var e2 = t3.parentWindow.Object;
  return t3 = null, e2;
}, _n = function() {
  try {
    tn = new ActiveXObject("htmlfile");
  } catch (t4) {
  }
  var t3, e2;
  _n = "undefined" != typeof document ? document.domain && tn ? xn(tn) : ((e2 = Dt("iframe")).style.display = "none", vn.appendChild(e2), e2.src = String("javascript:"), (t3 = e2.contentWindow.document).open(), t3.write(wn("document.F=Object")), t3.close(), t3.F) : xn(tn);
  for (var n2 = Be.length; n2--; )
    delete _n.prototype[Be[n2]];
  return _n();
};
fe[gn] = true;
var kn, Sn, jn = Object.create || function(t3, e2) {
  var n2;
  return null !== t3 ? (yn.prototype = Yt(t3), n2 = new yn(), yn.prototype = null, n2[gn] = t3) : n2 = _n(), void 0 === e2 ? n2 : mn.f(n2, e2);
}, Cn = B.RegExp, An = y(function() {
  var t3 = Cn(".", "s");
  return !(t3.dotAll && t3.exec("\n") && "s" === t3.flags);
}), En = B.RegExp, Nn = y(function() {
  var t3 = En("(?<a>b)", "g");
  return "b" !== t3.exec("b").groups.a || "bc" !== "b".replace(t3, "$<a>c");
}), In = xe.get, Ln = xt("native-string-replace", String.prototype.replace), On = RegExp.prototype.exec, Tn = On, Pn = L("".charAt), Rn = L("".indexOf), qn = L("".replace), Bn = L("".slice), Mn = (Sn = /b*/g, C(On, kn = /a/, "a"), C(On, Sn, "a"), 0 !== kn.lastIndex || 0 !== Sn.lastIndex), Hn = fn.BROKEN_CARET, Fn = void 0 !== /()??/.exec("")[1];
(Mn || Fn || Hn || An || Nn) && (Tn = function(t3) {
  var e2, n2, r2, i2, o2, a2, s2, c2 = this, l2 = In(c2), u2 = cn(t3), h2 = l2.raw;
  if (h2)
    return h2.lastIndex = c2.lastIndex, e2 = C(Tn, h2, u2), c2.lastIndex = h2.lastIndex, e2;
  var p2 = l2.groups, f2 = Hn && c2.sticky, d2 = C(ln, c2), b2 = c2.source, m2 = 0, v2 = u2;
  if (f2 && (d2 = qn(d2, "y", ""), -1 === Rn(d2, "g") && (d2 += "g"), v2 = Bn(u2, c2.lastIndex), c2.lastIndex > 0 && (!c2.multiline || c2.multiline && "\n" !== Pn(u2, c2.lastIndex - 1)) && (b2 = "(?: " + b2 + ")", v2 = " " + v2, m2++), n2 = new RegExp("^(?:" + b2 + ")", d2)), Fn && (n2 = new RegExp("^" + b2 + "$(?!\\s)", d2)), Mn && (r2 = c2.lastIndex), i2 = C(On, f2 ? n2 : c2, v2), f2 ? i2 ? (i2.input = Bn(i2.input, m2), i2[0] = Bn(i2[0], m2), i2.index = c2.lastIndex, c2.lastIndex += i2[0].length) : c2.lastIndex = 0 : Mn && i2 && (c2.lastIndex = c2.global ? i2.index + i2[0].length : r2), Fn && i2 && i2.length > 1 && C(Ln, i2[0], n2, function() {
    for (o2 = 1; o2 < arguments.length - 2; o2++)
      void 0 === arguments[o2] && (i2[o2] = void 0);
  }), i2 && p2)
    for (i2.groups = a2 = jn(null), o2 = 0; o2 < p2.length; o2++)
      a2[(s2 = p2[o2])[0]] = i2[s2[1]];
  return i2;
});
var Dn = Tn;
Ze({ target: "RegExp", proto: true, forced: /./.exec !== Dn }, { exec: Dn });
var $n = Pt("species"), zn = RegExp.prototype, Gn = L("".charAt), Wn = L("".charCodeAt), Vn = L("".slice), Un = function(t3) {
  return function(e2, n2) {
    var r2, i2, o2 = cn(X(e2)), a2 = Ae(n2), s2 = o2.length;
    return a2 < 0 || a2 >= s2 ? t3 ? "" : void 0 : (r2 = Wn(o2, a2)) < 55296 || r2 > 56319 || a2 + 1 === s2 || (i2 = Wn(o2, a2 + 1)) < 56320 || i2 > 57343 ? t3 ? Gn(o2, a2) : r2 : t3 ? Vn(o2, a2, a2 + 2) : i2 - 56320 + (r2 - 55296 << 10) + 65536;
  };
}, Yn = { codeAt: Un(false), charAt: Un(true) }.charAt, Kn = function(t3, e2, n2) {
  return e2 + (n2 ? Yn(t3, e2).length : 1);
}, Xn = Math.floor, Qn = L("".charAt), Zn = L("".replace), Jn = L("".slice), tr = /\$([$&'`]|\d{1,2}|<[^>]*>)/g, er = /\$([$&'`]|\d{1,2})/g, nr = function(t3, e2, n2, r2, i2, o2) {
  var a2 = n2 + t3.length, s2 = r2.length, c2 = er;
  return void 0 !== i2 && (i2 = kt(i2), c2 = tr), Zn(o2, c2, function(o3, c3) {
    var l2;
    switch (Qn(c3, 0)) {
      case "$":
        return "$";
      case "&":
        return t3;
      case "`":
        return Jn(e2, 0, n2);
      case "'":
        return Jn(e2, a2);
      case "<":
        l2 = i2[Jn(c3, 1, -1)];
        break;
      default:
        var u2 = +c3;
        if (0 === u2)
          return o3;
        if (u2 > s2) {
          var h2 = Xn(u2 / 10);
          return 0 === h2 ? o3 : h2 <= s2 ? void 0 === r2[h2 - 1] ? Qn(c3, 1) : r2[h2 - 1] + Qn(c3, 1) : o3;
        }
        l2 = r2[u2 - 1];
    }
    return void 0 === l2 ? "" : l2;
  });
}, rr = TypeError, ir = function(t3, e2) {
  var n2 = t3.exec;
  if (Z(n2)) {
    var r2 = C(n2, t3, e2);
    return null !== r2 && Yt(r2), r2;
  }
  if ("RegExp" === W(t3))
    return C(Dn, t3, e2);
  throw rr("RegExp#exec called on incompatible receiver");
}, or = Pt("replace"), ar = Math.max, sr = Math.min, cr = L([].concat), lr = L([].push), ur = L("".indexOf), hr = L("".slice), pr = "$0" === "a".replace(/./, "$0"), fr = !!/./[or] && "" === /./[or]("a", "$0");
function dr(t3, e2) {
  if (t3 instanceof SVGElement) {
    var n2 = t3.getAttribute("class") || "";
    t3.setAttribute("class", n2.replace(e2, "").replace(/^\s+|\s+$/g, ""));
  } else
    t3.className = t3.className.replace(e2, "").replace(/^\s+|\s+$/g, "");
}
function br(t3, e2) {
  var n2 = "";
  if (t3.style.cssText && (n2 += t3.style.cssText), "string" == typeof e2)
    n2 += e2;
  else
    for (var r2 in e2)
      n2 += "".concat(r2, ":").concat(e2[r2], ";");
  t3.style.cssText = n2;
}
function mr(t3) {
  if (t3) {
    if (!this._introItems[this._currentStep])
      return;
    var e2 = this._introItems[this._currentStep], n2 = g(e2.element, this._targetElement), r2 = this._options.helperElementPadding;
    v(e2.element) ? u(t3, "introjs-fixedTooltip") : dr(t3, "introjs-fixedTooltip"), "floating" === e2.position && (r2 = 0), br(t3, { width: "".concat(n2.width + r2, "px"), height: "".concat(n2.height + r2, "px"), top: "".concat(n2.top - r2 / 2, "px"), left: "".concat(n2.left - r2 / 2, "px") });
  }
}
!function(t3, e2, n2, r2) {
  var i2 = Pt(t3), o2 = !y(function() {
    var e3 = {};
    return e3[i2] = function() {
      return 7;
    }, 7 != ""[t3](e3);
  }), a2 = o2 && !y(function() {
    var e3 = false, n3 = /a/;
    return "split" === t3 && ((n3 = {}).constructor = {}, n3.constructor[$n] = function() {
      return n3;
    }, n3.flags = "", n3[i2] = /./[i2]), n3.exec = function() {
      return e3 = true, null;
    }, n3[i2](""), !e3;
  });
  if (!o2 || !a2 || n2) {
    var s2 = L(/./[i2]), c2 = e2(i2, ""[t3], function(t4, e3, n3, r3, i3) {
      var a3 = L(t4), c3 = e3.exec;
      return c3 === Dn || c3 === zn.exec ? o2 && !i3 ? { done: true, value: s2(e3, n3, r3) } : { done: true, value: a3(n3, e3, r3) } : { done: false };
    });
    ke(String.prototype, t3, c2[0]), ke(zn, i2, c2[1]);
  }
  r2 && Jt(zn[i2], "sham", true);
}("replace", function(t3, e2, n2) {
  var r2 = fr ? "$" : "$0";
  return [function(t4, n3) {
    var r3 = X(this), i2 = null == t4 ? void 0 : mt(t4, or);
    return i2 ? C(i2, t4, r3, n3) : C(e2, cn(r3), t4, n3);
  }, function(t4, i2) {
    var o2 = Yt(this), a2 = cn(t4);
    if ("string" == typeof i2 && -1 === ur(i2, r2) && -1 === ur(i2, "$<")) {
      var s2 = n2(e2, o2, a2, i2);
      if (s2.done)
        return s2.value;
    }
    var c2 = Z(i2);
    c2 || (i2 = cn(i2));
    var l2 = o2.global;
    if (l2) {
      var u2 = o2.unicode;
      o2.lastIndex = 0;
    }
    for (var h2 = []; ; ) {
      var p2 = ir(o2, a2);
      if (null === p2)
        break;
      if (lr(h2, p2), !l2)
        break;
      "" === cn(p2[0]) && (o2.lastIndex = Kn(a2, Le(o2.lastIndex), u2));
    }
    for (var f2, d2 = "", b2 = 0, m2 = 0; m2 < h2.length; m2++) {
      for (var v2 = cn((p2 = h2[m2])[0]), g2 = ar(sr(Ae(p2.index), a2.length), 0), y2 = [], w2 = 1; w2 < p2.length; w2++)
        lr(y2, void 0 === (f2 = p2[w2]) ? f2 : String(f2));
      var x2 = p2.groups;
      if (c2) {
        var _2 = cr([v2], y2, g2, a2);
        void 0 !== x2 && lr(_2, x2);
        var k2 = cn(S(i2, void 0, _2));
      } else
        k2 = nr(v2, a2, g2, y2, x2, i2);
      g2 >= b2 && (d2 += hr(a2, b2, g2) + k2, b2 = g2 + v2.length);
    }
    return d2 + hr(a2, b2);
  }];
}, !!y(function() {
  var t3 = /./;
  return t3.exec = function() {
    var t4 = [];
    return t4.groups = { a: "7" }, t4;
  }, "7" !== "".replace(t3, "$<a>");
}) || !pr || fr);
var vr = Zt.f, gr = Pt("unscopables"), yr = Array.prototype;
null == yr[gr] && vr(yr, gr, { configurable: true, value: jn(null) });
var wr, xr = Te.includes;
function _r(t3, e2, n2, r2, i2) {
  return t3.left + e2 + n2.width > r2.width ? (i2.style.left = "".concat(r2.width - n2.width - t3.left, "px"), false) : (i2.style.left = "".concat(e2, "px"), true);
}
function kr(t3, e2, n2, r2) {
  return t3.left + t3.width - e2 - n2.width < 0 ? (r2.style.left = "".concat(-t3.left, "px"), false) : (r2.style.right = "".concat(e2, "px"), true);
}
function Sr(t3, e2) {
  t3.includes(e2) && t3.splice(t3.indexOf(e2), 1);
}
function jr(t3, e2, n2) {
  var r2 = this._options.positionPrecedence.slice(), i2 = d(), o2 = g(e2).height + 10, a2 = g(e2).width + 20, s2 = t3.getBoundingClientRect(), c2 = "floating";
  s2.bottom + o2 > i2.height && Sr(r2, "bottom"), s2.top - o2 < 0 && Sr(r2, "top"), s2.right + a2 > i2.width && Sr(r2, "right"), s2.left - a2 < 0 && Sr(r2, "left");
  var l2, u2, h2 = -1 !== (u2 = (l2 = n2 || "").indexOf("-")) ? l2.substr(u2) : "";
  return n2 && (n2 = n2.split("-")[0]), r2.length && (c2 = r2.includes(n2) ? n2 : r2[0]), ["top", "bottom"].includes(c2) && (c2 += function(t4, e3, n3, r3) {
    var i3 = n3.width, o3 = e3 / 2, a3 = Math.min(i3, window.screen.width), s3 = ["-left-aligned", "-middle-aligned", "-right-aligned"];
    return a3 - t4 < e3 && Sr(s3, "-left-aligned"), (t4 < o3 || a3 - t4 < o3) && Sr(s3, "-middle-aligned"), t4 < e3 && Sr(s3, "-right-aligned"), s3.length ? s3.includes(r3) ? r3 : s3[0] : "-middle-aligned";
  }(s2.left, a2, i2, h2)), c2;
}
function Cr(t3, e2, n2, r2) {
  var i2, o2, a2, s2, c2, l2 = "";
  if (r2 = r2 || false, e2.style.top = null, e2.style.right = null, e2.style.bottom = null, e2.style.left = null, e2.style.marginLeft = null, e2.style.marginTop = null, n2.style.display = "inherit", this._introItems[this._currentStep]) {
    l2 = "string" == typeof (i2 = this._introItems[this._currentStep]).tooltipClass ? i2.tooltipClass : this._options.tooltipClass, e2.className = ["introjs-tooltip", l2].filter(Boolean).join(" "), e2.setAttribute("role", "dialog"), "floating" !== (c2 = this._introItems[this._currentStep].position) && this._options.autoPosition && (c2 = jr.call(this, t3, e2, c2)), a2 = g(t3), o2 = g(e2), s2 = d(), u(e2, "introjs-".concat(c2));
    var h2 = a2.width / 2 - o2.width / 2;
    switch (c2) {
      case "top-right-aligned":
        n2.className = "introjs-arrow bottom-right";
        var p2 = 0;
        kr(a2, p2, o2, e2), e2.style.bottom = "".concat(a2.height + 20, "px");
        break;
      case "top-middle-aligned":
        n2.className = "introjs-arrow bottom-middle", r2 && (h2 += 5), kr(a2, h2, o2, e2) && (e2.style.right = null, _r(a2, h2, o2, s2, e2)), e2.style.bottom = "".concat(a2.height + 20, "px");
        break;
      case "top-left-aligned":
      case "top":
        n2.className = "introjs-arrow bottom", _r(a2, r2 ? 0 : 15, o2, s2, e2), e2.style.bottom = "".concat(a2.height + 20, "px");
        break;
      case "right":
        e2.style.left = "".concat(a2.width + 20, "px"), a2.top + o2.height > s2.height ? (n2.className = "introjs-arrow left-bottom", e2.style.top = "-".concat(o2.height - a2.height - 20, "px")) : n2.className = "introjs-arrow left";
        break;
      case "left":
        r2 || true !== this._options.showStepNumbers || (e2.style.top = "15px"), a2.top + o2.height > s2.height ? (e2.style.top = "-".concat(o2.height - a2.height - 20, "px"), n2.className = "introjs-arrow right-bottom") : n2.className = "introjs-arrow right", e2.style.right = "".concat(a2.width + 20, "px");
        break;
      case "floating":
        n2.style.display = "none", e2.style.left = "50%", e2.style.top = "50%", e2.style.marginLeft = "-".concat(o2.width / 2, "px"), e2.style.marginTop = "-".concat(o2.height / 2, "px");
        break;
      case "bottom-right-aligned":
        n2.className = "introjs-arrow top-right", kr(a2, p2 = 0, o2, e2), e2.style.top = "".concat(a2.height + 20, "px");
        break;
      case "bottom-middle-aligned":
        n2.className = "introjs-arrow top-middle", r2 && (h2 += 5), kr(a2, h2, o2, e2) && (e2.style.right = null, _r(a2, h2, o2, s2, e2)), e2.style.top = "".concat(a2.height + 20, "px");
        break;
      default:
        n2.className = "introjs-arrow top", _r(a2, 0, o2, s2, e2), e2.style.top = "".concat(a2.height + 20, "px");
    }
  }
}
function Ar() {
  c(document.querySelectorAll(".introjs-showElement"), function(t3) {
    dr(t3, /introjs-[a-zA-Z]+/g);
  });
}
function Er(t3, e2) {
  var n2 = document.createElement(t3);
  e2 = e2 || {};
  var r2 = /^(?:role|data-|aria-)/;
  for (var i2 in e2) {
    var o2 = e2[i2];
    "style" === i2 ? br(n2, o2) : i2.match(r2) ? n2.setAttribute(i2, o2) : n2[i2] = o2;
  }
  return n2;
}
function Nr(t3, e2, n2) {
  if (n2) {
    var r2 = e2.style.opacity || "1";
    br(e2, { opacity: "0" }), window.setTimeout(function() {
      br(e2, { opacity: r2 });
    }, 10);
  }
  t3.appendChild(e2);
}
function Ir() {
  return parseInt(this._currentStep + 1, 10) / this._introItems.length * 100;
}
function Lr() {
  var t3 = document.querySelector(".introjs-disableInteraction");
  null === t3 && (t3 = Er("div", { className: "introjs-disableInteraction" }), this._targetElement.appendChild(t3)), mr.call(this, t3);
}
function Or(t3) {
  var e2 = this, n2 = Er("div", { className: "introjs-bullets" });
  false === this._options.showBullets && (n2.style.display = "none");
  var r2 = Er("ul");
  r2.setAttribute("role", "tablist");
  var i2 = function() {
    e2.goToStep(this.getAttribute("data-step-number"));
  };
  return c(this._introItems, function(e3, n3) {
    var o2 = e3.step, a2 = Er("li"), s2 = Er("a");
    a2.setAttribute("role", "presentation"), s2.setAttribute("role", "tab"), s2.onclick = i2, n3 === t3.step - 1 && (s2.className = "active"), m(s2), s2.innerHTML = "&nbsp;", s2.setAttribute("data-step-number", o2), a2.appendChild(s2), r2.appendChild(a2);
  }), n2.appendChild(r2), n2;
}
function Tr(t3, e2) {
  if (this._options.showBullets) {
    var n2 = document.querySelector(".introjs-bullets");
    n2 && n2.parentNode.replaceChild(Or.call(this, e2), n2);
  }
}
function Pr(t3, e2) {
  this._options.showBullets && (t3.querySelector(".introjs-bullets li > a.active").className = "", t3.querySelector('.introjs-bullets li > a[data-step-number="'.concat(e2.step, '"]')).className = "active");
}
function Rr() {
  var t3 = Er("div");
  t3.className = "introjs-progress", false === this._options.showProgress && (t3.style.display = "none");
  var e2 = Er("div", { className: "introjs-progressbar" });
  return this._options.progressBarAdditionalClass && (e2.className += " " + this._options.progressBarAdditionalClass), e2.setAttribute("role", "progress"), e2.setAttribute("aria-valuemin", 0), e2.setAttribute("aria-valuemax", 100), e2.setAttribute("aria-valuenow", Ir.call(this)), e2.style.cssText = "width:".concat(Ir.call(this), "%;"), t3.appendChild(e2), t3;
}
function qr(t3) {
  t3.querySelector(".introjs-progress .introjs-progressbar").style.cssText = "width:".concat(Ir.call(this), "%;"), t3.querySelector(".introjs-progress .introjs-progressbar").setAttribute("aria-valuenow", Ir.call(this));
}
function Br(t3) {
  return Mr.apply(this, arguments);
}
function Mr() {
  return (Mr = r(t().mark(function e2(n2) {
    var i2, o2, a2, s2, c2, l2, h2, d2, v2, g2, y2, w2, x2, _2, k2, S2, j2, C2, A2, E2, N2, I2, L2, O2, T2, P2 = this;
    return t().wrap(function(e3) {
      for (; ; )
        switch (e3.prev = e3.next) {
          case 0:
            if (void 0 === this._introChangeCallback) {
              e3.next = 3;
              break;
            }
            return e3.next = 3, this._introChangeCallback.call(this, n2.element);
          case 3:
            if (i2 = this, o2 = document.querySelector(".introjs-helperLayer"), a2 = document.querySelector(".introjs-tooltipReferenceLayer"), s2 = "introjs-helperLayer", "string" == typeof n2.highlightClass && (s2 += " ".concat(n2.highlightClass)), "string" == typeof this._options.highlightClass && (s2 += " ".concat(this._options.highlightClass)), null !== o2 && null !== a2 ? (d2 = a2.querySelector(".introjs-helperNumberLayer"), v2 = a2.querySelector(".introjs-tooltiptext"), g2 = a2.querySelector(".introjs-tooltip-title"), y2 = a2.querySelector(".introjs-arrow"), w2 = a2.querySelector(".introjs-tooltip"), h2 = a2.querySelector(".introjs-skipbutton"), l2 = a2.querySelector(".introjs-prevbutton"), c2 = a2.querySelector(".introjs-nextbutton"), o2.className = s2, w2.style.opacity = 0, w2.style.display = "none", f.call(i2, n2), mr.call(i2, o2), mr.call(i2, a2), Ar(), i2._lastShowElementTimer && window.clearTimeout(i2._lastShowElementTimer), i2._lastShowElementTimer = window.setTimeout(function() {
              null !== d2 && (d2.innerHTML = "".concat(n2.step, " ").concat(P2._options.stepNumbersOfLabel, " ").concat(P2._introItems.length)), v2.innerHTML = n2.intro, g2.innerHTML = n2.title, w2.style.display = "block", Cr.call(i2, n2.element, w2, y2), Pr.call(i2, a2, n2), qr.call(i2, a2), w2.style.opacity = 1, (null != c2 && /introjs-donebutton/gi.test(c2.className) || null != c2) && c2.focus(), b.call(i2, n2.scrollTo, n2, v2);
            }, 350)) : (x2 = Er("div", { className: s2 }), _2 = Er("div", { className: "introjs-tooltipReferenceLayer" }), k2 = Er("div", { className: "introjs-arrow" }), S2 = Er("div", { className: "introjs-tooltip" }), j2 = Er("div", { className: "introjs-tooltiptext" }), C2 = Er("div", { className: "introjs-tooltip-header" }), A2 = Er("h1", { className: "introjs-tooltip-title" }), E2 = Er("div"), br(x2, { "box-shadow": "0 0 1px 2px rgba(33, 33, 33, 0.8), rgba(33, 33, 33, ".concat(i2._options.overlayOpacity.toString(), ") 0 0 0 5000px") }), f.call(i2, n2), mr.call(i2, x2), mr.call(i2, _2), Nr(this._targetElement, x2, true), Nr(this._targetElement, _2), j2.innerHTML = n2.intro, A2.innerHTML = n2.title, E2.className = "introjs-tooltipbuttons", false === this._options.showButtons && (E2.style.display = "none"), C2.appendChild(A2), S2.appendChild(C2), S2.appendChild(j2), this._options.dontShowAgain && (N2 = Er("div", { className: "introjs-dontShowAgain" }), (I2 = Er("input", { type: "checkbox", id: "introjs-dontShowAgain", name: "introjs-dontShowAgain" })).onchange = function(t3) {
              P2.setDontShowAgain(t3.target.checked);
            }, (L2 = Er("label", { htmlFor: "introjs-dontShowAgain" })).innerText = this._options.dontShowAgainLabel, N2.appendChild(I2), N2.appendChild(L2), S2.appendChild(N2)), S2.appendChild(Or.call(this, n2)), S2.appendChild(Rr.call(this)), O2 = Er("div"), true === this._options.showStepNumbers && (O2.className = "introjs-helperNumberLayer", O2.innerHTML = "".concat(n2.step, " ").concat(this._options.stepNumbersOfLabel, " ").concat(this._introItems.length), S2.appendChild(O2)), S2.appendChild(k2), _2.appendChild(S2), (c2 = Er("a")).onclick = r(t().mark(function e4() {
              return t().wrap(function(t3) {
                for (; ; )
                  switch (t3.prev = t3.next) {
                    case 0:
                      if (i2._introItems.length - 1 === i2._currentStep) {
                        t3.next = 5;
                        break;
                      }
                      return t3.next = 3, zr.call(i2);
                    case 3:
                      t3.next = 11;
                      break;
                    case 5:
                      if (!/introjs-donebutton/gi.test(c2.className)) {
                        t3.next = 11;
                        break;
                      }
                      if ("function" != typeof i2._introCompleteCallback) {
                        t3.next = 9;
                        break;
                      }
                      return t3.next = 9, i2._introCompleteCallback.call(i2, i2._currentStep, "done");
                    case 9:
                      return t3.next = 11, wi.call(i2, i2._targetElement);
                    case 11:
                    case "end":
                      return t3.stop();
                  }
              }, e4);
            })), m(c2), c2.innerHTML = this._options.nextLabel, (l2 = Er("a")).onclick = r(t().mark(function e4() {
              return t().wrap(function(t3) {
                for (; ; )
                  switch (t3.prev = t3.next) {
                    case 0:
                      if (0 === i2._currentStep) {
                        t3.next = 3;
                        break;
                      }
                      return t3.next = 3, Wr.call(i2);
                    case 3:
                    case "end":
                      return t3.stop();
                  }
              }, e4);
            })), m(l2), l2.innerHTML = this._options.prevLabel, m(h2 = Er("a", { className: "introjs-skipbutton" })), h2.innerHTML = this._options.skipLabel, h2.onclick = r(t().mark(function e4() {
              return t().wrap(function(t3) {
                for (; ; )
                  switch (t3.prev = t3.next) {
                    case 0:
                      if (i2._introItems.length - 1 !== i2._currentStep || "function" != typeof i2._introCompleteCallback) {
                        t3.next = 3;
                        break;
                      }
                      return t3.next = 3, i2._introCompleteCallback.call(i2, i2._currentStep, "skip");
                    case 3:
                      if ("function" != typeof i2._introSkipCallback) {
                        t3.next = 6;
                        break;
                      }
                      return t3.next = 6, i2._introSkipCallback.call(i2);
                    case 6:
                      return t3.next = 8, wi.call(i2, i2._targetElement);
                    case 8:
                    case "end":
                      return t3.stop();
                  }
              }, e4);
            })), C2.appendChild(h2), this._introItems.length > 1 && E2.appendChild(l2), E2.appendChild(c2), S2.appendChild(E2), Cr.call(i2, n2.element, S2, k2), b.call(this, n2.scrollTo, n2, S2)), (T2 = i2._targetElement.querySelector(".introjs-disableInteraction")) && T2.parentNode.removeChild(T2), n2.disableInteraction && Lr.call(i2), 0 === this._currentStep && this._introItems.length > 1 ? (null != c2 && (c2.className = "".concat(this._options.buttonClass, " introjs-nextbutton"), c2.innerHTML = this._options.nextLabel), true === this._options.hidePrev ? (null != l2 && (l2.className = "".concat(this._options.buttonClass, " introjs-prevbutton introjs-hidden")), null != c2 && u(c2, "introjs-fullbutton")) : null != l2 && (l2.className = "".concat(this._options.buttonClass, " introjs-prevbutton introjs-disabled"))) : this._introItems.length - 1 === this._currentStep || 1 === this._introItems.length ? (null != l2 && (l2.className = "".concat(this._options.buttonClass, " introjs-prevbutton")), true === this._options.hideNext ? (null != c2 && (c2.className = "".concat(this._options.buttonClass, " introjs-nextbutton introjs-hidden")), null != l2 && u(l2, "introjs-fullbutton")) : null != c2 && (true === this._options.nextToDone ? (c2.innerHTML = this._options.doneLabel, u(c2, "".concat(this._options.buttonClass, " introjs-nextbutton introjs-donebutton"))) : c2.className = "".concat(this._options.buttonClass, " introjs-nextbutton introjs-disabled"))) : (null != l2 && (l2.className = "".concat(this._options.buttonClass, " introjs-prevbutton")), null != c2 && (c2.className = "".concat(this._options.buttonClass, " introjs-nextbutton"), c2.innerHTML = this._options.nextLabel)), null != l2 && l2.setAttribute("role", "button"), null != c2 && c2.setAttribute("role", "button"), null != h2 && h2.setAttribute("role", "button"), null != c2 && c2.focus(), p(n2), void 0 === this._introAfterChangeCallback) {
              e3.next = 22;
              break;
            }
            return e3.next = 22, this._introAfterChangeCallback.call(this, n2.element);
          case 22:
          case "end":
            return e3.stop();
        }
    }, e2, this);
  }))).apply(this, arguments);
}
function Hr(t3) {
  return Fr.apply(this, arguments);
}
function Fr() {
  return (Fr = r(t().mark(function e2(n2) {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (this._currentStep = n2 - 2, void 0 === this._introItems) {
              t3.next = 4;
              break;
            }
            return t3.next = 4, zr.call(this);
          case 4:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  }))).apply(this, arguments);
}
function Dr(t3) {
  return $r.apply(this, arguments);
}
function $r() {
  return ($r = r(t().mark(function e2(n2) {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (this._currentStepNumber = n2, void 0 === this._introItems) {
              t3.next = 4;
              break;
            }
            return t3.next = 4, zr.call(this);
          case 4:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  }))).apply(this, arguments);
}
function zr() {
  return Gr.apply(this, arguments);
}
function Gr() {
  return Gr = r(t().mark(function e2() {
    var n2, r2, i2 = this;
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (this._direction = "forward", void 0 !== this._currentStepNumber && c(this._introItems, function(t4, e3) {
              t4.step === i2._currentStepNumber && (i2._currentStep = e3 - 1, i2._currentStepNumber = void 0);
            }), void 0 === this._currentStep ? this._currentStep = 0 : ++this._currentStep, n2 = this._introItems[this._currentStep], r2 = true, void 0 === this._introBeforeChangeCallback) {
              t3.next = 9;
              break;
            }
            return t3.next = 8, this._introBeforeChangeCallback.call(this, n2 && n2.element);
          case 8:
            r2 = t3.sent;
          case 9:
            if (false !== r2) {
              t3.next = 12;
              break;
            }
            return --this._currentStep, t3.abrupt("return", false);
          case 12:
            if (!(this._introItems.length <= this._currentStep)) {
              t3.next = 19;
              break;
            }
            if ("function" != typeof this._introCompleteCallback) {
              t3.next = 16;
              break;
            }
            return t3.next = 16, this._introCompleteCallback.call(this, this._currentStep, "end");
          case 16:
            return t3.next = 18, wi.call(this, this._targetElement);
          case 18:
            return t3.abrupt("return");
          case 19:
            return t3.next = 21, Br.call(this, n2);
          case 21:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  })), Gr.apply(this, arguments);
}
function Wr() {
  return Vr.apply(this, arguments);
}
function Vr() {
  return Vr = r(t().mark(function e2() {
    var n2, r2;
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (this._direction = "backward", 0 !== this._currentStep) {
              t3.next = 3;
              break;
            }
            return t3.abrupt("return", false);
          case 3:
            if (--this._currentStep, n2 = this._introItems[this._currentStep], r2 = true, void 0 === this._introBeforeChangeCallback) {
              t3.next = 10;
              break;
            }
            return t3.next = 9, this._introBeforeChangeCallback.call(this, n2 && n2.element);
          case 9:
            r2 = t3.sent;
          case 10:
            if (false !== r2) {
              t3.next = 13;
              break;
            }
            return ++this._currentStep, t3.abrupt("return", false);
          case 13:
            return t3.next = 15, Br.call(this, n2);
          case 15:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  })), Vr.apply(this, arguments);
}
function Ur() {
  return this._currentStep;
}
function Yr(t3) {
  return Kr.apply(this, arguments);
}
function Kr() {
  return (Kr = r(t().mark(function e2(n2) {
    var r2, i2;
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (null === (r2 = void 0 === n2.code ? n2.which : n2.code) && (r2 = null === n2.charCode ? n2.keyCode : n2.charCode), "Escape" !== r2 && 27 !== r2 || true !== this._options.exitOnEsc) {
              t3.next = 7;
              break;
            }
            return t3.next = 5, wi.call(this, this._targetElement);
          case 5:
            t3.next = 39;
            break;
          case 7:
            if ("ArrowLeft" !== r2 && 37 !== r2) {
              t3.next = 12;
              break;
            }
            return t3.next = 10, Wr.call(this);
          case 10:
            t3.next = 39;
            break;
          case 12:
            if ("ArrowRight" !== r2 && 39 !== r2) {
              t3.next = 17;
              break;
            }
            return t3.next = 15, zr.call(this);
          case 15:
            t3.next = 39;
            break;
          case 17:
            if ("Enter" !== r2 && "NumpadEnter" !== r2 && 13 !== r2) {
              t3.next = 39;
              break;
            }
            if (!(i2 = n2.target || n2.srcElement) || !i2.className.match("introjs-prevbutton")) {
              t3.next = 24;
              break;
            }
            return t3.next = 22, Wr.call(this);
          case 22:
            t3.next = 38;
            break;
          case 24:
            if (!i2 || !i2.className.match("introjs-skipbutton")) {
              t3.next = 32;
              break;
            }
            if (this._introItems.length - 1 !== this._currentStep || "function" != typeof this._introCompleteCallback) {
              t3.next = 28;
              break;
            }
            return t3.next = 28, this._introCompleteCallback.call(this, this._currentStep, "skip");
          case 28:
            return t3.next = 30, wi.call(this, this._targetElement);
          case 30:
            t3.next = 38;
            break;
          case 32:
            if (!i2 || !i2.getAttribute("data-step-number")) {
              t3.next = 36;
              break;
            }
            i2.click(), t3.next = 38;
            break;
          case 36:
            return t3.next = 38, zr.call(this);
          case 38:
            n2.preventDefault ? n2.preventDefault() : n2.returnValue = false;
          case 39:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  }))).apply(this, arguments);
}
function Xr(t3) {
  if (null === t3 || "object" !== e(t3) || void 0 !== t3.nodeType)
    return t3;
  var n2 = {};
  for (var r2 in t3)
    void 0 !== window.jQuery && t3[r2] instanceof window.jQuery ? n2[r2] = t3[r2] : n2[r2] = Xr(t3[r2]);
  return n2;
}
function Qr(t3, e2) {
  var n2, r2 = this;
  return function() {
    for (var i2 = arguments.length, o2 = new Array(i2), a2 = 0; a2 < i2; a2++)
      o2[a2] = arguments[a2];
    clearTimeout(n2), n2 = setTimeout(function() {
      t3.apply(r2, o2);
    }, e2);
  };
}
function Zr(t3) {
  var e2 = document.querySelector(".introjs-hints");
  return e2 ? e2.querySelectorAll(t3) : [];
}
function Jr(t3) {
  return ti.apply(this, arguments);
}
function ti() {
  return (ti = r(t().mark(function e2(n2) {
    var r2;
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (r2 = Zr('.introjs-hint[data-step="'.concat(n2, '"]'))[0], pi.call(this), r2 && u(r2, "introjs-hidehint"), void 0 === this._hintCloseCallback) {
              t3.next = 6;
              break;
            }
            return t3.next = 6, this._hintCloseCallback.call(this, n2);
          case 6:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  }))).apply(this, arguments);
}
function ei() {
  var e2 = this;
  c(Zr(".introjs-hint"), function() {
    var n2 = r(t().mark(function n3(r2) {
      return t().wrap(function(t3) {
        for (; ; )
          switch (t3.prev = t3.next) {
            case 0:
              return t3.next = 2, Jr.call(e2, r2.getAttribute("data-step"));
            case 2:
            case "end":
              return t3.stop();
          }
      }, n3);
    }));
    return function(t3) {
      return n2.apply(this, arguments);
    };
  }());
}
function ni() {
  return ri.apply(this, arguments);
}
function ri() {
  return (ri = r(t().mark(function e2() {
    var n2, r2 = this;
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (!(n2 = Zr(".introjs-hint")) || !n2.length) {
              t3.next = 5;
              break;
            }
            c(n2, function(t4) {
              ii.call(r2, t4.getAttribute("data-step"));
            }), t3.next = 7;
            break;
          case 5:
            return t3.next = 7, fi.call(this, this._targetElement);
          case 7:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  }))).apply(this, arguments);
}
function ii(t3) {
  var e2 = Zr('.introjs-hint[data-step="'.concat(t3, '"]'))[0];
  e2 && dr(e2, /introjs-hidehint/g);
}
function oi() {
  var t3 = this;
  c(Zr(".introjs-hint"), function(e2) {
    ai.call(t3, e2.getAttribute("data-step"));
  }), l.off(document, "click", pi, this, false), l.off(window, "resize", bi, this, true), this._hintsAutoRefreshFunction && l.off(window, "scroll", this._hintsAutoRefreshFunction, this, true);
}
function ai(t3) {
  var e2 = Zr('.introjs-hint[data-step="'.concat(t3, '"]'))[0];
  e2 && e2.parentNode.removeChild(e2);
}
function si() {
  return ci.apply(this, arguments);
}
function ci() {
  return (ci = r(t().mark(function e2() {
    var n2, r2, i2, o2 = this;
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (n2 = this, null === (r2 = document.querySelector(".introjs-hints")) && (r2 = Er("div", { className: "introjs-hints" })), i2 = function(t4) {
              return function(e3) {
                var r3 = e3 || window.event;
                r3.stopPropagation && r3.stopPropagation(), null !== r3.cancelBubble && (r3.cancelBubble = true), ui.call(n2, t4);
              };
            }, c(this._introItems, function(t4, e3) {
              if (!document.querySelector('.introjs-hint[data-step="'.concat(e3, '"]'))) {
                var n3 = Er("a", { className: "introjs-hint" });
                m(n3), n3.onclick = i2(e3), t4.hintAnimation || u(n3, "introjs-hint-no-anim"), v(t4.element) && u(n3, "introjs-fixedhint");
                var a2 = Er("div", { className: "introjs-hint-dot" }), s2 = Er("div", { className: "introjs-hint-pulse" });
                n3.appendChild(a2), n3.appendChild(s2), n3.setAttribute("data-step", e3), t4.targetElement = t4.element, t4.element = n3, li.call(o2, t4.hintPosition, n3, t4.targetElement), r2.appendChild(n3);
              }
            }), document.body.appendChild(r2), void 0 === this._hintsAddedCallback) {
              t3.next = 9;
              break;
            }
            return t3.next = 9, this._hintsAddedCallback.call(this);
          case 9:
            this._options.hintAutoRefreshInterval >= 0 && (this._hintsAutoRefreshFunction = Qr(function() {
              return bi.call(o2);
            }, this._options.hintAutoRefreshInterval), l.on(window, "scroll", this._hintsAutoRefreshFunction, this, true));
          case 10:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  }))).apply(this, arguments);
}
function li(t3, e2, n2) {
  var r2 = e2.style, i2 = g.call(this, n2), o2 = 20, a2 = 20;
  switch (t3) {
    default:
    case "top-left":
      r2.left = "".concat(i2.left, "px"), r2.top = "".concat(i2.top, "px");
      break;
    case "top-right":
      r2.left = "".concat(i2.left + i2.width - o2, "px"), r2.top = "".concat(i2.top, "px");
      break;
    case "bottom-left":
      r2.left = "".concat(i2.left, "px"), r2.top = "".concat(i2.top + i2.height - a2, "px");
      break;
    case "bottom-right":
      r2.left = "".concat(i2.left + i2.width - o2, "px"), r2.top = "".concat(i2.top + i2.height - a2, "px");
      break;
    case "middle-left":
      r2.left = "".concat(i2.left, "px"), r2.top = "".concat(i2.top + (i2.height - a2) / 2, "px");
      break;
    case "middle-right":
      r2.left = "".concat(i2.left + i2.width - o2, "px"), r2.top = "".concat(i2.top + (i2.height - a2) / 2, "px");
      break;
    case "middle-middle":
      r2.left = "".concat(i2.left + (i2.width - o2) / 2, "px"), r2.top = "".concat(i2.top + (i2.height - a2) / 2, "px");
      break;
    case "bottom-middle":
      r2.left = "".concat(i2.left + (i2.width - o2) / 2, "px"), r2.top = "".concat(i2.top + i2.height - a2, "px");
      break;
    case "top-middle":
      r2.left = "".concat(i2.left + (i2.width - o2) / 2, "px"), r2.top = "".concat(i2.top, "px");
  }
}
function ui(t3) {
  return hi.apply(this, arguments);
}
function hi() {
  return (hi = r(t().mark(function e2(n2) {
    var r2, i2, o2, a2, s2, c2, l2, u2, h2;
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (r2 = document.querySelector('.introjs-hint[data-step="'.concat(n2, '"]')), i2 = this._introItems[n2], void 0 === this._hintClickCallback) {
              t3.next = 5;
              break;
            }
            return t3.next = 5, this._hintClickCallback.call(this, r2, i2, n2);
          case 5:
            if (o2 = pi.call(this), parseInt(o2, 10) !== n2) {
              t3.next = 8;
              break;
            }
            return t3.abrupt("return");
          case 8:
            a2 = Er("div", { className: "introjs-tooltip" }), s2 = Er("div"), c2 = Er("div"), l2 = Er("div"), a2.onclick = function(t4) {
              t4.stopPropagation ? t4.stopPropagation() : t4.cancelBubble = true;
            }, s2.className = "introjs-tooltiptext", (u2 = Er("p")).innerHTML = i2.hint, s2.appendChild(u2), this._options.hintShowButton && ((h2 = Er("a")).className = this._options.buttonClass, h2.setAttribute("role", "button"), h2.innerHTML = this._options.hintButtonLabel, h2.onclick = Jr.bind(this, n2), s2.appendChild(h2)), c2.className = "introjs-arrow", a2.appendChild(c2), a2.appendChild(s2), this._currentStep = r2.getAttribute("data-step"), l2.className = "introjs-tooltipReferenceLayer introjs-hintReference", l2.setAttribute("data-step", r2.getAttribute("data-step")), mr.call(this, l2), l2.appendChild(a2), document.body.appendChild(l2), Cr.call(this, r2, a2, c2, true);
          case 28:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  }))).apply(this, arguments);
}
function pi() {
  var t3 = document.querySelector(".introjs-hintReference");
  if (t3) {
    var e2 = t3.getAttribute("data-step");
    return t3.parentNode.removeChild(t3), e2;
  }
}
function fi(t3) {
  return di.apply(this, arguments);
}
function di() {
  return (di = r(t().mark(function e2(n2) {
    var r2, i2 = this;
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (this._introItems = [], !this._options.hints) {
              t3.next = 5;
              break;
            }
            c(this._options.hints, function(t4) {
              var e3 = Xr(t4);
              "string" == typeof e3.element && (e3.element = document.querySelector(e3.element)), e3.hintPosition = e3.hintPosition || i2._options.hintPosition, e3.hintAnimation = e3.hintAnimation || i2._options.hintAnimation, null !== e3.element && i2._introItems.push(e3);
            }), t3.next = 9;
            break;
          case 5:
            if ((r2 = n2.querySelectorAll("*[data-hint]")) && r2.length) {
              t3.next = 8;
              break;
            }
            return t3.abrupt("return", false);
          case 8:
            c(r2, function(t4) {
              var e3 = t4.getAttribute("data-hint-animation");
              e3 = e3 ? "true" === e3 : i2._options.hintAnimation, i2._introItems.push({ element: t4, hint: t4.getAttribute("data-hint"), hintPosition: t4.getAttribute("data-hint-position") || i2._options.hintPosition, hintAnimation: e3, tooltipClass: t4.getAttribute("data-tooltip-class"), position: t4.getAttribute("data-position") || i2._options.tooltipPosition });
            });
          case 9:
            return t3.next = 11, si.call(this);
          case 11:
            l.on(document, "click", pi, this, false), l.on(window, "resize", bi, this, true);
          case 13:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  }))).apply(this, arguments);
}
function bi() {
  var t3 = this;
  c(this._introItems, function(e2) {
    var n2 = e2.targetElement, r2 = e2.hintPosition, i2 = e2.element;
    void 0 !== n2 && li.call(t3, r2, i2, n2);
  });
}
function mi(t3) {
  var e2 = this, n2 = t3.querySelectorAll("*[data-intro]"), r2 = [];
  if (this._options.steps)
    c(this._options.steps, function(t4) {
      var n3 = Xr(t4);
      if (n3.step = r2.length + 1, n3.title = n3.title || "", "string" == typeof n3.element && (n3.element = document.querySelector(n3.element)), void 0 === n3.element || null === n3.element) {
        var i3 = document.querySelector(".introjsFloatingElement");
        null === i3 && (i3 = Er("div", { className: "introjsFloatingElement" }), document.body.appendChild(i3)), n3.element = i3, n3.position = "floating";
      }
      n3.position = n3.position || e2._options.tooltipPosition, n3.scrollTo = n3.scrollTo || e2._options.scrollTo, void 0 === n3.disableInteraction && (n3.disableInteraction = e2._options.disableInteraction), null !== n3.element && r2.push(n3);
    });
  else {
    var i2;
    if (n2.length < 1)
      return [];
    c(n2, function(t4) {
      if ((!e2._options.group || t4.getAttribute("data-intro-group") === e2._options.group) && "none" !== t4.style.display) {
        var n3 = parseInt(t4.getAttribute("data-step"), 10);
        i2 = t4.hasAttribute("data-disable-interaction") ? !!t4.getAttribute("data-disable-interaction") : e2._options.disableInteraction, n3 > 0 && (r2[n3 - 1] = { element: t4, title: t4.getAttribute("data-title") || "", intro: t4.getAttribute("data-intro"), step: parseInt(t4.getAttribute("data-step"), 10), tooltipClass: t4.getAttribute("data-tooltip-class"), highlightClass: t4.getAttribute("data-highlight-class"), position: t4.getAttribute("data-position") || e2._options.tooltipPosition, scrollTo: t4.getAttribute("data-scroll-to") || e2._options.scrollTo, disableInteraction: i2 });
      }
    });
    var o2 = 0;
    c(n2, function(t4) {
      if ((!e2._options.group || t4.getAttribute("data-intro-group") === e2._options.group) && null === t4.getAttribute("data-step")) {
        for (; void 0 !== r2[o2]; )
          o2++;
        i2 = t4.hasAttribute("data-disable-interaction") ? !!t4.getAttribute("data-disable-interaction") : e2._options.disableInteraction, r2[o2] = { element: t4, title: t4.getAttribute("data-title") || "", intro: t4.getAttribute("data-intro"), step: o2 + 1, tooltipClass: t4.getAttribute("data-tooltip-class"), highlightClass: t4.getAttribute("data-highlight-class"), position: t4.getAttribute("data-position") || e2._options.tooltipPosition, scrollTo: t4.getAttribute("data-scroll-to") || e2._options.scrollTo, disableInteraction: i2 };
      }
    });
  }
  for (var a2 = [], s2 = 0; s2 < r2.length; s2++)
    r2[s2] && a2.push(r2[s2]);
  return (r2 = a2).sort(function(t4, e3) {
    return t4.step - e3.step;
  }), r2;
}
function vi(t3) {
  var e2 = document.querySelector(".introjs-tooltipReferenceLayer"), n2 = document.querySelector(".introjs-helperLayer"), r2 = document.querySelector(".introjs-disableInteraction");
  if (mr.call(this, n2), mr.call(this, e2), mr.call(this, r2), t3 && (this._introItems = mi.call(this, this._targetElement), Tr.call(this, e2, this._introItems[this._currentStep]), qr.call(this, e2)), void 0 !== this._currentStep && null !== this._currentStep) {
    var i2 = document.querySelector(".introjs-arrow"), o2 = document.querySelector(".introjs-tooltip");
    o2 && i2 && Cr.call(this, this._introItems[this._currentStep].element, o2, i2);
  }
  return bi.call(this), this;
}
function gi() {
  vi.call(this);
}
function yi(t3, e2) {
  if (t3 && t3.parentElement) {
    var n2 = t3.parentElement;
    e2 ? (br(t3, { opacity: "0" }), window.setTimeout(function() {
      try {
        n2.removeChild(t3);
      } catch (t4) {
      }
    }, 500)) : n2.removeChild(t3);
  }
}
function wi(t3, e2) {
  return xi.apply(this, arguments);
}
function xi() {
  return (xi = r(t().mark(function e2(n2, r2) {
    var i2, o2;
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (i2 = true, void 0 === this._introBeforeExitCallback) {
              t3.next = 5;
              break;
            }
            return t3.next = 4, this._introBeforeExitCallback.call(this);
          case 4:
            i2 = t3.sent;
          case 5:
            if (r2 || false !== i2) {
              t3.next = 7;
              break;
            }
            return t3.abrupt("return");
          case 7:
            if ((o2 = n2.querySelectorAll(".introjs-overlay")) && o2.length && c(o2, function(t4) {
              return yi(t4);
            }), yi(n2.querySelector(".introjs-helperLayer"), true), yi(n2.querySelector(".introjs-tooltipReferenceLayer")), yi(n2.querySelector(".introjs-disableInteraction")), yi(document.querySelector(".introjsFloatingElement")), Ar(), l.off(window, "keydown", Yr, this, true), l.off(window, "resize", gi, this, true), void 0 === this._introExitCallback) {
              t3.next = 23;
              break;
            }
            return t3.next = 23, this._introExitCallback.call(this);
          case 23:
            this._currentStep = void 0;
          case 24:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  }))).apply(this, arguments);
}
function _i(e2) {
  var n2 = this, i2 = Er("div", { className: "introjs-overlay" });
  return br(i2, { top: 0, bottom: 0, left: 0, right: 0, position: "fixed" }), e2.appendChild(i2), true === this._options.exitOnOverlayClick && (br(i2, { cursor: "pointer" }), i2.onclick = r(t().mark(function r2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, wi.call(n2, e2);
          case 2:
          case "end":
            return t3.stop();
        }
    }, r2);
  }))), true;
}
function ki(t3) {
  return Si.apply(this, arguments);
}
function Si() {
  return (Si = r(t().mark(function e2(n2) {
    var r2;
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            if (this.isActive()) {
              t3.next = 2;
              break;
            }
            return t3.abrupt("return");
          case 2:
            if (void 0 === this._introStartCallback) {
              t3.next = 5;
              break;
            }
            return t3.next = 5, this._introStartCallback.call(this, n2);
          case 5:
            if (0 !== (r2 = mi.call(this, n2)).length) {
              t3.next = 8;
              break;
            }
            return t3.abrupt("return", false);
          case 8:
            if (this._introItems = r2, !_i.call(this, n2)) {
              t3.next = 14;
              break;
            }
            return t3.next = 12, zr.call(this);
          case 12:
            this._options.keyboardNavigation && l.on(window, "keydown", Yr, this, true), l.on(window, "resize", gi, this, true);
          case 14:
            return t3.abrupt("return", false);
          case 15:
          case "end":
            return t3.stop();
        }
    }, e2, this);
  }))).apply(this, arguments);
}
function ji(t3, e2, n2) {
  var r2, o2 = (i(r2 = {}, t3, e2), i(r2, "path", "/"), r2);
  if (n2) {
    var a2 = new Date();
    a2.setTime(a2.getTime() + 24 * n2 * 60 * 60 * 1e3), o2.expires = a2.toUTCString();
  }
  var s2 = [];
  for (var c2 in o2)
    s2.push("".concat(c2, "=").concat(o2[c2]));
  return document.cookie = s2.join("; "), Ci(t3);
}
function Ci(t3) {
  return (e2 = {}, document.cookie.split(";").forEach(function(t4) {
    var n2 = o(t4.split("="), 2), r2 = n2[0], i2 = n2[1];
    e2[r2.trim()] = i2;
  }), e2)[t3];
  var e2;
}
Ze({ target: "Array", proto: true, forced: y(function() {
  return !Array(1).includes();
}) }, { includes: function(t3) {
  return xr(this, t3, arguments.length > 1 ? arguments[1] : void 0);
} }), wr = "includes", yr[gr][wr] = true;
function Ai(t3) {
  t3 ? ji(this._options.dontShowAgainCookie, "true", this._options.dontShowAgainCookieDays) : ji(this._options.dontShowAgainCookie, "", -1);
}
function Ei() {
  var t3 = Ci(this._options.dontShowAgainCookie);
  return t3 && "true" === t3;
}
function Ni(t3) {
  this._targetElement = t3, this._introItems = [], this._options = { isActive: true, nextLabel: "Next", prevLabel: "Back", skipLabel: "×", doneLabel: "Done", hidePrev: false, hideNext: false, nextToDone: true, tooltipPosition: "bottom", tooltipClass: "", group: "", highlightClass: "", exitOnEsc: true, exitOnOverlayClick: true, showStepNumbers: false, stepNumbersOfLabel: "of", keyboardNavigation: true, showButtons: true, showBullets: true, showProgress: false, scrollToElement: true, scrollTo: "element", scrollPadding: 30, overlayOpacity: 0.5, autoPosition: true, positionPrecedence: ["bottom", "top", "right", "left"], disableInteraction: false, dontShowAgain: false, dontShowAgainLabel: "Don't show this again", dontShowAgainCookie: "introjs-dontShowAgain", dontShowAgainCookieDays: 365, helperElementPadding: 10, hintPosition: "top-middle", hintButtonLabel: "Got it", hintShowButton: true, hintAutoRefreshInterval: 10, hintAnimation: true, buttonClass: "introjs-button", progressBarAdditionalClass: false };
}
var Ii = function t2(n2) {
  var r2;
  if ("object" === e(n2))
    r2 = new Ni(n2);
  else if ("string" == typeof n2) {
    var i2 = document.querySelector(n2);
    if (!i2)
      throw new Error("There is no element with given selector.");
    r2 = new Ni(i2);
  } else
    r2 = new Ni(document.body);
  return t2.instances[s(r2, "introjs-instance")] = r2, r2;
};
Ii.version = "6.0.0", Ii.instances = {}, Ii.fn = Ni.prototype = { isActive: function() {
  return (!this._options.dontShowAgain || !Ei.call(this)) && this._options.isActive;
}, clone: function() {
  return new Ni(this);
}, setOption: function(t3, e2) {
  return this._options[t3] = e2, this;
}, setOptions: function(t3) {
  return this._options = function(t4, e2) {
    var n2, r2 = {};
    for (n2 in t4)
      r2[n2] = t4[n2];
    for (n2 in e2)
      r2[n2] = e2[n2];
    return r2;
  }(this._options, t3), this;
}, start: function() {
  var e2 = this;
  return r(t().mark(function n2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, ki.call(e2, e2._targetElement);
          case 2:
            return t3.abrupt("return", e2);
          case 3:
          case "end":
            return t3.stop();
        }
    }, n2);
  }))();
}, goToStep: function(e2) {
  var n2 = this;
  return r(t().mark(function r2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, Hr.call(n2, e2);
          case 2:
            return t3.abrupt("return", n2);
          case 3:
          case "end":
            return t3.stop();
        }
    }, r2);
  }))();
}, addStep: function(t3) {
  return this._options.steps || (this._options.steps = []), this._options.steps.push(t3), this;
}, addSteps: function(t3) {
  if (t3.length) {
    for (var e2 = 0; e2 < t3.length; e2++)
      this.addStep(t3[e2]);
    return this;
  }
}, goToStepNumber: function(e2) {
  var n2 = this;
  return r(t().mark(function r2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, Dr.call(n2, e2);
          case 2:
            return t3.abrupt("return", n2);
          case 3:
          case "end":
            return t3.stop();
        }
    }, r2);
  }))();
}, nextStep: function() {
  var e2 = this;
  return r(t().mark(function n2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, zr.call(e2);
          case 2:
            return t3.abrupt("return", e2);
          case 3:
          case "end":
            return t3.stop();
        }
    }, n2);
  }))();
}, previousStep: function() {
  var e2 = this;
  return r(t().mark(function n2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, Wr.call(e2);
          case 2:
            return t3.abrupt("return", e2);
          case 3:
          case "end":
            return t3.stop();
        }
    }, n2);
  }))();
}, currentStep: function() {
  return Ur.call(this);
}, exit: function(e2) {
  var n2 = this;
  return r(t().mark(function r2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, wi.call(n2, n2._targetElement, e2);
          case 2:
            return t3.abrupt("return", n2);
          case 3:
          case "end":
            return t3.stop();
        }
    }, r2);
  }))();
}, refresh: function(t3) {
  return vi.call(this, t3), this;
}, setDontShowAgain: function(t3) {
  return Ai.call(this, t3), this;
}, onbeforechange: function(t3) {
  if ("function" != typeof t3)
    throw new Error("Provided callback for onbeforechange was not a function");
  return this._introBeforeChangeCallback = t3, this;
}, onchange: function(t3) {
  if ("function" != typeof t3)
    throw new Error("Provided callback for onchange was not a function.");
  return this._introChangeCallback = t3, this;
}, onafterchange: function(t3) {
  if ("function" != typeof t3)
    throw new Error("Provided callback for onafterchange was not a function");
  return this._introAfterChangeCallback = t3, this;
}, oncomplete: function(t3) {
  if ("function" != typeof t3)
    throw new Error("Provided callback for oncomplete was not a function.");
  return this._introCompleteCallback = t3, this;
}, onhintsadded: function(t3) {
  if ("function" != typeof t3)
    throw new Error("Provided callback for onhintsadded was not a function.");
  return this._hintsAddedCallback = t3, this;
}, onhintclick: function(t3) {
  if ("function" != typeof t3)
    throw new Error("Provided callback for onhintclick was not a function.");
  return this._hintClickCallback = t3, this;
}, onhintclose: function(t3) {
  if ("function" != typeof t3)
    throw new Error("Provided callback for onhintclose was not a function.");
  return this._hintCloseCallback = t3, this;
}, onstart: function(t3) {
  if ("function" != typeof t3)
    throw new Error("Provided callback for onstart was not a function.");
  return this._introStartCallback = t3, this;
}, onexit: function(t3) {
  if ("function" != typeof t3)
    throw new Error("Provided callback for onexit was not a function.");
  return this._introExitCallback = t3, this;
}, onskip: function(t3) {
  if ("function" != typeof t3)
    throw new Error("Provided callback for onskip was not a function.");
  return this._introSkipCallback = t3, this;
}, onbeforeexit: function(t3) {
  if ("function" != typeof t3)
    throw new Error("Provided callback for onbeforeexit was not a function.");
  return this._introBeforeExitCallback = t3, this;
}, addHints: function() {
  var e2 = this;
  return r(t().mark(function n2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, fi.call(e2, e2._targetElement);
          case 2:
            return t3.abrupt("return", e2);
          case 3:
          case "end":
            return t3.stop();
        }
    }, n2);
  }))();
}, hideHint: function(e2) {
  var n2 = this;
  return r(t().mark(function r2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, Jr.call(n2, e2);
          case 2:
            return t3.abrupt("return", n2);
          case 3:
          case "end":
            return t3.stop();
        }
    }, r2);
  }))();
}, hideHints: function() {
  var e2 = this;
  return r(t().mark(function n2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, ei.call(e2);
          case 2:
            return t3.abrupt("return", e2);
          case 3:
          case "end":
            return t3.stop();
        }
    }, n2);
  }))();
}, showHint: function(t3) {
  return ii.call(this, t3), this;
}, showHints: function() {
  var e2 = this;
  return r(t().mark(function n2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, ni.call(e2);
          case 2:
            return t3.abrupt("return", e2);
          case 3:
          case "end":
            return t3.stop();
        }
    }, n2);
  }))();
}, removeHints: function() {
  return oi.call(this), this;
}, removeHint: function(t3) {
  return ai().call(this, t3), this;
}, showHintDialog: function(e2) {
  var n2 = this;
  return r(t().mark(function r2() {
    return t().wrap(function(t3) {
      for (; ; )
        switch (t3.prev = t3.next) {
          case 0:
            return t3.next = 2, ui.call(n2, e2);
          case 2:
            return t3.abrupt("return", n2);
          case 3:
          case "end":
            return t3.stop();
        }
    }, r2);
  }))();
} };
const _imports_0 = "/assets/images/favicon-32x32.png";
const Options_vue_vue_type_style_index_0_lang = "";
const Options_vue_vue_type_style_index_1_scoped_cbdadd5d_lang = "";
async function useAsyncSetup(config, loadingError) {
  const { storedConfig, hasErrors } = await getOrInitConfig();
  config.value = storedConfig;
  loadingError.value = hasErrors;
  if (!hasErrors && storedConfig.envs.length === 0 && storedConfig.projects.length === 0) {
    setTimeout(() => {
      Ii().start();
    }, 0);
  }
}
async function getOrInitConfig() {
  const { config, errors } = await getFixConfig({
    mergeOptions: false,
    mergeDefault: false
  });
  return {
    hasErrors: errors && (errors.migrationFailed || errors.validationFailed),
    storedConfig: config
  };
}
function useSaveConfig({ config, errorMessage, displaySaveInfo }) {
  return async (savingConfig) => {
    if (!savingConfig) {
      return;
    }
    config.value = savingConfig;
    errorMessage.value = null;
    if (!await setConfig$1(savingConfig)) {
      displaySaveInfo.value = false;
      errorMessage.value = "Save Failed";
      return;
    }
    displaySaveInfo.value = true;
    setTimeout(() => {
      displaySaveInfo.value = false;
    }, 3e3);
  };
}
function useUpdateConfigOptions({ saveConfig, config }) {
  return (options) => {
    saveConfig({
      ...config.value,
      options: {
        ...config.value.options,
        ...options
      }
    });
  };
}
function isConfigDarkMode(config) {
  return config.value && config.value.options ? isDarkMode(config.value.options.colorScheme) : false;
}
function updateBodyClassListDarkMode(darkMode) {
  const classList = window.document.body.classList;
  if (darkMode) {
    classList.add("dark-mode");
    classList.remove("light-mode");
  } else {
    classList.add("light-mode");
    classList.remove("dark-mode");
  }
}
function useDarkMode(config) {
  const darkMode = computed(() => isConfigDarkMode(config));
  watch(darkMode, (value) => updateBodyClassListDarkMode(value));
  return darkMode;
}
const _sfc_main$9 = defineComponent({
  name: "OptionsPage",
  components: {
    EditorFormConfig,
    ImportConfig
  },
  setup() {
    const config = ref(null);
    const loadingError = ref(false);
    const errorMessage = ref(null);
    const displaySaveInfo = ref(false);
    useAsyncSetup(config, loadingError);
    const darkMode = useDarkMode(config);
    const saveConfig = useSaveConfig({ config, errorMessage, displaySaveInfo });
    const updateConfigOptions = useUpdateConfigOptions({ config, saveConfig });
    return {
      displaySaveInfo,
      errorMessage,
      config,
      loadingError,
      darkMode,
      downloadAsJson: () => downloadAsJson(config.value),
      saveConfig,
      updateConfigOptions
    };
  }
});
const _withScopeId = (n2) => (pushScopeId("data-v-cbdadd5d"), n2 = n2(), popScopeId(), n2);
const _hoisted_1$9 = {
  key: 0,
  class: "options"
};
const _hoisted_2$9 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("h1", { "data-intro": "Hello, this is Yaes Configuration page. Nobody like a tutorial, so let's get it over with." }, [
  /* @__PURE__ */ createBaseVNode("img", { src: _imports_0 }),
  /* @__PURE__ */ createTextVNode(" YAES - Configuration Page ")
], -1));
const _hoisted_3$9 = { class: "title" };
const _hoisted_4$1 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("h2", null, [
  /* @__PURE__ */ createBaseVNode("span", null, " Environments ")
], -1));
const _hoisted_5 = { key: 0 };
const _hoisted_6 = {
  key: 0,
  class: "info"
};
const _hoisted_7 = {
  key: 0,
  class: "info error"
};
const _hoisted_8 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("h2", null, "Import / Export", -1));
function _sfc_render$9(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_CheckIcon = resolveComponent("CheckIcon");
  const _component_DeleteIcon = resolveComponent("DeleteIcon");
  const _component_EditorFormConfig = resolveComponent("EditorFormConfig");
  const _component_ImportConfig = resolveComponent("ImportConfig");
  return _ctx.config ? (openBlock(), createElementBlock("div", _hoisted_1$9, [
    createBaseVNode("section", null, [
      _hoisted_2$9,
      createBaseVNode("div", _hoisted_3$9, [
        _hoisted_4$1,
        _ctx.loadingError ? (openBlock(), createElementBlock("div", _hoisted_5, " Oh oh it seems we had a little issue getting your configuration in a proper state. ")) : createCommentVNode("", true),
        createBaseVNode("div", null, [
          createVNode(Transition, { name: "fade" }, {
            default: withCtx(() => [
              _ctx.displaySaveInfo ? (openBlock(), createElementBlock("span", _hoisted_6, [
                createTextVNode(" Saved "),
                createVNode(_component_CheckIcon, {
                  width: "16px",
                  height: "12px"
                })
              ])) : createCommentVNode("", true)
            ]),
            _: 1
          }),
          createVNode(Transition, { name: "fade" }, {
            default: withCtx(() => [
              _ctx.errorMessage ? (openBlock(), createElementBlock("span", _hoisted_7, [
                createTextVNode(toDisplayString(_ctx.errorMessage) + " ", 1),
                createVNode(_component_DeleteIcon, {
                  width: "16px",
                  height: "12px"
                })
              ])) : createCommentVNode("", true)
            ]),
            _: 1
          })
        ])
      ]),
      createVNode(_component_EditorFormConfig, {
        config: _ctx.config,
        "onUpdate:config": _ctx.saveConfig
      }, null, 8, ["config", "onUpdate:config"]),
      _hoisted_8,
      createVNode(_component_ImportConfig, {
        options: _ctx.config.options,
        config: _ctx.config,
        "onUpdate:options": _ctx.updateConfigOptions,
        onConfigLoaded: _ctx.saveConfig,
        onDownloadConfig: _ctx.downloadAsJson
      }, null, 8, ["options", "config", "onUpdate:options", "onConfigLoaded", "onDownloadConfig"])
    ])
  ])) : createCommentVNode("", true);
}
const Options = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["render", _sfc_render$9], ["__scopeId", "data-v-cbdadd5d"]]);
const uniqueId = {
  install: (app) => {
    let uuid = 0;
    app.mixin({
      beforeCreate: function() {
        this.uuid = uuid.toString();
        uuid += 1;
      }
    });
    app.config.globalProperties.$id = function(id) {
      return "uid-" + this.uuid + "-" + id;
    };
  }
};
const _sfc_main$8 = {};
const _hoisted_1$8 = {
  class: "svg-icon",
  viewBox: "0 0 20 20"
};
const _hoisted_2$8 = /* @__PURE__ */ createBaseVNode("path", { d: "M13.388,9.624h-3.011v-3.01c0-0.208-0.168-0.377-0.376-0.377S9.624,6.405,9.624,6.613v3.01H6.613c-0.208,0-0.376,0.168-0.376,0.376s0.168,0.376,0.376,0.376h3.011v3.01c0,0.208,0.168,0.378,0.376,0.378s0.376-0.17,0.376-0.378v-3.01h3.011c0.207,0,0.377-0.168,0.377-0.376S13.595,9.624,13.388,9.624z M10,1.344c-4.781,0-8.656,3.875-8.656,8.656c0,4.781,3.875,8.656,8.656,8.656c4.781,0,8.656-3.875,8.656-8.656C18.656,5.219,14.781,1.344,10,1.344z M10,17.903c-4.365,0-7.904-3.538-7.904-7.903S5.635,2.096,10,2.096S17.903,5.635,17.903,10S14.365,17.903,10,17.903z" }, null, -1);
const _hoisted_3$8 = [
  _hoisted_2$8
];
function _sfc_render$8(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$8, _hoisted_3$8);
}
const AddIcon = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$8]]);
const _sfc_main$7 = {};
const _hoisted_1$7 = {
  class: "svg-icon",
  viewBox: "0 0 20 20"
};
const _hoisted_2$7 = /* @__PURE__ */ createBaseVNode("path", { d: "M7.629,14.566c0.125,0.125,0.291,0.188,0.456,0.188c0.164,0,0.329-0.062,0.456-0.188l8.219-8.221c0.252-0.252,0.252-0.659,0-0.911c-0.252-0.252-0.659-0.252-0.911,0l-7.764,7.763L4.152,9.267c-0.252-0.251-0.66-0.251-0.911,0c-0.252,0.252-0.252,0.66,0,0.911L7.629,14.566z" }, null, -1);
const _hoisted_3$7 = [
  _hoisted_2$7
];
function _sfc_render$7(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$7, _hoisted_3$7);
}
const CheckIcon = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$7]]);
const _sfc_main$6 = {};
const _hoisted_1$6 = {
  class: "svg-icon",
  viewBox: "0 0 20 20"
};
const _hoisted_2$6 = /* @__PURE__ */ createBaseVNode("path", { d: "M18.783,13.198H15.73c-0.431,0-0.78-0.35-0.78-0.779c0-0.433,0.349-0.78,0.78-0.78h2.273V3.652H7.852v0.922\n							c0,0.433-0.349,0.78-0.78,0.78c-0.431,0-0.78-0.347-0.78-0.78V2.872c0-0.43,0.349-0.78,0.78-0.78h11.711\n							c0.431,0,0.78,0.35,0.78,0.78v9.546C19.562,12.848,19.214,13.198,18.783,13.198z" }, null, -1);
const _hoisted_3$6 = /* @__PURE__ */ createBaseVNode("path", { d: "M12.927,17.908H1.217c-0.431,0-0.78-0.351-0.78-0.78V7.581c0-0.43,0.349-0.78,0.78-0.78h11.709\n							c0.431,0,0.78,0.35,0.78,0.78v9.546C13.706,17.557,13.357,17.908,12.927,17.908z M1.997,16.348h10.15V8.361H1.997V16.348z" }, null, -1);
const _hoisted_4 = [
  _hoisted_2$6,
  _hoisted_3$6
];
function _sfc_render$6(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$6, _hoisted_4);
}
const CloneIcon = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$6]]);
const _sfc_main$5 = {};
const _hoisted_1$5 = {
  class: "svg-icon",
  viewBox: "0 0 20 20"
};
const _hoisted_2$5 = /* @__PURE__ */ createBaseVNode("path", { d: "M2.25,12.584c-0.713,0-1.292,0.578-1.292,1.291s0.579,1.291,1.292,1.291c0.713,0,1.292-0.578,1.292-1.291S2.963,12.584,2.25,12.584z M2.25,14.307c-0.238,0-0.43-0.193-0.43-0.432s0.192-0.432,0.43-0.432c0.238,0,0.431,0.193,0.431,0.432S2.488,14.307,2.25,14.307z M5.694,6.555H18.61c0.237,0,0.431-0.191,0.431-0.43s-0.193-0.431-0.431-0.431H5.694c-0.238,0-0.43,0.192-0.43,0.431S5.457,6.555,5.694,6.555z M2.25,8.708c-0.713,0-1.292,0.578-1.292,1.291c0,0.715,0.579,1.292,1.292,1.292c0.713,0,1.292-0.577,1.292-1.292C3.542,9.287,2.963,8.708,2.25,8.708z M2.25,10.43c-0.238,0-0.43-0.192-0.43-0.431c0-0.237,0.192-0.43,0.43-0.43c0.238,0,0.431,0.192,0.431,0.43C2.681,10.238,2.488,10.43,2.25,10.43z M18.61,9.57H5.694c-0.238,0-0.43,0.192-0.43,0.43c0,0.238,0.192,0.431,0.43,0.431H18.61c0.237,0,0.431-0.192,0.431-0.431C19.041,9.762,18.848,9.57,18.61,9.57z M18.61,13.443H5.694c-0.238,0-0.43,0.193-0.43,0.432s0.192,0.432,0.43,0.432H18.61c0.237,0,0.431-0.193,0.431-0.432S18.848,13.443,18.61,13.443z M2.25,4.833c-0.713,0-1.292,0.578-1.292,1.292c0,0.713,0.579,1.291,1.292,1.291c0.713,0,1.292-0.578,1.292-1.291C3.542,5.412,2.963,4.833,2.25,4.833z M2.25,6.555c-0.238,0-0.43-0.191-0.43-0.43s0.192-0.431,0.43-0.431c0.238,0,0.431,0.192,0.431,0.431S2.488,6.555,2.25,6.555z" }, null, -1);
const _hoisted_3$5 = [
  _hoisted_2$5
];
function _sfc_render$5(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$5, _hoisted_3$5);
}
const DragListIcon = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$5]]);
const _sfc_main$4 = {};
const _hoisted_1$4 = {
  class: "svg-icon",
  viewBox: "0 0 20 20"
};
const _hoisted_2$4 = /* @__PURE__ */ createBaseVNode("path", { d: "M12.71,7.291c-0.15-0.15-0.393-0.15-0.542,0L10,9.458L7.833,7.291c-0.15-0.15-0.392-0.15-0.542,0c-0.149,0.149-0.149,0.392,0,0.541L9.458,10l-2.168,2.167c-0.149,0.15-0.149,0.393,0,0.542c0.15,0.149,0.392,0.149,0.542,0L10,10.542l2.168,2.167c0.149,0.149,0.392,0.149,0.542,0c0.148-0.149,0.148-0.392,0-0.542L10.542,10l2.168-2.168C12.858,7.683,12.858,7.44,12.71,7.291z M10,1.188c-4.867,0-8.812,3.946-8.812,8.812c0,4.867,3.945,8.812,8.812,8.812s8.812-3.945,8.812-8.812C18.812,5.133,14.867,1.188,10,1.188z M10,18.046c-4.444,0-8.046-3.603-8.046-8.046c0-4.444,3.603-8.046,8.046-8.046c4.443,0,8.046,3.602,8.046,8.046C18.046,14.443,14.443,18.046,10,18.046z" }, null, -1);
const _hoisted_3$4 = [
  _hoisted_2$4
];
function _sfc_render$4(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$4, _hoisted_3$4);
}
const DeleteIcon = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$4]]);
const _sfc_main$3 = {};
const _hoisted_1$3 = {
  class: "svg-icon",
  viewBox: "0 0 20 20"
};
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("path", { d: "M18.303,4.742l-1.454-1.455c-0.171-0.171-0.475-0.171-0.646,0l-3.061,3.064H2.019c-0.251,0-0.457,0.205-0.457,0.456v9.578c0,0.251,0.206,0.456,0.457,0.456h13.683c0.252,0,0.457-0.205,0.457-0.456V7.533l2.144-2.146C18.481,5.208,18.483,4.917,18.303,4.742 M15.258,15.929H2.476V7.263h9.754L9.695,9.792c-0.057,0.057-0.101,0.13-0.119,0.212L9.18,11.36h-3.98c-0.251,0-0.457,0.205-0.457,0.456c0,0.253,0.205,0.456,0.457,0.456h4.336c0.023,0,0.899,0.02,1.498-0.127c0.312-0.077,0.55-0.137,0.55-0.137c0.08-0.018,0.155-0.059,0.212-0.118l3.463-3.443V15.929z M11.241,11.156l-1.078,0.267l0.267-1.076l6.097-6.091l0.808,0.808L11.241,11.156z" }, null, -1);
const _hoisted_3$3 = [
  _hoisted_2$3
];
function _sfc_render$3(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$3, _hoisted_3$3);
}
const EditTextIcon = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$3]]);
const _sfc_main$2 = {};
const _hoisted_1$2 = {
  class: "svg-icon",
  viewBox: "0 0 20 20"
};
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("path", { d: "M8.416,3.943l1.12-1.12v9.031c0,0.257,0.208,0.464,0.464,0.464c0.256,0,0.464-0.207,0.464-0.464V2.823l1.12,1.12c0.182,0.182,0.476,0.182,0.656,0c0.182-0.181,0.182-0.475,0-0.656l-1.744-1.745c-0.018-0.081-0.048-0.16-0.112-0.224C10.279,1.214,10.137,1.177,10,1.194c-0.137-0.017-0.279,0.02-0.384,0.125C9.551,1.384,9.518,1.465,9.499,1.548L7.76,3.288c-0.182,0.181-0.182,0.475,0,0.656C7.941,4.125,8.234,4.125,8.416,3.943z M15.569,6.286h-2.32v0.928h2.32c0.512,0,0.928,0.416,0.928,0.928v8.817c0,0.513-0.416,0.929-0.928,0.929H4.432c-0.513,0-0.928-0.416-0.928-0.929V8.142c0-0.513,0.416-0.928,0.928-0.928h2.32V6.286h-2.32c-1.025,0-1.856,0.831-1.856,1.856v8.817c0,1.025,0.832,1.856,1.856,1.856h11.138c1.024,0,1.855-0.831,1.855-1.856V8.142C17.425,7.117,16.594,6.286,15.569,6.286z" }, null, -1);
const _hoisted_3$2 = [
  _hoisted_2$2
];
function _sfc_render$2(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$2, _hoisted_3$2);
}
const ExportIcon = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$2]]);
const _sfc_main$1 = {};
const _hoisted_1$1 = { viewBox: "0 0 20 20" };
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("path", { d: "M3.24,7.51c-0.146,0.142-0.146,0.381,0,0.523l5.199,5.193c0.234,0.238,0.633,0.064,0.633-0.262v-2.634c0.105-0.007,0.212-0.011,0.321-0.011c2.373,0,4.302,1.91,4.302,4.258c0,0.957-0.33,1.809-1.008,2.602c-0.259,0.307,0.084,0.762,0.451,0.572c2.336-1.195,3.73-3.408,3.73-5.924c0-3.741-3.103-6.783-6.916-6.783c-0.307,0-0.615,0.028-0.881,0.063V2.575c0-0.327-0.398-0.5-0.633-0.261L3.24,7.51 M4.027,7.771l4.301-4.3v2.073c0,0.232,0.21,0.409,0.441,0.366c0.298-0.056,0.746-0.123,1.184-0.123c3.402,0,6.172,2.709,6.172,6.041c0,1.695-0.718,3.24-1.979,4.352c0.193-0.51,0.293-1.045,0.293-1.602c0-2.76-2.266-5-5.046-5c-0.256,0-0.528,0.018-0.747,0.05C8.465,9.653,8.328,9.81,8.328,9.995v2.074L4.027,7.771z" }, null, -1);
const _hoisted_3$1 = [
  _hoisted_2$1
];
function _sfc_render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$1, _hoisted_3$1);
}
const GoBackIcon = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const _sfc_main = {};
const _hoisted_1 = {
  class: "svg-icon",
  viewBox: "0 0 20 20"
};
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("path", { d: "M15.608,6.262h-2.338v0.935h2.338c0.516,0,0.934,0.418,0.934,0.935v8.879c0,0.517-0.418,0.935-0.934,0.935H4.392c-0.516,0-0.935-0.418-0.935-0.935V8.131c0-0.516,0.419-0.935,0.935-0.935h2.336V6.262H4.392c-1.032,0-1.869,0.837-1.869,1.869v8.879c0,1.031,0.837,1.869,1.869,1.869h11.216c1.031,0,1.869-0.838,1.869-1.869V8.131C17.478,7.099,16.64,6.262,15.608,6.262z M9.513,11.973c0.017,0.082,0.047,0.162,0.109,0.226c0.104,0.106,0.243,0.143,0.378,0.126c0.135,0.017,0.274-0.02,0.377-0.126c0.064-0.065,0.097-0.147,0.115-0.231l1.708-1.751c0.178-0.183,0.178-0.479,0-0.662c-0.178-0.182-0.467-0.182-0.645,0l-1.101,1.129V1.588c0-0.258-0.204-0.467-0.456-0.467c-0.252,0-0.456,0.209-0.456,0.467v9.094L8.443,9.553c-0.178-0.182-0.467-0.182-0.645,0c-0.178,0.184-0.178,0.479,0,0.662L9.513,11.973z" }, null, -1);
const _hoisted_3 = [
  _hoisted_2
];
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, _hoisted_3);
}
const ImportIcon = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const all = {
  AddIcon,
  ArrowRightIcon,
  CheckIcon,
  CloneIcon,
  DragListIcon,
  DeleteIcon,
  EditTextIcon,
  ExportIcon,
  GoBackIcon,
  ImportIcon
};
const GlobalIcons = {
  install: (app) => {
    Object.entries(all).forEach(([name, component]) => {
      app.component(
        name,
        // Look for the component options on `.default`, which will
        // exist if the component was exported with `export default`,
        // otherwise fall back to module's root.
        component.default || component
      );
    });
  }
};
/**
  * vee-validate v4.7.4
  * (c) 2023 Abdelrahman Awad
  * @license MIT
  */
function isNullOrUndefined(value) {
  return value === null || value === void 0;
}
function isEmptyArray(arr) {
  return Array.isArray(arr) && arr.length === 0;
}
const requiredValidator = (value) => {
  if (isNullOrUndefined(value) || isEmptyArray(value) || value === false) {
    return false;
  }
  return !!String(value).trim().length;
};
defineRule("required", requiredValidator);
defineRule("url", (value) => {
  const urlRegex = /^(?:(?:https?|ftp):\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i;
  if (!urlRegex.test(value)) {
    return "This field must be a valid url";
  }
  return true;
});
defineRule("urlParams", (value) => {
  if (!value || !value.length) {
    return true;
  }
  const urlRegex = /^([^=&]+=[^=&]+)(&[^=&]+=[^=&]+)*$/;
  if (!urlRegex.test(value)) {
    return "This field must be a valid url params";
  }
  return true;
});
defineRule("list", (value) => {
  if (!value || !value.length) {
    return true;
  }
  const urlRegex = /^[^,]+(,[^,]+)*$/;
  if (!urlRegex.test(value)) {
    return "This field must be a list format";
  }
  return true;
});
configure({
  validateOnBlur: true,
  // controls if `blur` events should trigger validation with `handleChange` handler
  validateOnChange: true,
  // controls if `change` events should trigger validation with `handleChange` handler
  validateOnInput: true,
  // controls if `input` events should trigger validation with `handleChange` handler
  validateOnModelUpdate: true
  // controls if `update:modelValue` events should trigger validation with `handleChange` handler
});
const introjs_min = "";
async function main() {
  if (!window.Cypress) {
    loadSentry();
  }
  const app = createApp(Options);
  const startApp = () => {
    app.use(GlobalIcons);
    app.use(uniqueId);
    app.mount("#app");
  };
  queueVueGlobalErrorHandler(app);
  if (window.Cypress) {
    window.startApp = startApp;
  } else {
    startApp();
  }
}
main();
//# sourceMappingURL=options.html-4edf64df.js.map
