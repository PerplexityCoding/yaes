function getCurrentTab() {
  return new Promise((success) => {
    chrome.tabs.query({ currentWindow: true, active: true }, (tabs) => {
      success(tabs[0]);
    });
  });
}
function getTab(tabId) {
  return new Promise((success) => {
    chrome.tabs.get(tabId, (tab) => {
      success(tab);
    });
  });
}
function openChromeUrl(tab, url, inNewTab) {
  if (inNewTab) {
    chrome.tabs.create({
      url,
      active: false
    });
  } else {
    chrome.tabs.update(tab.id, { url });
    window.close();
  }
}
function openOptionsPage() {
  chrome.tabs.create({ url: "/src/options.html" });
}
export {
  openChromeUrl as a,
  getCurrentTab as b,
  getTab as g,
  openOptionsPage as o
};
//# sourceMappingURL=tabs-05aa9e80.js.map
