import { c as cjs, s as storageGet, g as getAndAssembleConfig, a as storageSet, b as storageRemove, I as INIT_DEFAULT_CONFIG, m as mergeOptionsDefault, d as mergeOptionsInEnv } from "./utils-d4ff6b88.js";
import { u as uuidv4, b as updateArray, a as removeUndefined } from "./utils-7f9e60bc.js";
var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
function getDefaultExportFromCjs(x) {
  return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
}
var url = {};
var punycodeExports = {};
var punycode$1 = {
  get exports() {
    return punycodeExports;
  },
  set exports(v) {
    punycodeExports = v;
  }
};
/*! https://mths.be/punycode v1.3.2 by @mathias */
(function(module, exports) {
  (function(root) {
    var freeExports = exports && !exports.nodeType && exports;
    var freeModule = module && !module.nodeType && module;
    var freeGlobal = typeof commonjsGlobal == "object" && commonjsGlobal;
    if (freeGlobal.global === freeGlobal || freeGlobal.window === freeGlobal || freeGlobal.self === freeGlobal) {
      root = freeGlobal;
    }
    var punycode2, maxInt = 2147483647, base = 36, tMin = 1, tMax = 26, skew = 38, damp = 700, initialBias = 72, initialN = 128, delimiter = "-", regexPunycode = /^xn--/, regexNonASCII = /[^\x20-\x7E]/, regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g, errors = {
      "overflow": "Overflow: input needs wider integers to process",
      "not-basic": "Illegal input >= 0x80 (not a basic code point)",
      "invalid-input": "Invalid input"
    }, baseMinusTMin = base - tMin, floor = Math.floor, stringFromCharCode = String.fromCharCode, key;
    function error(type) {
      throw RangeError(errors[type]);
    }
    function map(array, fn) {
      var length = array.length;
      var result = [];
      while (length--) {
        result[length] = fn(array[length]);
      }
      return result;
    }
    function mapDomain(string, fn) {
      var parts = string.split("@");
      var result = "";
      if (parts.length > 1) {
        result = parts[0] + "@";
        string = parts[1];
      }
      string = string.replace(regexSeparators, ".");
      var labels = string.split(".");
      var encoded = map(labels, fn).join(".");
      return result + encoded;
    }
    function ucs2decode(string) {
      var output = [], counter = 0, length = string.length, value, extra;
      while (counter < length) {
        value = string.charCodeAt(counter++);
        if (value >= 55296 && value <= 56319 && counter < length) {
          extra = string.charCodeAt(counter++);
          if ((extra & 64512) == 56320) {
            output.push(((value & 1023) << 10) + (extra & 1023) + 65536);
          } else {
            output.push(value);
            counter--;
          }
        } else {
          output.push(value);
        }
      }
      return output;
    }
    function ucs2encode(array) {
      return map(array, function(value) {
        var output = "";
        if (value > 65535) {
          value -= 65536;
          output += stringFromCharCode(value >>> 10 & 1023 | 55296);
          value = 56320 | value & 1023;
        }
        output += stringFromCharCode(value);
        return output;
      }).join("");
    }
    function basicToDigit(codePoint) {
      if (codePoint - 48 < 10) {
        return codePoint - 22;
      }
      if (codePoint - 65 < 26) {
        return codePoint - 65;
      }
      if (codePoint - 97 < 26) {
        return codePoint - 97;
      }
      return base;
    }
    function digitToBasic(digit, flag) {
      return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
    }
    function adapt(delta, numPoints, firstTime) {
      var k = 0;
      delta = firstTime ? floor(delta / damp) : delta >> 1;
      delta += floor(delta / numPoints);
      for (; delta > baseMinusTMin * tMax >> 1; k += base) {
        delta = floor(delta / baseMinusTMin);
      }
      return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
    }
    function decode2(input) {
      var output = [], inputLength = input.length, out, i = 0, n = initialN, bias = initialBias, basic, j, index, oldi, w, k, digit, t, baseMinusT;
      basic = input.lastIndexOf(delimiter);
      if (basic < 0) {
        basic = 0;
      }
      for (j = 0; j < basic; ++j) {
        if (input.charCodeAt(j) >= 128) {
          error("not-basic");
        }
        output.push(input.charCodeAt(j));
      }
      for (index = basic > 0 ? basic + 1 : 0; index < inputLength; ) {
        for (oldi = i, w = 1, k = base; ; k += base) {
          if (index >= inputLength) {
            error("invalid-input");
          }
          digit = basicToDigit(input.charCodeAt(index++));
          if (digit >= base || digit > floor((maxInt - i) / w)) {
            error("overflow");
          }
          i += digit * w;
          t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
          if (digit < t) {
            break;
          }
          baseMinusT = base - t;
          if (w > floor(maxInt / baseMinusT)) {
            error("overflow");
          }
          w *= baseMinusT;
        }
        out = output.length + 1;
        bias = adapt(i - oldi, out, oldi == 0);
        if (floor(i / out) > maxInt - n) {
          error("overflow");
        }
        n += floor(i / out);
        i %= out;
        output.splice(i++, 0, n);
      }
      return ucs2encode(output);
    }
    function encode2(input) {
      var n, delta, handledCPCount, basicLength, bias, j, m, q, k, t, currentValue, output = [], inputLength, handledCPCountPlusOne, baseMinusT, qMinusT;
      input = ucs2decode(input);
      inputLength = input.length;
      n = initialN;
      delta = 0;
      bias = initialBias;
      for (j = 0; j < inputLength; ++j) {
        currentValue = input[j];
        if (currentValue < 128) {
          output.push(stringFromCharCode(currentValue));
        }
      }
      handledCPCount = basicLength = output.length;
      if (basicLength) {
        output.push(delimiter);
      }
      while (handledCPCount < inputLength) {
        for (m = maxInt, j = 0; j < inputLength; ++j) {
          currentValue = input[j];
          if (currentValue >= n && currentValue < m) {
            m = currentValue;
          }
        }
        handledCPCountPlusOne = handledCPCount + 1;
        if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
          error("overflow");
        }
        delta += (m - n) * handledCPCountPlusOne;
        n = m;
        for (j = 0; j < inputLength; ++j) {
          currentValue = input[j];
          if (currentValue < n && ++delta > maxInt) {
            error("overflow");
          }
          if (currentValue == n) {
            for (q = delta, k = base; ; k += base) {
              t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
              if (q < t) {
                break;
              }
              qMinusT = q - t;
              baseMinusT = base - t;
              output.push(
                stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0))
              );
              q = floor(qMinusT / baseMinusT);
            }
            output.push(stringFromCharCode(digitToBasic(q, 0)));
            bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
            delta = 0;
            ++handledCPCount;
          }
        }
        ++delta;
        ++n;
      }
      return output.join("");
    }
    function toUnicode(input) {
      return mapDomain(input, function(string) {
        return regexPunycode.test(string) ? decode2(string.slice(4).toLowerCase()) : string;
      });
    }
    function toASCII(input) {
      return mapDomain(input, function(string) {
        return regexNonASCII.test(string) ? "xn--" + encode2(string) : string;
      });
    }
    punycode2 = {
      /**
       * A string representing the current Punycode.js version number.
       * @memberOf punycode
       * @type String
       */
      "version": "1.3.2",
      /**
       * An object of methods to convert from JavaScript's internal character
       * representation (UCS-2) to Unicode code points, and back.
       * @see <https://mathiasbynens.be/notes/javascript-encoding>
       * @memberOf punycode
       * @type Object
       */
      "ucs2": {
        "decode": ucs2decode,
        "encode": ucs2encode
      },
      "decode": decode2,
      "encode": encode2,
      "toASCII": toASCII,
      "toUnicode": toUnicode
    };
    if (freeExports && freeModule) {
      if (module.exports == freeExports) {
        freeModule.exports = punycode2;
      } else {
        for (key in punycode2) {
          punycode2.hasOwnProperty(key) && (freeExports[key] = punycode2[key]);
        }
      }
    } else {
      root.punycode = punycode2;
    }
  })(commonjsGlobal);
})(punycode$1, punycodeExports);
var util$1 = {
  isString: function(arg) {
    return typeof arg === "string";
  },
  isObject: function(arg) {
    return typeof arg === "object" && arg !== null;
  },
  isNull: function(arg) {
    return arg === null;
  },
  isNullOrUndefined: function(arg) {
    return arg == null;
  }
};
var querystring$1 = {};
function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}
var decode = function(qs, sep, eq, options) {
  sep = sep || "&";
  eq = eq || "=";
  var obj = {};
  if (typeof qs !== "string" || qs.length === 0) {
    return obj;
  }
  var regexp = /\+/g;
  qs = qs.split(sep);
  var maxKeys = 1e3;
  if (options && typeof options.maxKeys === "number") {
    maxKeys = options.maxKeys;
  }
  var len = qs.length;
  if (maxKeys > 0 && len > maxKeys) {
    len = maxKeys;
  }
  for (var i = 0; i < len; ++i) {
    var x = qs[i].replace(regexp, "%20"), idx = x.indexOf(eq), kstr, vstr, k, v;
    if (idx >= 0) {
      kstr = x.substr(0, idx);
      vstr = x.substr(idx + 1);
    } else {
      kstr = x;
      vstr = "";
    }
    k = decodeURIComponent(kstr);
    v = decodeURIComponent(vstr);
    if (!hasOwnProperty(obj, k)) {
      obj[k] = v;
    } else if (Array.isArray(obj[k])) {
      obj[k].push(v);
    } else {
      obj[k] = [obj[k], v];
    }
  }
  return obj;
};
var stringifyPrimitive = function(v) {
  switch (typeof v) {
    case "string":
      return v;
    case "boolean":
      return v ? "true" : "false";
    case "number":
      return isFinite(v) ? v : "";
    default:
      return "";
  }
};
var encode = function(obj, sep, eq, name) {
  sep = sep || "&";
  eq = eq || "=";
  if (obj === null) {
    obj = void 0;
  }
  if (typeof obj === "object") {
    return Object.keys(obj).map(function(k) {
      var ks = encodeURIComponent(stringifyPrimitive(k)) + eq;
      if (Array.isArray(obj[k])) {
        return obj[k].map(function(v) {
          return ks + encodeURIComponent(stringifyPrimitive(v));
        }).join(sep);
      } else {
        return ks + encodeURIComponent(stringifyPrimitive(obj[k]));
      }
    }).join(sep);
  }
  if (!name)
    return "";
  return encodeURIComponent(stringifyPrimitive(name)) + eq + encodeURIComponent(stringifyPrimitive(obj));
};
querystring$1.decode = querystring$1.parse = decode;
querystring$1.encode = querystring$1.stringify = encode;
var punycode = punycodeExports;
var util = util$1;
url.parse = urlParse;
url.resolve = urlResolve;
url.resolveObject = urlResolveObject;
url.format = urlFormat;
url.Url = Url;
function Url() {
  this.protocol = null;
  this.slashes = null;
  this.auth = null;
  this.host = null;
  this.port = null;
  this.hostname = null;
  this.hash = null;
  this.search = null;
  this.query = null;
  this.pathname = null;
  this.path = null;
  this.href = null;
}
var protocolPattern = /^([a-z0-9.+-]+:)/i, portPattern = /:[0-9]*$/, simplePathPattern = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/, delims = ["<", ">", '"', "`", " ", "\r", "\n", "	"], unwise = ["{", "}", "|", "\\", "^", "`"].concat(delims), autoEscape = ["'"].concat(unwise), nonHostChars = ["%", "/", "?", ";", "#"].concat(autoEscape), hostEndingChars = ["/", "?", "#"], hostnameMaxLen = 255, hostnamePartPattern = /^[+a-z0-9A-Z_-]{0,63}$/, hostnamePartStart = /^([+a-z0-9A-Z_-]{0,63})(.*)$/, unsafeProtocol = {
  "javascript": true,
  "javascript:": true
}, hostlessProtocol = {
  "javascript": true,
  "javascript:": true
}, slashedProtocol = {
  "http": true,
  "https": true,
  "ftp": true,
  "gopher": true,
  "file": true,
  "http:": true,
  "https:": true,
  "ftp:": true,
  "gopher:": true,
  "file:": true
}, querystring = querystring$1;
function urlParse(url2, parseQueryString, slashesDenoteHost) {
  if (url2 && util.isObject(url2) && url2 instanceof Url)
    return url2;
  var u = new Url();
  u.parse(url2, parseQueryString, slashesDenoteHost);
  return u;
}
Url.prototype.parse = function(url2, parseQueryString, slashesDenoteHost) {
  if (!util.isString(url2)) {
    throw new TypeError("Parameter 'url' must be a string, not " + typeof url2);
  }
  var queryIndex = url2.indexOf("?"), splitter = queryIndex !== -1 && queryIndex < url2.indexOf("#") ? "?" : "#", uSplit = url2.split(splitter), slashRegex = /\\/g;
  uSplit[0] = uSplit[0].replace(slashRegex, "/");
  url2 = uSplit.join(splitter);
  var rest = url2;
  rest = rest.trim();
  if (!slashesDenoteHost && url2.split("#").length === 1) {
    var simplePath = simplePathPattern.exec(rest);
    if (simplePath) {
      this.path = rest;
      this.href = rest;
      this.pathname = simplePath[1];
      if (simplePath[2]) {
        this.search = simplePath[2];
        if (parseQueryString) {
          this.query = querystring.parse(this.search.substr(1));
        } else {
          this.query = this.search.substr(1);
        }
      } else if (parseQueryString) {
        this.search = "";
        this.query = {};
      }
      return this;
    }
  }
  var proto = protocolPattern.exec(rest);
  if (proto) {
    proto = proto[0];
    var lowerProto = proto.toLowerCase();
    this.protocol = lowerProto;
    rest = rest.substr(proto.length);
  }
  if (slashesDenoteHost || proto || rest.match(/^\/\/[^@\/]+@[^@\/]+/)) {
    var slashes = rest.substr(0, 2) === "//";
    if (slashes && !(proto && hostlessProtocol[proto])) {
      rest = rest.substr(2);
      this.slashes = true;
    }
  }
  if (!hostlessProtocol[proto] && (slashes || proto && !slashedProtocol[proto])) {
    var hostEnd = -1;
    for (var i = 0; i < hostEndingChars.length; i++) {
      var hec = rest.indexOf(hostEndingChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
        hostEnd = hec;
    }
    var auth, atSign;
    if (hostEnd === -1) {
      atSign = rest.lastIndexOf("@");
    } else {
      atSign = rest.lastIndexOf("@", hostEnd);
    }
    if (atSign !== -1) {
      auth = rest.slice(0, atSign);
      rest = rest.slice(atSign + 1);
      this.auth = decodeURIComponent(auth);
    }
    hostEnd = -1;
    for (var i = 0; i < nonHostChars.length; i++) {
      var hec = rest.indexOf(nonHostChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
        hostEnd = hec;
    }
    if (hostEnd === -1)
      hostEnd = rest.length;
    this.host = rest.slice(0, hostEnd);
    rest = rest.slice(hostEnd);
    this.parseHost();
    this.hostname = this.hostname || "";
    var ipv6Hostname = this.hostname[0] === "[" && this.hostname[this.hostname.length - 1] === "]";
    if (!ipv6Hostname) {
      var hostparts = this.hostname.split(/\./);
      for (var i = 0, l = hostparts.length; i < l; i++) {
        var part = hostparts[i];
        if (!part)
          continue;
        if (!part.match(hostnamePartPattern)) {
          var newpart = "";
          for (var j = 0, k = part.length; j < k; j++) {
            if (part.charCodeAt(j) > 127) {
              newpart += "x";
            } else {
              newpart += part[j];
            }
          }
          if (!newpart.match(hostnamePartPattern)) {
            var validParts = hostparts.slice(0, i);
            var notHost = hostparts.slice(i + 1);
            var bit = part.match(hostnamePartStart);
            if (bit) {
              validParts.push(bit[1]);
              notHost.unshift(bit[2]);
            }
            if (notHost.length) {
              rest = "/" + notHost.join(".") + rest;
            }
            this.hostname = validParts.join(".");
            break;
          }
        }
      }
    }
    if (this.hostname.length > hostnameMaxLen) {
      this.hostname = "";
    } else {
      this.hostname = this.hostname.toLowerCase();
    }
    if (!ipv6Hostname) {
      this.hostname = punycode.toASCII(this.hostname);
    }
    var p = this.port ? ":" + this.port : "";
    var h = this.hostname || "";
    this.host = h + p;
    this.href += this.host;
    if (ipv6Hostname) {
      this.hostname = this.hostname.substr(1, this.hostname.length - 2);
      if (rest[0] !== "/") {
        rest = "/" + rest;
      }
    }
  }
  if (!unsafeProtocol[lowerProto]) {
    for (var i = 0, l = autoEscape.length; i < l; i++) {
      var ae = autoEscape[i];
      if (rest.indexOf(ae) === -1)
        continue;
      var esc = encodeURIComponent(ae);
      if (esc === ae) {
        esc = escape(ae);
      }
      rest = rest.split(ae).join(esc);
    }
  }
  var hash = rest.indexOf("#");
  if (hash !== -1) {
    this.hash = rest.substr(hash);
    rest = rest.slice(0, hash);
  }
  var qm = rest.indexOf("?");
  if (qm !== -1) {
    this.search = rest.substr(qm);
    this.query = rest.substr(qm + 1);
    if (parseQueryString) {
      this.query = querystring.parse(this.query);
    }
    rest = rest.slice(0, qm);
  } else if (parseQueryString) {
    this.search = "";
    this.query = {};
  }
  if (rest)
    this.pathname = rest;
  if (slashedProtocol[lowerProto] && this.hostname && !this.pathname) {
    this.pathname = "/";
  }
  if (this.pathname || this.search) {
    var p = this.pathname || "";
    var s = this.search || "";
    this.path = p + s;
  }
  this.href = this.format();
  return this;
};
function urlFormat(obj) {
  if (util.isString(obj))
    obj = urlParse(obj);
  if (!(obj instanceof Url))
    return Url.prototype.format.call(obj);
  return obj.format();
}
Url.prototype.format = function() {
  var auth = this.auth || "";
  if (auth) {
    auth = encodeURIComponent(auth);
    auth = auth.replace(/%3A/i, ":");
    auth += "@";
  }
  var protocol = this.protocol || "", pathname = this.pathname || "", hash = this.hash || "", host = false, query = "";
  if (this.host) {
    host = auth + this.host;
  } else if (this.hostname) {
    host = auth + (this.hostname.indexOf(":") === -1 ? this.hostname : "[" + this.hostname + "]");
    if (this.port) {
      host += ":" + this.port;
    }
  }
  if (this.query && util.isObject(this.query) && Object.keys(this.query).length) {
    query = querystring.stringify(this.query);
  }
  var search = this.search || query && "?" + query || "";
  if (protocol && protocol.substr(-1) !== ":")
    protocol += ":";
  if (this.slashes || (!protocol || slashedProtocol[protocol]) && host !== false) {
    host = "//" + (host || "");
    if (pathname && pathname.charAt(0) !== "/")
      pathname = "/" + pathname;
  } else if (!host) {
    host = "";
  }
  if (hash && hash.charAt(0) !== "#")
    hash = "#" + hash;
  if (search && search.charAt(0) !== "?")
    search = "?" + search;
  pathname = pathname.replace(/[?#]/g, function(match) {
    return encodeURIComponent(match);
  });
  search = search.replace("#", "%23");
  return protocol + host + pathname + search + hash;
};
function urlResolve(source, relative) {
  return urlParse(source, false, true).resolve(relative);
}
Url.prototype.resolve = function(relative) {
  return this.resolveObject(urlParse(relative, false, true)).format();
};
function urlResolveObject(source, relative) {
  if (!source)
    return relative;
  return urlParse(source, false, true).resolveObject(relative);
}
Url.prototype.resolveObject = function(relative) {
  if (util.isString(relative)) {
    var rel = new Url();
    rel.parse(relative, false, true);
    relative = rel;
  }
  var result = new Url();
  var tkeys = Object.keys(this);
  for (var tk = 0; tk < tkeys.length; tk++) {
    var tkey = tkeys[tk];
    result[tkey] = this[tkey];
  }
  result.hash = relative.hash;
  if (relative.href === "") {
    result.href = result.format();
    return result;
  }
  if (relative.slashes && !relative.protocol) {
    var rkeys = Object.keys(relative);
    for (var rk = 0; rk < rkeys.length; rk++) {
      var rkey = rkeys[rk];
      if (rkey !== "protocol")
        result[rkey] = relative[rkey];
    }
    if (slashedProtocol[result.protocol] && result.hostname && !result.pathname) {
      result.path = result.pathname = "/";
    }
    result.href = result.format();
    return result;
  }
  if (relative.protocol && relative.protocol !== result.protocol) {
    if (!slashedProtocol[relative.protocol]) {
      var keys = Object.keys(relative);
      for (var v = 0; v < keys.length; v++) {
        var k = keys[v];
        result[k] = relative[k];
      }
      result.href = result.format();
      return result;
    }
    result.protocol = relative.protocol;
    if (!relative.host && !hostlessProtocol[relative.protocol]) {
      var relPath = (relative.pathname || "").split("/");
      while (relPath.length && !(relative.host = relPath.shift()))
        ;
      if (!relative.host)
        relative.host = "";
      if (!relative.hostname)
        relative.hostname = "";
      if (relPath[0] !== "")
        relPath.unshift("");
      if (relPath.length < 2)
        relPath.unshift("");
      result.pathname = relPath.join("/");
    } else {
      result.pathname = relative.pathname;
    }
    result.search = relative.search;
    result.query = relative.query;
    result.host = relative.host || "";
    result.auth = relative.auth;
    result.hostname = relative.hostname || relative.host;
    result.port = relative.port;
    if (result.pathname || result.search) {
      var p = result.pathname || "";
      var s = result.search || "";
      result.path = p + s;
    }
    result.slashes = result.slashes || relative.slashes;
    result.href = result.format();
    return result;
  }
  var isSourceAbs = result.pathname && result.pathname.charAt(0) === "/", isRelAbs = relative.host || relative.pathname && relative.pathname.charAt(0) === "/", mustEndAbs = isRelAbs || isSourceAbs || result.host && relative.pathname, removeAllDots = mustEndAbs, srcPath = result.pathname && result.pathname.split("/") || [], relPath = relative.pathname && relative.pathname.split("/") || [], psychotic = result.protocol && !slashedProtocol[result.protocol];
  if (psychotic) {
    result.hostname = "";
    result.port = null;
    if (result.host) {
      if (srcPath[0] === "")
        srcPath[0] = result.host;
      else
        srcPath.unshift(result.host);
    }
    result.host = "";
    if (relative.protocol) {
      relative.hostname = null;
      relative.port = null;
      if (relative.host) {
        if (relPath[0] === "")
          relPath[0] = relative.host;
        else
          relPath.unshift(relative.host);
      }
      relative.host = null;
    }
    mustEndAbs = mustEndAbs && (relPath[0] === "" || srcPath[0] === "");
  }
  if (isRelAbs) {
    result.host = relative.host || relative.host === "" ? relative.host : result.host;
    result.hostname = relative.hostname || relative.hostname === "" ? relative.hostname : result.hostname;
    result.search = relative.search;
    result.query = relative.query;
    srcPath = relPath;
  } else if (relPath.length) {
    if (!srcPath)
      srcPath = [];
    srcPath.pop();
    srcPath = srcPath.concat(relPath);
    result.search = relative.search;
    result.query = relative.query;
  } else if (!util.isNullOrUndefined(relative.search)) {
    if (psychotic) {
      result.hostname = result.host = srcPath.shift();
      var authInHost = result.host && result.host.indexOf("@") > 0 ? result.host.split("@") : false;
      if (authInHost) {
        result.auth = authInHost.shift();
        result.host = result.hostname = authInHost.shift();
      }
    }
    result.search = relative.search;
    result.query = relative.query;
    if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
      result.path = (result.pathname ? result.pathname : "") + (result.search ? result.search : "");
    }
    result.href = result.format();
    return result;
  }
  if (!srcPath.length) {
    result.pathname = null;
    if (result.search) {
      result.path = "/" + result.search;
    } else {
      result.path = null;
    }
    result.href = result.format();
    return result;
  }
  var last = srcPath.slice(-1)[0];
  var hasTrailingSlash = (result.host || relative.host || srcPath.length > 1) && (last === "." || last === "..") || last === "";
  var up = 0;
  for (var i = srcPath.length; i >= 0; i--) {
    last = srcPath[i];
    if (last === ".") {
      srcPath.splice(i, 1);
    } else if (last === "..") {
      srcPath.splice(i, 1);
      up++;
    } else if (up) {
      srcPath.splice(i, 1);
      up--;
    }
  }
  if (!mustEndAbs && !removeAllDots) {
    for (; up--; up) {
      srcPath.unshift("..");
    }
  }
  if (mustEndAbs && srcPath[0] !== "" && (!srcPath[0] || srcPath[0].charAt(0) !== "/")) {
    srcPath.unshift("");
  }
  if (hasTrailingSlash && srcPath.join("/").substr(-1) !== "/") {
    srcPath.push("");
  }
  var isAbsolute = srcPath[0] === "" || srcPath[0] && srcPath[0].charAt(0) === "/";
  if (psychotic) {
    result.hostname = result.host = isAbsolute ? "" : srcPath.length ? srcPath.shift() : "";
    var authInHost = result.host && result.host.indexOf("@") > 0 ? result.host.split("@") : false;
    if (authInHost) {
      result.auth = authInHost.shift();
      result.host = result.hostname = authInHost.shift();
    }
  }
  mustEndAbs = mustEndAbs || result.host && srcPath.length;
  if (mustEndAbs && !isAbsolute) {
    srcPath.unshift("");
  }
  if (!srcPath.length) {
    result.pathname = null;
    result.path = null;
  } else {
    result.pathname = srcPath.join("/");
  }
  if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
    result.path = (result.pathname ? result.pathname : "") + (result.search ? result.search : "");
  }
  result.auth = relative.auth || result.auth;
  result.slashes = result.slashes || relative.slashes;
  result.href = result.format();
  return result;
};
Url.prototype.parseHost = function() {
  var host = this.host;
  var port = portPattern.exec(host);
  if (port) {
    port = port[0];
    if (port !== ":") {
      this.port = port.substr(1);
    }
    host = host.substr(0, host.length - port.length);
  }
  if (host)
    this.hostname = host;
};
var helpers$3 = {};
var uri = url;
var ValidationError = helpers$3.ValidationError = function ValidationError2(message, instance, schema, path, name, argument) {
  if (Array.isArray(path)) {
    this.path = path;
    this.property = path.reduce(function(sum, item) {
      return sum + makeSuffix(item);
    }, "instance");
  } else if (path !== void 0) {
    this.property = path;
  }
  if (message) {
    this.message = message;
  }
  if (schema) {
    var id = schema.$id || schema.id;
    this.schema = id || schema;
  }
  if (instance !== void 0) {
    this.instance = instance;
  }
  this.name = name;
  this.argument = argument;
  this.stack = this.toString();
};
ValidationError.prototype.toString = function toString() {
  return this.property + " " + this.message;
};
var ValidatorResult$2 = helpers$3.ValidatorResult = function ValidatorResult(instance, schema, options, ctx) {
  this.instance = instance;
  this.schema = schema;
  this.options = options;
  this.path = ctx.path;
  this.propertyPath = ctx.propertyPath;
  this.errors = [];
  this.throwError = options && options.throwError;
  this.throwFirst = options && options.throwFirst;
  this.throwAll = options && options.throwAll;
  this.disableFormat = options && options.disableFormat === true;
};
ValidatorResult$2.prototype.addError = function addError(detail) {
  var err;
  if (typeof detail == "string") {
    err = new ValidationError(detail, this.instance, this.schema, this.path);
  } else {
    if (!detail)
      throw new Error("Missing error detail");
    if (!detail.message)
      throw new Error("Missing error message");
    if (!detail.name)
      throw new Error("Missing validator type");
    err = new ValidationError(detail.message, this.instance, this.schema, this.path, detail.name, detail.argument);
  }
  this.errors.push(err);
  if (this.throwFirst) {
    throw new ValidatorResultError$1(this);
  } else if (this.throwError) {
    throw err;
  }
  return err;
};
ValidatorResult$2.prototype.importErrors = function importErrors(res) {
  if (typeof res == "string" || res && res.validatorType) {
    this.addError(res);
  } else if (res && res.errors) {
    this.errors = this.errors.concat(res.errors);
  }
};
function stringizer(v, i) {
  return i + ": " + v.toString() + "\n";
}
ValidatorResult$2.prototype.toString = function toString2(res) {
  return this.errors.map(stringizer).join("");
};
Object.defineProperty(ValidatorResult$2.prototype, "valid", { get: function() {
  return !this.errors.length;
} });
helpers$3.ValidatorResultError = ValidatorResultError$1;
function ValidatorResultError$1(result) {
  if (Error.captureStackTrace) {
    Error.captureStackTrace(this, ValidatorResultError$1);
  }
  this.instance = result.instance;
  this.schema = result.schema;
  this.options = result.options;
  this.errors = result.errors;
}
ValidatorResultError$1.prototype = new Error();
ValidatorResultError$1.prototype.constructor = ValidatorResultError$1;
ValidatorResultError$1.prototype.name = "Validation Error";
var SchemaError$2 = helpers$3.SchemaError = function SchemaError(msg, schema) {
  this.message = msg;
  this.schema = schema;
  Error.call(this, msg);
  Error.captureStackTrace(this, SchemaError);
};
SchemaError$2.prototype = Object.create(
  Error.prototype,
  {
    constructor: { value: SchemaError$2, enumerable: false },
    name: { value: "SchemaError", enumerable: false }
  }
);
var SchemaContext$1 = helpers$3.SchemaContext = function SchemaContext(schema, options, path, base, schemas) {
  this.schema = schema;
  this.options = options;
  if (Array.isArray(path)) {
    this.path = path;
    this.propertyPath = path.reduce(function(sum, item) {
      return sum + makeSuffix(item);
    }, "instance");
  } else {
    this.propertyPath = path;
  }
  this.base = base;
  this.schemas = schemas;
};
SchemaContext$1.prototype.resolve = function resolve(target) {
  return uri.resolve(this.base, target);
};
SchemaContext$1.prototype.makeChild = function makeChild(schema, propertyName) {
  var path = propertyName === void 0 ? this.path : this.path.concat([propertyName]);
  var id = schema.$id || schema.id;
  var base = uri.resolve(this.base, id || "");
  var ctx = new SchemaContext$1(schema, this.options, path, base, Object.create(this.schemas));
  if (id && !ctx.schemas[base]) {
    ctx.schemas[base] = schema;
  }
  return ctx;
};
var FORMAT_REGEXPS = helpers$3.FORMAT_REGEXPS = {
  // 7.3.1. Dates, Times, and Duration
  "date-time": /^\d{4}-(?:0[0-9]{1}|1[0-2]{1})-(3[01]|0[1-9]|[12][0-9])[tT ](2[0-4]|[01][0-9]):([0-5][0-9]):(60|[0-5][0-9])(\.\d+)?([zZ]|[+-]([0-5][0-9]):(60|[0-5][0-9]))$/,
  "date": /^\d{4}-(?:0[0-9]{1}|1[0-2]{1})-(3[01]|0[1-9]|[12][0-9])$/,
  "time": /^(2[0-4]|[01][0-9]):([0-5][0-9]):(60|[0-5][0-9])$/,
  "duration": /P(T\d+(H(\d+M(\d+S)?)?|M(\d+S)?|S)|\d+(D|M(\d+D)?|Y(\d+M(\d+D)?)?)(T\d+(H(\d+M(\d+S)?)?|M(\d+S)?|S))?|\d+W)/i,
  // 7.3.2. Email Addresses
  // TODO: fix the email production
  "email": /^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!\.)){0,61}[a-zA-Z0-9]?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!$)){0,61}[a-zA-Z0-9]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/,
  "idn-email": /^("(?:[!#-\[\]-\u{10FFFF}]|\\[\t -\u{10FFFF}])*"|[!#-'*+\-/-9=?A-Z\^-\u{10FFFF}](?:\.?[!#-'*+\-/-9=?A-Z\^-\u{10FFFF}])*)@([!#-'*+\-/-9=?A-Z\^-\u{10FFFF}](?:\.?[!#-'*+\-/-9=?A-Z\^-\u{10FFFF}])*|\[[!-Z\^-\u{10FFFF}]*\])$/u,
  // 7.3.3. Hostnames
  // 7.3.4. IP Addresses
  "ip-address": /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
  // FIXME whitespace is invalid
  "ipv6": /^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/,
  // 7.3.5. Resource Identifiers
  // TODO: A more accurate regular expression for "uri" goes:
  // [A-Za-z][+\-.0-9A-Za-z]*:((/(/((%[0-9A-Fa-f]{2}|[!$&-.0-9;=A-Z_a-z~])+|(\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~]+)?|[.0-:A-Fa-f]+)\])?)(:\d*)?)?)?#(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~])*|(/(/((%[0-9A-Fa-f]{2}|[!$&-.0-9;=A-Z_a-z~])+|(\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~]+)?|[.0-:A-Fa-f]+)\])?)(:\d*)?[/?]|[!$&-.0-;=?-Z_a-z~])|/?%[0-9A-Fa-f]{2}|[!$&-.0-;=?-Z_a-z~])(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~])*(#(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~])*)?|/(/((%[0-9A-Fa-f]{2}|[!$&-.0-9;=A-Z_a-z~])+(:\d*)?|(\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~]+)?|[.0-:A-Fa-f]+)\])?:\d*|\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~]+)?|[.0-:A-Fa-f]+)\])?)?)?
  "uri": /^[a-zA-Z][a-zA-Z0-9+.-]*:[^\s]*$/,
  "uri-reference": /^(((([A-Za-z][+\-.0-9A-Za-z]*(:%[0-9A-Fa-f]{2}|:[!$&-.0-;=?-Z_a-z~]|[/?])|\?)(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~])*|([A-Za-z][+\-.0-9A-Za-z]*:?)?)|([A-Za-z][+\-.0-9A-Za-z]*:)?\/((%[0-9A-Fa-f]{2}|\/((%[0-9A-Fa-f]{2}|[!$&-.0-9;=A-Z_a-z~])+|(\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~]+)?|[.0-:A-Fa-f]+)\])?)(:\d*)?[/?]|[!$&-.0-;=?-Z_a-z~])(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~])*|(\/((%[0-9A-Fa-f]{2}|[!$&-.0-9;=A-Z_a-z~])+|(\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~]+)?|[.0-:A-Fa-f]+)\])?)(:\d*)?)?))#(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~])*|(([A-Za-z][+\-.0-9A-Za-z]*)?%[0-9A-Fa-f]{2}|[!$&-.0-9;=@_~]|[A-Za-z][+\-.0-9A-Za-z]*[!$&-*,;=@_~])(%[0-9A-Fa-f]{2}|[!$&-.0-9;=@-Z_a-z~])*((([/?](%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~])*)?#|[/?])(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~])*)?|([A-Za-z][+\-.0-9A-Za-z]*(:%[0-9A-Fa-f]{2}|:[!$&-.0-;=?-Z_a-z~]|[/?])|\?)(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~])*|([A-Za-z][+\-.0-9A-Za-z]*:)?\/((%[0-9A-Fa-f]{2}|\/((%[0-9A-Fa-f]{2}|[!$&-.0-9;=A-Z_a-z~])+|(\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~]+)?|[.0-:A-Fa-f]+)\])?)(:\d*)?[/?]|[!$&-.0-;=?-Z_a-z~])(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~])*|\/((%[0-9A-Fa-f]{2}|[!$&-.0-9;=A-Z_a-z~])+(:\d*)?|(\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~]+)?|[.0-:A-Fa-f]+)\])?:\d*|\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~]+)?|[.0-:A-Fa-f]+)\])?)?|[A-Za-z][+\-.0-9A-Za-z]*:?)?$/,
  "iri": /^[a-zA-Z][a-zA-Z0-9+.-]*:[^\s]*$/,
  "iri-reference": /^(((([A-Za-z][+\-.0-9A-Za-z]*(:%[0-9A-Fa-f]{2}|:[!$&-.0-;=?-Z_a-z~-\u{10FFFF}]|[/?])|\?)(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~-\u{10FFFF}])*|([A-Za-z][+\-.0-9A-Za-z]*:?)?)|([A-Za-z][+\-.0-9A-Za-z]*:)?\/((%[0-9A-Fa-f]{2}|\/((%[0-9A-Fa-f]{2}|[!$&-.0-9;=A-Z_a-z~-\u{10FFFF}])+|(\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~-\u{10FFFF}]+)?|[.0-:A-Fa-f]+)\])?)(:\d*)?[/?]|[!$&-.0-;=?-Z_a-z~-\u{10FFFF}])(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~-\u{10FFFF}])*|(\/((%[0-9A-Fa-f]{2}|[!$&-.0-9;=A-Z_a-z~-\u{10FFFF}])+|(\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~-\u{10FFFF}]+)?|[.0-:A-Fa-f]+)\])?)(:\d*)?)?))#(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~-\u{10FFFF}])*|(([A-Za-z][+\-.0-9A-Za-z]*)?%[0-9A-Fa-f]{2}|[!$&-.0-9;=@_~-\u{10FFFF}]|[A-Za-z][+\-.0-9A-Za-z]*[!$&-*,;=@_~-\u{10FFFF}])(%[0-9A-Fa-f]{2}|[!$&-.0-9;=@-Z_a-z~-\u{10FFFF}])*((([/?](%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~-\u{10FFFF}])*)?#|[/?])(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~-\u{10FFFF}])*)?|([A-Za-z][+\-.0-9A-Za-z]*(:%[0-9A-Fa-f]{2}|:[!$&-.0-;=?-Z_a-z~-\u{10FFFF}]|[/?])|\?)(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~-\u{10FFFF}])*|([A-Za-z][+\-.0-9A-Za-z]*:)?\/((%[0-9A-Fa-f]{2}|\/((%[0-9A-Fa-f]{2}|[!$&-.0-9;=A-Z_a-z~-\u{10FFFF}])+|(\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~-\u{10FFFF}]+)?|[.0-:A-Fa-f]+)\])?)(:\d*)?[/?]|[!$&-.0-;=?-Z_a-z~-\u{10FFFF}])(%[0-9A-Fa-f]{2}|[!$&-;=?-Z_a-z~-\u{10FFFF}])*|\/((%[0-9A-Fa-f]{2}|[!$&-.0-9;=A-Z_a-z~-\u{10FFFF}])+(:\d*)?|(\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~-\u{10FFFF}]+)?|[.0-:A-Fa-f]+)\])?:\d*|\[(([Vv][0-9A-Fa-f]+\.[!$&-.0-;=A-Z_a-z~-\u{10FFFF}]+)?|[.0-:A-Fa-f]+)\])?)?|[A-Za-z][+\-.0-9A-Za-z]*:?)?$/u,
  "uuid": /^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$/i,
  // 7.3.6. uri-template
  "uri-template": /(%[0-9a-f]{2}|[!#$&(-;=?@\[\]_a-z~]|\{[!#&+,./;=?@|]?(%[0-9a-f]{2}|[0-9_a-z])(\.?(%[0-9a-f]{2}|[0-9_a-z]))*(:[1-9]\d{0,3}|\*)?(,(%[0-9a-f]{2}|[0-9_a-z])(\.?(%[0-9a-f]{2}|[0-9_a-z]))*(:[1-9]\d{0,3}|\*)?)*\})*/iu,
  // 7.3.7. JSON Pointers
  "json-pointer": /^(\/([\x00-\x2e0-@\[-}\x7f]|~[01])*)*$/iu,
  "relative-json-pointer": /^\d+(#|(\/([\x00-\x2e0-@\[-}\x7f]|~[01])*)*)$/iu,
  // hostname regex from: http://stackoverflow.com/a/1420225/5628
  "hostname": /^(?=.{1,255}$)[0-9A-Za-z](?:(?:[0-9A-Za-z]|-){0,61}[0-9A-Za-z])?(?:\.[0-9A-Za-z](?:(?:[0-9A-Za-z]|-){0,61}[0-9A-Za-z])?)*\.?$/,
  "host-name": /^(?=.{1,255}$)[0-9A-Za-z](?:(?:[0-9A-Za-z]|-){0,61}[0-9A-Za-z])?(?:\.[0-9A-Za-z](?:(?:[0-9A-Za-z]|-){0,61}[0-9A-Za-z])?)*\.?$/,
  "utc-millisec": function(input) {
    return typeof input === "string" && parseFloat(input) === parseInt(input, 10) && !isNaN(input);
  },
  // 7.3.8. regex
  "regex": function(input) {
    var result = true;
    try {
      new RegExp(input);
    } catch (e) {
      result = false;
    }
    return result;
  },
  // Other definitions
  // "style" was removed from JSON Schema in draft-4 and is deprecated
  "style": /[\r\n\t ]*[^\r\n\t ][^:]*:[\r\n\t ]*[^\r\n\t ;]*[\r\n\t ]*;?/,
  // "color" was removed from JSON Schema in draft-4 and is deprecated
  "color": /^(#?([0-9A-Fa-f]{3}){1,2}\b|aqua|black|blue|fuchsia|gray|green|lime|maroon|navy|olive|orange|purple|red|silver|teal|white|yellow|(rgb\(\s*\b([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\b\s*,\s*\b([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\b\s*,\s*\b([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\b\s*\))|(rgb\(\s*(\d?\d%|100%)+\s*,\s*(\d?\d%|100%)+\s*,\s*(\d?\d%|100%)+\s*\)))$/,
  "phone": /^\+(?:[0-9] ?){6,14}[0-9]$/,
  "alpha": /^[a-zA-Z]+$/,
  "alphanumeric": /^[a-zA-Z0-9]+$/
};
FORMAT_REGEXPS.regexp = FORMAT_REGEXPS.regex;
FORMAT_REGEXPS.pattern = FORMAT_REGEXPS.regex;
FORMAT_REGEXPS.ipv4 = FORMAT_REGEXPS["ip-address"];
helpers$3.isFormat = function isFormat(input, format, validator2) {
  if (typeof input === "string" && FORMAT_REGEXPS[format] !== void 0) {
    if (FORMAT_REGEXPS[format] instanceof RegExp) {
      return FORMAT_REGEXPS[format].test(input);
    }
    if (typeof FORMAT_REGEXPS[format] === "function") {
      return FORMAT_REGEXPS[format](input);
    }
  } else if (validator2 && validator2.customFormats && typeof validator2.customFormats[format] === "function") {
    return validator2.customFormats[format](input);
  }
  return true;
};
var makeSuffix = helpers$3.makeSuffix = function makeSuffix2(key) {
  key = key.toString();
  if (!key.match(/[.\s\[\]]/) && !key.match(/^[\d]/)) {
    return "." + key;
  }
  if (key.match(/^\d+$/)) {
    return "[" + key + "]";
  }
  return "[" + JSON.stringify(key) + "]";
};
helpers$3.deepCompareStrict = function deepCompareStrict(a, b) {
  if (typeof a !== typeof b) {
    return false;
  }
  if (Array.isArray(a)) {
    if (!Array.isArray(b)) {
      return false;
    }
    if (a.length !== b.length) {
      return false;
    }
    return a.every(function(v, i) {
      return deepCompareStrict(a[i], b[i]);
    });
  }
  if (typeof a === "object") {
    if (!a || !b) {
      return a === b;
    }
    var aKeys = Object.keys(a);
    var bKeys = Object.keys(b);
    if (aKeys.length !== bKeys.length) {
      return false;
    }
    return aKeys.every(function(v) {
      return deepCompareStrict(a[v], b[v]);
    });
  }
  return a === b;
};
function deepMerger(target, dst, e, i) {
  if (typeof e === "object") {
    dst[i] = deepMerge(target[i], e);
  } else {
    if (target.indexOf(e) === -1) {
      dst.push(e);
    }
  }
}
function copyist(src, dst, key) {
  dst[key] = src[key];
}
function copyistWithDeepMerge(target, src, dst, key) {
  if (typeof src[key] !== "object" || !src[key]) {
    dst[key] = src[key];
  } else {
    if (!target[key]) {
      dst[key] = src[key];
    } else {
      dst[key] = deepMerge(target[key], src[key]);
    }
  }
}
function deepMerge(target, src) {
  var array = Array.isArray(src);
  var dst = array && [] || {};
  if (array) {
    target = target || [];
    dst = dst.concat(target);
    src.forEach(deepMerger.bind(null, target, dst));
  } else {
    if (target && typeof target === "object") {
      Object.keys(target).forEach(copyist.bind(null, target, dst));
    }
    Object.keys(src).forEach(copyistWithDeepMerge.bind(null, target, src, dst));
  }
  return dst;
}
helpers$3.deepMerge = deepMerge;
helpers$3.objectGetPath = function objectGetPath(o, s) {
  var parts = s.split("/").slice(1);
  var k;
  while (typeof (k = parts.shift()) == "string") {
    var n = decodeURIComponent(k.replace(/~0/, "~").replace(/~1/g, "/"));
    if (!(n in o))
      return;
    o = o[n];
  }
  return o;
};
function pathEncoder(v) {
  return "/" + encodeURIComponent(v).replace(/~/g, "%7E");
}
helpers$3.encodePath = function encodePointer(a) {
  return a.map(pathEncoder).join("");
};
helpers$3.getDecimalPlaces = function getDecimalPlaces(number) {
  var decimalPlaces = 0;
  if (isNaN(number))
    return decimalPlaces;
  if (typeof number !== "number") {
    number = Number(number);
  }
  var parts = number.toString().split("e");
  if (parts.length === 2) {
    if (parts[1][0] !== "-") {
      return decimalPlaces;
    } else {
      decimalPlaces = Number(parts[1].slice(1));
    }
  }
  var decimalParts = parts[0].split(".");
  if (decimalParts.length === 2) {
    decimalPlaces += decimalParts[1].length;
  }
  return decimalPlaces;
};
helpers$3.isSchema = function isSchema(val) {
  return typeof val === "object" && val || typeof val === "boolean";
};
var helpers$2 = helpers$3;
var ValidatorResult$1 = helpers$2.ValidatorResult;
var SchemaError$1 = helpers$2.SchemaError;
var attribute$1 = {};
attribute$1.ignoreProperties = {
  // informative properties
  "id": true,
  "default": true,
  "description": true,
  "title": true,
  // arguments to other properties
  "additionalItems": true,
  "then": true,
  "else": true,
  // special-handled properties
  "$schema": true,
  "$ref": true,
  "extends": true
};
var validators = attribute$1.validators = {};
validators.type = function validateType(instance, schema, options, ctx) {
  if (instance === void 0) {
    return null;
  }
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var types2 = Array.isArray(schema.type) ? schema.type : [schema.type];
  if (!types2.some(this.testType.bind(this, instance, schema, options, ctx))) {
    var list = types2.map(function(v) {
      if (!v)
        return;
      var id = v.$id || v.id;
      return id ? "<" + id + ">" : v + "";
    });
    result.addError({
      name: "type",
      argument: list,
      message: "is not of a type(s) " + list
    });
  }
  return result;
};
function testSchemaNoThrow(instance, options, ctx, callback, schema) {
  var throwError = options.throwError;
  var throwAll = options.throwAll;
  options.throwError = false;
  options.throwAll = false;
  var res = this.validateSchema(instance, schema, options, ctx);
  options.throwError = throwError;
  options.throwAll = throwAll;
  if (!res.valid && callback instanceof Function) {
    callback(res);
  }
  return res.valid;
}
validators.anyOf = function validateAnyOf(instance, schema, options, ctx) {
  if (instance === void 0) {
    return null;
  }
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var inner = new ValidatorResult$1(instance, schema, options, ctx);
  if (!Array.isArray(schema.anyOf)) {
    throw new SchemaError$1("anyOf must be an array");
  }
  if (!schema.anyOf.some(
    testSchemaNoThrow.bind(
      this,
      instance,
      options,
      ctx,
      function(res) {
        inner.importErrors(res);
      }
    )
  )) {
    var list = schema.anyOf.map(function(v, i) {
      var id = v.$id || v.id;
      if (id)
        return "<" + id + ">";
      return v.title && JSON.stringify(v.title) || v["$ref"] && "<" + v["$ref"] + ">" || "[subschema " + i + "]";
    });
    if (options.nestedErrors) {
      result.importErrors(inner);
    }
    result.addError({
      name: "anyOf",
      argument: list,
      message: "is not any of " + list.join(",")
    });
  }
  return result;
};
validators.allOf = function validateAllOf(instance, schema, options, ctx) {
  if (instance === void 0) {
    return null;
  }
  if (!Array.isArray(schema.allOf)) {
    throw new SchemaError$1("allOf must be an array");
  }
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var self2 = this;
  schema.allOf.forEach(function(v, i) {
    var valid = self2.validateSchema(instance, v, options, ctx);
    if (!valid.valid) {
      var id = v.$id || v.id;
      var msg = id || v.title && JSON.stringify(v.title) || v["$ref"] && "<" + v["$ref"] + ">" || "[subschema " + i + "]";
      result.addError({
        name: "allOf",
        argument: { id: msg, length: valid.errors.length, valid },
        message: "does not match allOf schema " + msg + " with " + valid.errors.length + " error[s]:"
      });
      result.importErrors(valid);
    }
  });
  return result;
};
validators.oneOf = function validateOneOf(instance, schema, options, ctx) {
  if (instance === void 0) {
    return null;
  }
  if (!Array.isArray(schema.oneOf)) {
    throw new SchemaError$1("oneOf must be an array");
  }
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var inner = new ValidatorResult$1(instance, schema, options, ctx);
  var count = schema.oneOf.filter(
    testSchemaNoThrow.bind(
      this,
      instance,
      options,
      ctx,
      function(res) {
        inner.importErrors(res);
      }
    )
  ).length;
  var list = schema.oneOf.map(function(v, i) {
    var id = v.$id || v.id;
    return id || v.title && JSON.stringify(v.title) || v["$ref"] && "<" + v["$ref"] + ">" || "[subschema " + i + "]";
  });
  if (count !== 1) {
    if (options.nestedErrors) {
      result.importErrors(inner);
    }
    result.addError({
      name: "oneOf",
      argument: list,
      message: "is not exactly one from " + list.join(",")
    });
  }
  return result;
};
validators.if = function validateIf(instance, schema, options, ctx) {
  if (instance === void 0)
    return null;
  if (!helpers$2.isSchema(schema.if))
    throw new Error('Expected "if" keyword to be a schema');
  var ifValid = testSchemaNoThrow.call(this, instance, options, ctx, null, schema.if);
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var res;
  if (ifValid) {
    if (schema.then === void 0)
      return;
    if (!helpers$2.isSchema(schema.then))
      throw new Error('Expected "then" keyword to be a schema');
    res = this.validateSchema(instance, schema.then, options, ctx.makeChild(schema.then));
    result.importErrors(res);
  } else {
    if (schema.else === void 0)
      return;
    if (!helpers$2.isSchema(schema.else))
      throw new Error('Expected "else" keyword to be a schema');
    res = this.validateSchema(instance, schema.else, options, ctx.makeChild(schema.else));
    result.importErrors(res);
  }
  return result;
};
function getEnumerableProperty(object, key) {
  if (Object.hasOwnProperty.call(object, key))
    return object[key];
  if (!(key in object))
    return;
  while (object = Object.getPrototypeOf(object)) {
    if (Object.propertyIsEnumerable.call(object, key))
      return object[key];
  }
}
validators.propertyNames = function validatePropertyNames(instance, schema, options, ctx) {
  if (!this.types.object(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var subschema = schema.propertyNames !== void 0 ? schema.propertyNames : {};
  if (!helpers$2.isSchema(subschema))
    throw new SchemaError$1('Expected "propertyNames" to be a schema (object or boolean)');
  for (var property in instance) {
    if (getEnumerableProperty(instance, property) !== void 0) {
      var res = this.validateSchema(property, subschema, options, ctx.makeChild(subschema));
      result.importErrors(res);
    }
  }
  return result;
};
validators.properties = function validateProperties(instance, schema, options, ctx) {
  if (!this.types.object(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var properties = schema.properties || {};
  for (var property in properties) {
    var subschema = properties[property];
    if (subschema === void 0) {
      continue;
    } else if (subschema === null) {
      throw new SchemaError$1('Unexpected null, expected schema in "properties"');
    }
    if (typeof options.preValidateProperty == "function") {
      options.preValidateProperty(instance, property, subschema, options, ctx);
    }
    var prop = getEnumerableProperty(instance, property);
    var res = this.validateSchema(prop, subschema, options, ctx.makeChild(subschema, property));
    if (res.instance !== result.instance[property])
      result.instance[property] = res.instance;
    result.importErrors(res);
  }
  return result;
};
function testAdditionalProperty(instance, schema, options, ctx, property, result) {
  if (!this.types.object(instance))
    return;
  if (schema.properties && schema.properties[property] !== void 0) {
    return;
  }
  if (schema.additionalProperties === false) {
    result.addError({
      name: "additionalProperties",
      argument: property,
      message: "is not allowed to have the additional property " + JSON.stringify(property)
    });
  } else {
    var additionalProperties = schema.additionalProperties || {};
    if (typeof options.preValidateProperty == "function") {
      options.preValidateProperty(instance, property, additionalProperties, options, ctx);
    }
    var res = this.validateSchema(instance[property], additionalProperties, options, ctx.makeChild(additionalProperties, property));
    if (res.instance !== result.instance[property])
      result.instance[property] = res.instance;
    result.importErrors(res);
  }
}
validators.patternProperties = function validatePatternProperties(instance, schema, options, ctx) {
  if (!this.types.object(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var patternProperties = schema.patternProperties || {};
  for (var property in instance) {
    var test = true;
    for (var pattern in patternProperties) {
      var subschema = patternProperties[pattern];
      if (subschema === void 0) {
        continue;
      } else if (subschema === null) {
        throw new SchemaError$1('Unexpected null, expected schema in "patternProperties"');
      }
      try {
        var regexp = new RegExp(pattern, "u");
      } catch (_e) {
        regexp = new RegExp(pattern);
      }
      if (!regexp.test(property)) {
        continue;
      }
      test = false;
      if (typeof options.preValidateProperty == "function") {
        options.preValidateProperty(instance, property, subschema, options, ctx);
      }
      var res = this.validateSchema(instance[property], subschema, options, ctx.makeChild(subschema, property));
      if (res.instance !== result.instance[property])
        result.instance[property] = res.instance;
      result.importErrors(res);
    }
    if (test) {
      testAdditionalProperty.call(this, instance, schema, options, ctx, property, result);
    }
  }
  return result;
};
validators.additionalProperties = function validateAdditionalProperties(instance, schema, options, ctx) {
  if (!this.types.object(instance))
    return;
  if (schema.patternProperties) {
    return null;
  }
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  for (var property in instance) {
    testAdditionalProperty.call(this, instance, schema, options, ctx, property, result);
  }
  return result;
};
validators.minProperties = function validateMinProperties(instance, schema, options, ctx) {
  if (!this.types.object(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var keys = Object.keys(instance);
  if (!(keys.length >= schema.minProperties)) {
    result.addError({
      name: "minProperties",
      argument: schema.minProperties,
      message: "does not meet minimum property length of " + schema.minProperties
    });
  }
  return result;
};
validators.maxProperties = function validateMaxProperties(instance, schema, options, ctx) {
  if (!this.types.object(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var keys = Object.keys(instance);
  if (!(keys.length <= schema.maxProperties)) {
    result.addError({
      name: "maxProperties",
      argument: schema.maxProperties,
      message: "does not meet maximum property length of " + schema.maxProperties
    });
  }
  return result;
};
validators.items = function validateItems(instance, schema, options, ctx) {
  var self2 = this;
  if (!this.types.array(instance))
    return;
  if (schema.items === void 0)
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  instance.every(function(value, i) {
    if (Array.isArray(schema.items)) {
      var items = schema.items[i] === void 0 ? schema.additionalItems : schema.items[i];
    } else {
      var items = schema.items;
    }
    if (items === void 0) {
      return true;
    }
    if (items === false) {
      result.addError({
        name: "items",
        message: "additionalItems not permitted"
      });
      return false;
    }
    var res = self2.validateSchema(value, items, options, ctx.makeChild(items, i));
    if (res.instance !== result.instance[i])
      result.instance[i] = res.instance;
    result.importErrors(res);
    return true;
  });
  return result;
};
validators.contains = function validateContains(instance, schema, options, ctx) {
  var self2 = this;
  if (!this.types.array(instance))
    return;
  if (schema.contains === void 0)
    return;
  if (!helpers$2.isSchema(schema.contains))
    throw new Error('Expected "contains" keyword to be a schema');
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var count = instance.some(function(value, i) {
    var res = self2.validateSchema(value, schema.contains, options, ctx.makeChild(schema.contains, i));
    return res.errors.length === 0;
  });
  if (count === false) {
    result.addError({
      name: "contains",
      argument: schema.contains,
      message: "must contain an item matching given schema"
    });
  }
  return result;
};
validators.minimum = function validateMinimum(instance, schema, options, ctx) {
  if (!this.types.number(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  if (schema.exclusiveMinimum && schema.exclusiveMinimum === true) {
    if (!(instance > schema.minimum)) {
      result.addError({
        name: "minimum",
        argument: schema.minimum,
        message: "must be greater than " + schema.minimum
      });
    }
  } else {
    if (!(instance >= schema.minimum)) {
      result.addError({
        name: "minimum",
        argument: schema.minimum,
        message: "must be greater than or equal to " + schema.minimum
      });
    }
  }
  return result;
};
validators.maximum = function validateMaximum(instance, schema, options, ctx) {
  if (!this.types.number(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  if (schema.exclusiveMaximum && schema.exclusiveMaximum === true) {
    if (!(instance < schema.maximum)) {
      result.addError({
        name: "maximum",
        argument: schema.maximum,
        message: "must be less than " + schema.maximum
      });
    }
  } else {
    if (!(instance <= schema.maximum)) {
      result.addError({
        name: "maximum",
        argument: schema.maximum,
        message: "must be less than or equal to " + schema.maximum
      });
    }
  }
  return result;
};
validators.exclusiveMinimum = function validateExclusiveMinimum(instance, schema, options, ctx) {
  if (typeof schema.exclusiveMinimum === "boolean")
    return;
  if (!this.types.number(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var valid = instance > schema.exclusiveMinimum;
  if (!valid) {
    result.addError({
      name: "exclusiveMinimum",
      argument: schema.exclusiveMinimum,
      message: "must be strictly greater than " + schema.exclusiveMinimum
    });
  }
  return result;
};
validators.exclusiveMaximum = function validateExclusiveMaximum(instance, schema, options, ctx) {
  if (typeof schema.exclusiveMaximum === "boolean")
    return;
  if (!this.types.number(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var valid = instance < schema.exclusiveMaximum;
  if (!valid) {
    result.addError({
      name: "exclusiveMaximum",
      argument: schema.exclusiveMaximum,
      message: "must be strictly less than " + schema.exclusiveMaximum
    });
  }
  return result;
};
var validateMultipleOfOrDivisbleBy = function validateMultipleOfOrDivisbleBy2(instance, schema, options, ctx, validationType, errorMessage) {
  if (!this.types.number(instance))
    return;
  var validationArgument = schema[validationType];
  if (validationArgument == 0) {
    throw new SchemaError$1(validationType + " cannot be zero");
  }
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var instanceDecimals = helpers$2.getDecimalPlaces(instance);
  var divisorDecimals = helpers$2.getDecimalPlaces(validationArgument);
  var maxDecimals = Math.max(instanceDecimals, divisorDecimals);
  var multiplier = Math.pow(10, maxDecimals);
  if (Math.round(instance * multiplier) % Math.round(validationArgument * multiplier) !== 0) {
    result.addError({
      name: validationType,
      argument: validationArgument,
      message: errorMessage + JSON.stringify(validationArgument)
    });
  }
  return result;
};
validators.multipleOf = function validateMultipleOf(instance, schema, options, ctx) {
  return validateMultipleOfOrDivisbleBy.call(this, instance, schema, options, ctx, "multipleOf", "is not a multiple of (divisible by) ");
};
validators.divisibleBy = function validateDivisibleBy(instance, schema, options, ctx) {
  return validateMultipleOfOrDivisbleBy.call(this, instance, schema, options, ctx, "divisibleBy", "is not divisible by (multiple of) ");
};
validators.required = function validateRequired(instance, schema, options, ctx) {
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  if (instance === void 0 && schema.required === true) {
    result.addError({
      name: "required",
      message: "is required"
    });
  } else if (this.types.object(instance) && Array.isArray(schema.required)) {
    schema.required.forEach(function(n) {
      if (getEnumerableProperty(instance, n) === void 0) {
        result.addError({
          name: "required",
          argument: n,
          message: "requires property " + JSON.stringify(n)
        });
      }
    });
  }
  return result;
};
validators.pattern = function validatePattern(instance, schema, options, ctx) {
  if (!this.types.string(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var pattern = schema.pattern;
  try {
    var regexp = new RegExp(pattern, "u");
  } catch (_e) {
    regexp = new RegExp(pattern);
  }
  if (!instance.match(regexp)) {
    result.addError({
      name: "pattern",
      argument: schema.pattern,
      message: "does not match pattern " + JSON.stringify(schema.pattern.toString())
    });
  }
  return result;
};
validators.format = function validateFormat(instance, schema, options, ctx) {
  if (instance === void 0)
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  if (!result.disableFormat && !helpers$2.isFormat(instance, schema.format, this)) {
    result.addError({
      name: "format",
      argument: schema.format,
      message: "does not conform to the " + JSON.stringify(schema.format) + " format"
    });
  }
  return result;
};
validators.minLength = function validateMinLength(instance, schema, options, ctx) {
  if (!this.types.string(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var hsp = instance.match(/[\uDC00-\uDFFF]/g);
  var length = instance.length - (hsp ? hsp.length : 0);
  if (!(length >= schema.minLength)) {
    result.addError({
      name: "minLength",
      argument: schema.minLength,
      message: "does not meet minimum length of " + schema.minLength
    });
  }
  return result;
};
validators.maxLength = function validateMaxLength(instance, schema, options, ctx) {
  if (!this.types.string(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var hsp = instance.match(/[\uDC00-\uDFFF]/g);
  var length = instance.length - (hsp ? hsp.length : 0);
  if (!(length <= schema.maxLength)) {
    result.addError({
      name: "maxLength",
      argument: schema.maxLength,
      message: "does not meet maximum length of " + schema.maxLength
    });
  }
  return result;
};
validators.minItems = function validateMinItems(instance, schema, options, ctx) {
  if (!this.types.array(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  if (!(instance.length >= schema.minItems)) {
    result.addError({
      name: "minItems",
      argument: schema.minItems,
      message: "does not meet minimum length of " + schema.minItems
    });
  }
  return result;
};
validators.maxItems = function validateMaxItems(instance, schema, options, ctx) {
  if (!this.types.array(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  if (!(instance.length <= schema.maxItems)) {
    result.addError({
      name: "maxItems",
      argument: schema.maxItems,
      message: "does not meet maximum length of " + schema.maxItems
    });
  }
  return result;
};
function testArrays(v, i, a) {
  var j, len = a.length;
  for (j = i + 1, len; j < len; j++) {
    if (helpers$2.deepCompareStrict(v, a[j])) {
      return false;
    }
  }
  return true;
}
validators.uniqueItems = function validateUniqueItems(instance, schema, options, ctx) {
  if (schema.uniqueItems !== true)
    return;
  if (!this.types.array(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  if (!instance.every(testArrays)) {
    result.addError({
      name: "uniqueItems",
      message: "contains duplicate item"
    });
  }
  return result;
};
validators.dependencies = function validateDependencies(instance, schema, options, ctx) {
  if (!this.types.object(instance))
    return;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  for (var property in schema.dependencies) {
    if (instance[property] === void 0) {
      continue;
    }
    var dep = schema.dependencies[property];
    var childContext = ctx.makeChild(dep, property);
    if (typeof dep == "string") {
      dep = [dep];
    }
    if (Array.isArray(dep)) {
      dep.forEach(function(prop) {
        if (instance[prop] === void 0) {
          result.addError({
            // FIXME there's two different "dependencies" errors here with slightly different outputs
            // Can we make these the same? Or should we create different error types?
            name: "dependencies",
            argument: childContext.propertyPath,
            message: "property " + prop + " not found, required by " + childContext.propertyPath
          });
        }
      });
    } else {
      var res = this.validateSchema(instance, dep, options, childContext);
      if (result.instance !== res.instance)
        result.instance = res.instance;
      if (res && res.errors.length) {
        result.addError({
          name: "dependencies",
          argument: childContext.propertyPath,
          message: "does not meet dependency required by " + childContext.propertyPath
        });
        result.importErrors(res);
      }
    }
  }
  return result;
};
validators["enum"] = function validateEnum(instance, schema, options, ctx) {
  if (instance === void 0) {
    return null;
  }
  if (!Array.isArray(schema["enum"])) {
    throw new SchemaError$1("enum expects an array", schema);
  }
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  if (!schema["enum"].some(helpers$2.deepCompareStrict.bind(null, instance))) {
    result.addError({
      name: "enum",
      argument: schema["enum"],
      message: "is not one of enum values: " + schema["enum"].map(String).join(",")
    });
  }
  return result;
};
validators["const"] = function validateEnum2(instance, schema, options, ctx) {
  if (instance === void 0) {
    return null;
  }
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  if (!helpers$2.deepCompareStrict(schema["const"], instance)) {
    result.addError({
      name: "const",
      argument: schema["const"],
      message: "does not exactly match expected constant: " + schema["const"]
    });
  }
  return result;
};
validators.not = validators.disallow = function validateNot(instance, schema, options, ctx) {
  var self2 = this;
  if (instance === void 0)
    return null;
  var result = new ValidatorResult$1(instance, schema, options, ctx);
  var notTypes = schema.not || schema.disallow;
  if (!notTypes)
    return null;
  if (!Array.isArray(notTypes))
    notTypes = [notTypes];
  notTypes.forEach(function(type) {
    if (self2.testType(instance, schema, options, ctx, type)) {
      var id = type && (type.$id || type.id);
      var schemaId = id || type;
      result.addError({
        name: "not",
        argument: schemaId,
        message: "is of prohibited type " + schemaId
      });
    }
  });
  return result;
};
var attribute_1 = attribute$1;
var scan = {};
var urilib$1 = url;
var helpers$1 = helpers$3;
scan.SchemaScanResult = SchemaScanResult;
function SchemaScanResult(found, ref) {
  this.id = found;
  this.ref = ref;
}
scan.scan = function scan2(base, schema) {
  function scanSchema2(baseuri, schema2) {
    if (!schema2 || typeof schema2 != "object")
      return;
    if (schema2.$ref) {
      var resolvedUri = urilib$1.resolve(baseuri, schema2.$ref);
      ref[resolvedUri] = ref[resolvedUri] ? ref[resolvedUri] + 1 : 0;
      return;
    }
    var id = schema2.$id || schema2.id;
    var ourBase = id ? urilib$1.resolve(baseuri, id) : baseuri;
    if (ourBase) {
      if (ourBase.indexOf("#") < 0)
        ourBase += "#";
      if (found[ourBase]) {
        if (!helpers$1.deepCompareStrict(found[ourBase], schema2)) {
          throw new Error("Schema <" + ourBase + "> already exists with different definition");
        }
        return found[ourBase];
      }
      found[ourBase] = schema2;
      if (ourBase[ourBase.length - 1] == "#") {
        found[ourBase.substring(0, ourBase.length - 1)] = schema2;
      }
    }
    scanArray(ourBase + "/items", Array.isArray(schema2.items) ? schema2.items : [schema2.items]);
    scanArray(ourBase + "/extends", Array.isArray(schema2.extends) ? schema2.extends : [schema2.extends]);
    scanSchema2(ourBase + "/additionalItems", schema2.additionalItems);
    scanObject(ourBase + "/properties", schema2.properties);
    scanSchema2(ourBase + "/additionalProperties", schema2.additionalProperties);
    scanObject(ourBase + "/definitions", schema2.definitions);
    scanObject(ourBase + "/patternProperties", schema2.patternProperties);
    scanObject(ourBase + "/dependencies", schema2.dependencies);
    scanArray(ourBase + "/disallow", schema2.disallow);
    scanArray(ourBase + "/allOf", schema2.allOf);
    scanArray(ourBase + "/anyOf", schema2.anyOf);
    scanArray(ourBase + "/oneOf", schema2.oneOf);
    scanSchema2(ourBase + "/not", schema2.not);
  }
  function scanArray(baseuri, schemas) {
    if (!Array.isArray(schemas))
      return;
    for (var i = 0; i < schemas.length; i++) {
      scanSchema2(baseuri + "/" + i, schemas[i]);
    }
  }
  function scanObject(baseuri, schemas) {
    if (!schemas || typeof schemas != "object")
      return;
    for (var p in schemas) {
      scanSchema2(baseuri + "/" + p, schemas[p]);
    }
  }
  var found = {};
  var ref = {};
  scanSchema2(base, schema);
  return new SchemaScanResult(found, ref);
};
var urilib = url;
var attribute = attribute_1;
var helpers = helpers$3;
var scanSchema = scan.scan;
var ValidatorResult2 = helpers.ValidatorResult;
var ValidatorResultError = helpers.ValidatorResultError;
var SchemaError2 = helpers.SchemaError;
var SchemaContext2 = helpers.SchemaContext;
var anonymousBase = "/";
var Validator$1 = function Validator() {
  this.customFormats = Object.create(Validator.prototype.customFormats);
  this.schemas = {};
  this.unresolvedRefs = [];
  this.types = Object.create(types);
  this.attributes = Object.create(attribute.validators);
};
Validator$1.prototype.customFormats = {};
Validator$1.prototype.schemas = null;
Validator$1.prototype.types = null;
Validator$1.prototype.attributes = null;
Validator$1.prototype.unresolvedRefs = null;
Validator$1.prototype.addSchema = function addSchema(schema, base) {
  var self2 = this;
  if (!schema) {
    return null;
  }
  var scan3 = scanSchema(base || anonymousBase, schema);
  var ourUri = base || schema.$id || schema.id;
  for (var uri2 in scan3.id) {
    this.schemas[uri2] = scan3.id[uri2];
  }
  for (var uri2 in scan3.ref) {
    this.unresolvedRefs.push(uri2);
  }
  this.unresolvedRefs = this.unresolvedRefs.filter(function(uri3) {
    return typeof self2.schemas[uri3] === "undefined";
  });
  return this.schemas[ourUri];
};
Validator$1.prototype.addSubSchemaArray = function addSubSchemaArray(baseuri, schemas) {
  if (!Array.isArray(schemas))
    return;
  for (var i = 0; i < schemas.length; i++) {
    this.addSubSchema(baseuri, schemas[i]);
  }
};
Validator$1.prototype.addSubSchemaObject = function addSubSchemaArray2(baseuri, schemas) {
  if (!schemas || typeof schemas != "object")
    return;
  for (var p in schemas) {
    this.addSubSchema(baseuri, schemas[p]);
  }
};
Validator$1.prototype.setSchemas = function setSchemas(schemas) {
  this.schemas = schemas;
};
Validator$1.prototype.getSchema = function getSchema(urn) {
  return this.schemas[urn];
};
Validator$1.prototype.validate = function validate(instance, schema, options, ctx) {
  if (typeof schema !== "boolean" && typeof schema !== "object" || schema === null) {
    throw new SchemaError2("Expected `schema` to be an object or boolean");
  }
  if (!options) {
    options = {};
  }
  var id = schema.$id || schema.id;
  var base = urilib.resolve(options.base || anonymousBase, id || "");
  if (!ctx) {
    ctx = new SchemaContext2(schema, options, [], base, Object.create(this.schemas));
    if (!ctx.schemas[base]) {
      ctx.schemas[base] = schema;
    }
    var found = scanSchema(base, schema);
    for (var n in found.id) {
      var sch = found.id[n];
      ctx.schemas[n] = sch;
    }
  }
  if (options.required && instance === void 0) {
    var result = new ValidatorResult2(instance, schema, options, ctx);
    result.addError("is required, but is undefined");
    return result;
  }
  var result = this.validateSchema(instance, schema, options, ctx);
  if (!result) {
    throw new Error("Result undefined");
  } else if (options.throwAll && result.errors.length) {
    throw new ValidatorResultError(result);
  }
  return result;
};
function shouldResolve(schema) {
  var ref = typeof schema === "string" ? schema : schema.$ref;
  if (typeof ref == "string")
    return ref;
  return false;
}
Validator$1.prototype.validateSchema = function validateSchema(instance, schema, options, ctx) {
  var result = new ValidatorResult2(instance, schema, options, ctx);
  if (typeof schema === "boolean") {
    if (schema === true) {
      schema = {};
    } else if (schema === false) {
      schema = { type: [] };
    }
  } else if (!schema) {
    throw new Error("schema is undefined");
  }
  if (schema["extends"]) {
    if (Array.isArray(schema["extends"])) {
      var schemaobj = { schema, ctx };
      schema["extends"].forEach(this.schemaTraverser.bind(this, schemaobj));
      schema = schemaobj.schema;
      schemaobj.schema = null;
      schemaobj.ctx = null;
      schemaobj = null;
    } else {
      schema = helpers.deepMerge(schema, this.superResolve(schema["extends"], ctx));
    }
  }
  var switchSchema = shouldResolve(schema);
  if (switchSchema) {
    var resolved = this.resolve(schema, switchSchema, ctx);
    var subctx = new SchemaContext2(resolved.subschema, options, ctx.path, resolved.switchSchema, ctx.schemas);
    return this.validateSchema(instance, resolved.subschema, options, subctx);
  }
  var skipAttributes = options && options.skipAttributes || [];
  for (var key in schema) {
    if (!attribute.ignoreProperties[key] && skipAttributes.indexOf(key) < 0) {
      var validatorErr = null;
      var validator2 = this.attributes[key];
      if (validator2) {
        validatorErr = validator2.call(this, instance, schema, options, ctx);
      } else if (options.allowUnknownAttributes === false) {
        throw new SchemaError2("Unsupported attribute: " + key, schema);
      }
      if (validatorErr) {
        result.importErrors(validatorErr);
      }
    }
  }
  if (typeof options.rewrite == "function") {
    var value = options.rewrite.call(this, instance, schema, options, ctx);
    result.instance = value;
  }
  return result;
};
Validator$1.prototype.schemaTraverser = function schemaTraverser(schemaobj, s) {
  schemaobj.schema = helpers.deepMerge(schemaobj.schema, this.superResolve(s, schemaobj.ctx));
};
Validator$1.prototype.superResolve = function superResolve(schema, ctx) {
  var ref = shouldResolve(schema);
  if (ref) {
    return this.resolve(schema, ref, ctx).subschema;
  }
  return schema;
};
Validator$1.prototype.resolve = function resolve2(schema, switchSchema, ctx) {
  switchSchema = ctx.resolve(switchSchema);
  if (ctx.schemas[switchSchema]) {
    return { subschema: ctx.schemas[switchSchema], switchSchema };
  }
  var parsed = urilib.parse(switchSchema);
  var fragment = parsed && parsed.hash;
  var document = fragment && fragment.length && switchSchema.substr(0, switchSchema.length - fragment.length);
  if (!document || !ctx.schemas[document]) {
    throw new SchemaError2("no such schema <" + switchSchema + ">", schema);
  }
  var subschema = helpers.objectGetPath(ctx.schemas[document], fragment.substr(1));
  if (subschema === void 0) {
    throw new SchemaError2("no such schema " + fragment + " located in <" + document + ">", schema);
  }
  return { subschema, switchSchema };
};
Validator$1.prototype.testType = function validateType2(instance, schema, options, ctx, type) {
  if (type === void 0) {
    return;
  } else if (type === null) {
    throw new SchemaError2('Unexpected null in "type" keyword');
  }
  if (typeof this.types[type] == "function") {
    return this.types[type].call(this, instance);
  }
  if (type && typeof type == "object") {
    var res = this.validateSchema(instance, type, options, ctx);
    return res === void 0 || !(res && res.errors.length);
  }
  return true;
};
var types = Validator$1.prototype.types = {};
types.string = function testString(instance) {
  return typeof instance == "string";
};
types.number = function testNumber(instance) {
  return typeof instance == "number" && isFinite(instance);
};
types.integer = function testInteger(instance) {
  return typeof instance == "number" && instance % 1 === 0;
};
types.boolean = function testBoolean(instance) {
  return typeof instance == "boolean";
};
types.array = function testArray(instance) {
  return Array.isArray(instance);
};
types["null"] = function testNull(instance) {
  return instance === null;
};
types.date = function testDate(instance) {
  return instance instanceof Date;
};
types.any = function testAny(instance) {
  return true;
};
types.object = function testObject(instance) {
  return instance && typeof instance === "object" && !Array.isArray(instance) && !(instance instanceof Date);
};
var validator = Validator$1;
var Validator2 = validator;
helpers$3.ValidatorResult;
helpers$3.ValidatorResultError;
helpers$3.ValidationError;
helpers$3.SchemaError;
var validate$1 = function(instance, schema, options) {
  var v = new Validator2();
  return v.validate(instance, schema, options);
};
const cachedSchema = {};
async function validate2(config, version) {
  let result = {};
  if (config) {
    version = version || config.version || "1.1.1";
  }
  try {
    let schema = cachedSchema[version];
    if (!schema) {
      const response = await fetch(`/schemas/${version}/config.schema.json`);
      schema = cachedSchema[version] = await response.json();
    }
    const validateResult = validate$1(config, schema);
    result.errors = validateResult.errors;
  } catch (e) {
    result.errors = [e];
  }
  result.status = result.errors.length <= 0;
  return result;
}
function migrate$2(config) {
  const options = config.options;
  migrateRibbon(options);
  migrateBadge(options);
  config.projects = config.projects || [];
  config.projects.forEach((project) => project.envs = project.envs || []);
  if (config.envs) {
    config.envs.forEach((env, idx) => {
      migrateId(env, idx);
      migrateRibbon(env);
      migrateBadge(env);
      migrateEnvProject(config, env);
    });
  }
  migrateProjectId(config.projects);
  config.version = "1.1.0";
}
function migrateRibbon(obj) {
  if (obj && obj.ribbon !== void 0) {
    obj.displayRibbon = !!obj.ribbon;
    if (typeof obj.ribbon === "object") {
      obj.ribbonOptions = obj.ribbon;
    }
    delete obj.ribbon;
    return true;
  }
  return false;
}
function migrateBadge(obj) {
  if (obj && obj.badge !== void 0) {
    obj.displayBadge = !!obj.badge;
    if (typeof obj.badge === "object") {
      obj.badgeOptions = obj.badge;
    }
    delete obj.badge;
  }
}
function migrateId(env, idx) {
  if (env.id == null) {
    env.id = idx;
  }
}
function migrateEnvProject(config, env) {
  const projects = config.projects;
  const defaultProject = projects.find((project) => project.name === "Default Project") || {
    name: "Default Project",
    envs: []
  };
  if (env.project != null) {
    const project = projects.find(
      (project2) => project2.id === env.project || project2.name === env.project
    );
    if (project) {
      project.envs.push(env.id);
    } else {
      const newProject2 = { name: env.project, envs: [] };
      newProject2.envs.push(env.id);
      projects.push(newProject2);
    }
    delete env.project;
  } else {
    defaultProject.envs.push(env.id);
  }
  if (defaultProject.envs.length === 1) {
    projects.push(defaultProject);
  }
  config.projects = projects;
}
function migrateProjectId(projects) {
  projects.forEach((project, idx) => {
    project.name = project.name || project.id;
    project.id = idx;
  });
}
function migrate$1(config, version) {
  switch (version) {
    case "1.1.0":
      return migrate$2(config);
  }
}
async function migrateVersion(config, fromVersion, toVersion) {
  const beforeValidation = await validate2(config, fromVersion);
  if (!beforeValidation.status) {
    console.error(beforeValidation.errors);
    return false;
  }
  try {
    migrate$1(config, toVersion);
  } catch (e) {
    console.error(e);
    return false;
  }
  const afterValidation = await validate2(config, toVersion);
  if (!afterValidation.status) {
    console.error(afterValidation.errors);
    return false;
  }
  config.version = toVersion;
  return true;
}
const ConfigUpdateStatus = {
  MIGRATION_FAILED: 0,
  MIGRATION_SUCCESS: 1,
  NO_MIGRATION: 3
};
async function checkUpdate(config) {
  const version = config.version || "1.0.0";
  switch (version) {
    case "1.0.0":
      if (!await migrateVersion(config, "1.0.0", "1.1.0")) {
        return ConfigUpdateStatus.MIGRATION_FAILED;
      }
    case "1.1.0":
      config.version = "1.1.1";
      break;
    default:
      return ConfigUpdateStatus.NO_MIGRATION;
  }
  return ConfigUpdateStatus.MIGRATION_SUCCESS;
}
function getNextProjectId() {
  return uuidv4();
}
function getNextEnvId() {
  return uuidv4();
}
function findIndex(objId) {
  return (array) => array.findIndex((o) => o.id === objId);
}
function newProject(config, data) {
  return {
    id: getNextProjectId(config.projects),
    envs: [],
    ...data
  };
}
function addProject(config, project) {
  return {
    ...config,
    projects: [...config.projects, project]
  };
}
function deleteProject(config, projectId) {
  const project = getProjectById(config, projectId);
  const envs = config.envs.filter((env) => project.envs.indexOf(env.id) < 0);
  const projects = updateArray(config.projects, findIndex(projectId), () => null);
  return {
    ...config,
    envs,
    projects
  };
}
function updateProject(config, project) {
  return {
    ...config,
    projects: updateArray(config.projects, findIndex(project.id), () => project)
  };
}
function newEnv(config, data) {
  return {
    ...data,
    id: getNextEnvId(config.envs)
  };
}
function addEnv(config, projectId, env) {
  const configEnvs = config.envs;
  const project = getProjectById(config, projectId);
  const projects = updateArray(config.projects, findIndex(projectId), () => ({
    ...project,
    envs: [...project.envs, env.id]
  }));
  const envs = [...configEnvs, env];
  return {
    ...config,
    projects,
    envs
  };
}
function deleteEnv(config, envId) {
  const envs = config.envs;
  const projects = config.projects;
  return {
    ...config,
    projects: projects.map((project) => ({
      ...project,
      envs: project.envs.filter((currentEnvId) => currentEnvId !== envId)
    })),
    envs: updateArray(envs, findIndex(envId), () => null)
  };
}
function updateEnv(config, env) {
  return {
    ...config,
    envs: updateArray(config.envs, findIndex(env.id), () => env)
  };
}
function getProjectEnvs(config, projectId) {
  const project = getProjectById(config, projectId);
  if (project.envs && project.envs.length > 0) {
    return project.envs.map((envId) => config.envs.find((env) => env.id === envId));
  }
  return [];
}
function getProjectById(config, projectId) {
  return config.projects.find((project) => project.id === projectId);
}
function getEnvById(config, envId) {
  return config.envs.find((env) => env.id === envId);
}
function mergeImportedConfig(importedConfig, config, mode) {
  let importConfigOptions = importedConfig.options;
  if (importConfigOptions) {
    mergeOptions(importedConfig, config, mode);
  }
  return importedConfig;
}
function mergeOptions(destConfig, currentConfig, mode) {
  destConfig.options = mergeGlobalOptions(destConfig.options, currentConfig.options, mode);
  mergeEnvOptions(destConfig, currentConfig, mode);
}
function mergeGlobalOptions(destConfigOptions, currentConfigOptions, mode) {
  if (mode === "merge") {
    return cjs(destConfigOptions, currentConfigOptions);
  } else if (mode === "keep") {
    return {
      ...currentConfigOptions
    };
  }
}
function mergeEnvOptions(destConfig, currentConfig, mode) {
  const envOptionsById = currentConfig.envs.reduce((acc, env) => {
    acc[env.id] = getOverridableOptions(env);
    return acc;
  }, {});
  destConfig.envs = destConfig.envs.map((env) => {
    const existingEnv = envOptionsById[env.id];
    if (existingEnv) {
      return {
        ...getEnvBaseOptions(env),
        ...mergeGlobalOptions(getOverridableOptions(env), envOptionsById[env.id], mode)
      };
    }
    return env;
  });
}
function getEnvBaseOptions(env) {
  return removeUndefined({
    id: env.id,
    shortName: env.shortName,
    name: env.name,
    url: env.url,
    appendUrlParams: env.appendUrlParams,
    removeUrlParams: env.removeUrlParams
  });
}
function getOverridableOptions(env) {
  return removeUndefined({
    displayRibbon: env.displayRibbon,
    ribbonOptions: env.ribbonOptions,
    displayBadge: env.displayBadge,
    badgeOptions: env.badgeOptions,
    displayDomain: env.displayDomain,
    pingUrl: env.pingUrl
  });
}
async function migrateConfig(config) {
  let errors = null;
  let updatingConfig = cjs({}, config);
  const updateStatus = await checkUpdate(updatingConfig);
  if (updateStatus === ConfigUpdateStatus.MIGRATION_SUCCESS) {
    config = updatingConfig;
    await setConfig(config);
  }
  if (updateStatus === ConfigUpdateStatus.MIGRATION_FAILED) {
    errors = errors || {};
    errors.migrationFailed = true;
  }
  if (!errors) {
    const validation = await validate2(config);
    if (validation.status === false) {
      errors = errors || {};
      errors.validationFailed = true;
      errors.validationErrors = validation.errors;
    }
  }
  return {
    config,
    errors
  };
}
async function migrate() {
  let values = await storageGet(null);
  if (values != null && values.version != null) {
    let config = await getAndAssembleConfig(values);
    config.envs = await removeUnrefEnvs(config);
    return migrateConfig(config);
  } else {
    const config = { ...INIT_DEFAULT_CONFIG };
    await setConfig(config);
    return {
      config
    };
  }
}
async function getFixConfig({ mergeOptions: mergeOptions2, mergeDefault } = { mergeOptions: true, mergeDefault: true }) {
  let errors = {};
  let values = await storageGet(null);
  let config = await getAndAssembleConfig(values);
  config.envs = await removeUnrefEnvs(config);
  if (config != null) {
    if (mergeDefault) {
      config = mergeOptionsDefault(config);
    }
    if (mergeOptions2) {
      config = mergeOptionsInEnv(config);
    }
  } else {
    config = { ...INIT_DEFAULT_CONFIG };
    await setConfig(config);
  }
  return {
    config,
    errors
  };
}
async function removeUnrefEnvs(config) {
  const envIdsUsed = config.projects.reduce((acc, project) => {
    project.envs.forEach((envId) => {
      acc[envId] = true;
    });
    return acc;
  }, {});
  const unusedEnvIds = config.envs.filter(({ id }) => !envIdsUsed[id]).map((env) => env.id);
  const usedEnvs = config.envs.filter(({ id }) => envIdsUsed[id]);
  if (unusedEnvIds.length > 0) {
    await deleteEnvs(config, unusedEnvIds);
  }
  return usedEnvs;
}
async function isValid(config) {
  const result = await validate2(config);
  if (!result.status) {
    console.log(result.errors);
  }
  return result.status;
}
async function setConfig(config) {
  if (await isValid(config)) {
    const envsById = config.envs.reduce((acc, env) => {
      acc[`env-${env.id}`] = JSON.stringify(env);
      return acc;
    }, {});
    await storageSet({
      version: config.version,
      options: JSON.stringify(config.options),
      projects: JSON.stringify(config.projects),
      ...envsById
    });
    return true;
  }
  return false;
}
async function deleteEnvs(config, envs) {
  if ((await validate2(config)).status) {
    if (!Array.isArray(envs)) {
      envs = [envs];
    }
    const envsKey = envs.map((envId) => `env-${envId}`);
    await storageRemove(envsKey);
    return true;
  }
  return false;
}
async function importConfig(data) {
  let originalConfig;
  try {
    originalConfig = JSON.parse(data);
  } catch (e) {
    return null;
  }
  try {
    const { errors, config } = await migrateConfig(originalConfig);
    if (!errors) {
      return config;
    }
    console.error(JSON.stringify(errors, null, 4));
  } catch (e) {
    console.error(e);
  }
  return null;
}
async function importFromUrl(url2) {
  try {
    const response = await fetch(url2);
    if (response) {
      const data = await response.text();
      return await importConfig(data);
    }
    return null;
  } catch (e) {
    if (e.message !== "Failed to fetch") {
      console.error(e);
    }
    return null;
  }
}
async function autoUpdate(config) {
  const options = config.options;
  if (options) {
    const importOptions = options.import;
    if (importOptions && importOptions.sync && importOptions.url) {
      let importedConfig = await importFromUrl(importOptions.url);
      if (importedConfig) {
        const importedConfigUrl = importedConfig.options && importedConfig.options.import ? importedConfig.options.import.url : null;
        importedConfig = mergeImportedConfig(
          importedConfig,
          config,
          importOptions.mergeOptionsMode
        );
        if (importedConfig) {
          const importedConfigOptions = importedConfig.options = importedConfig.options || {};
          importedConfigOptions.import = {
            ...importOptions,
            url: importedConfigUrl || importOptions.url
          };
          await setConfig(importedConfig);
        }
      }
    }
  }
}
export {
  autoUpdate as a,
  mergeImportedConfig as b,
  importConfig as c,
  commonjsGlobal as d,
  getProjectEnvs as e,
  getProjectById as f,
  getDefaultExportFromCjs as g,
  addEnv as h,
  importFromUrl as i,
  getEnvById as j,
  deleteEnv as k,
  newProject as l,
  migrate as m,
  newEnv as n,
  addProject as o,
  deleteProject as p,
  updateProject as q,
  getFixConfig as r,
  setConfig as s,
  updateEnv as u
};
//# sourceMappingURL=index-c2ffbe1b.js.map
