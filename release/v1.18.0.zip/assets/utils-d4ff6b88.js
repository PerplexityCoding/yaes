function storageGet(values, type = "sync") {
  return new Promise((resolve) => {
    chrome.storage[type].get(values, (data) => {
      resolve(data);
    });
  });
}
function storageSet(data, type = "sync") {
  return new Promise((resolve) => {
    chrome.storage[type].set(data, () => {
      resolve(data);
    });
  });
}
function storageRemove(data, type = "sync") {
  return new Promise((resolve) => {
    chrome.storage[type].remove(data, () => {
      resolve();
    });
  });
}
const INIT_DEFAULT_CONFIG = {
  version: "1.1.1",
  projects: [],
  envs: [],
  options: {}
};
const DEFAULT_OPTIONS = {
  displayDomain: false,
  displayHeader: true,
  displayFooter: true,
  displaySeeProjectsLink: true,
  displayRibbon: false,
  displayBadge: true,
  badgeOptions: {
    backgroundColor: "#2677c9"
  },
  ribbonOptions: {
    type: "corner-ribbon",
    color: "white",
    backgroundColor: "#2677c9",
    position: "right"
  },
  colorScheme: "system",
  allowBugTrackerReporting: true,
  import: {
    sync: false,
    mergeOptionsMode: "default"
  },
  pingUrl: false,
  displayStyle: "list",
  switchEnvBetweenProjects: true
};
var isMergeableObject = function isMergeableObject2(value) {
  return isNonNullObject(value) && !isSpecial(value);
};
function isNonNullObject(value) {
  return !!value && typeof value === "object";
}
function isSpecial(value) {
  var stringValue = Object.prototype.toString.call(value);
  return stringValue === "[object RegExp]" || stringValue === "[object Date]" || isReactElement(value);
}
var canUseSymbol = typeof Symbol === "function" && Symbol.for;
var REACT_ELEMENT_TYPE = canUseSymbol ? Symbol.for("react.element") : 60103;
function isReactElement(value) {
  return value.$$typeof === REACT_ELEMENT_TYPE;
}
function emptyTarget(val) {
  return Array.isArray(val) ? [] : {};
}
function cloneUnlessOtherwiseSpecified(value, options) {
  return options.clone !== false && options.isMergeableObject(value) ? deepmerge(emptyTarget(value), value, options) : value;
}
function defaultArrayMerge(target, source, options) {
  return target.concat(source).map(function(element) {
    return cloneUnlessOtherwiseSpecified(element, options);
  });
}
function getMergeFunction(key, options) {
  if (!options.customMerge) {
    return deepmerge;
  }
  var customMerge = options.customMerge(key);
  return typeof customMerge === "function" ? customMerge : deepmerge;
}
function getEnumerableOwnPropertySymbols(target) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(target).filter(function(symbol) {
    return Object.propertyIsEnumerable.call(target, symbol);
  }) : [];
}
function getKeys(target) {
  return Object.keys(target).concat(getEnumerableOwnPropertySymbols(target));
}
function propertyIsOnObject(object, property) {
  try {
    return property in object;
  } catch (_) {
    return false;
  }
}
function propertyIsUnsafe(target, key) {
  return propertyIsOnObject(target, key) && !(Object.hasOwnProperty.call(target, key) && Object.propertyIsEnumerable.call(target, key));
}
function mergeObject(target, source, options) {
  var destination = {};
  if (options.isMergeableObject(target)) {
    getKeys(target).forEach(function(key) {
      destination[key] = cloneUnlessOtherwiseSpecified(target[key], options);
    });
  }
  getKeys(source).forEach(function(key) {
    if (propertyIsUnsafe(target, key)) {
      return;
    }
    if (propertyIsOnObject(target, key) && options.isMergeableObject(source[key])) {
      destination[key] = getMergeFunction(key, options)(target[key], source[key], options);
    } else {
      destination[key] = cloneUnlessOtherwiseSpecified(source[key], options);
    }
  });
  return destination;
}
function deepmerge(target, source, options) {
  options = options || {};
  options.arrayMerge = options.arrayMerge || defaultArrayMerge;
  options.isMergeableObject = options.isMergeableObject || isMergeableObject;
  options.cloneUnlessOtherwiseSpecified = cloneUnlessOtherwiseSpecified;
  var sourceIsArray = Array.isArray(source);
  var targetIsArray = Array.isArray(target);
  var sourceAndTargetTypesMatch = sourceIsArray === targetIsArray;
  if (!sourceAndTargetTypesMatch) {
    return cloneUnlessOtherwiseSpecified(source, options);
  } else if (sourceIsArray) {
    return options.arrayMerge(target, source, options);
  } else {
    return mergeObject(target, source, options);
  }
}
deepmerge.all = function deepmergeAll(array, options) {
  if (!Array.isArray(array)) {
    throw new Error("first argument should be an array");
  }
  return array.reduce(function(prev, next) {
    return deepmerge(prev, next, options);
  }, {});
};
var deepmerge_1 = deepmerge;
var cjs = deepmerge_1;
function mergeOptionsDefault(config) {
  config.options = cjs(cjs({}, DEFAULT_OPTIONS), config.options || {});
  return config;
}
async function getAndAssembleConfig(values) {
  try {
    const config = {
      options: values.options ? JSON.parse(values.options) : {},
      projects: values.projects ? JSON.parse(values.projects) : [],
      envs: await loadEnvs(values),
      version: values.version || INIT_DEFAULT_CONFIG.version
    };
    return config;
  } catch (e) {
    console.error(e);
    return null;
  }
}
async function loadEnvs(values) {
  return Object.entries(values).filter(([key]) => /^env-[0-9a-zA-Z-]*$/.exec(key)).reduce((acc, entry) => {
    acc.push(JSON.parse(entry[1]));
    return acc;
  }, []);
}
function mergeOptionsInEnv(config) {
  const envs = config.envs.map((env) => {
    return cjs(Object.assign({}, config.options), env);
  });
  return {
    ...config,
    envs
  };
}
export {
  DEFAULT_OPTIONS as D,
  INIT_DEFAULT_CONFIG as I,
  storageSet as a,
  storageRemove as b,
  cjs as c,
  mergeOptionsInEnv as d,
  getAndAssembleConfig as g,
  mergeOptionsDefault as m,
  storageGet as s
};
//# sourceMappingURL=utils-d4ff6b88.js.map
