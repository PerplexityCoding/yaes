import { d as defineComponent, Q as ArrowRightIcon, f as ref, _ as _export_sfc, c as createElementBlock, i as createBaseVNode, q as createTextVNode, K as toDisplayString, b as createCommentVNode, a as createBlock, n as normalizeClass, L as withModifiers, o as openBlock, j as resolveComponent, M as Fragment, N as renderList, k as createVNode, g as computed, P as isDarkMode, s as pushScopeId, t as popScopeId, R as loadSentry, S as createApp, U as queueVueGlobalErrorHandler } from "./ArrowRightIcon-ac76a36d.js";
import { i as isValidEnv, h as hostnameFromEnv, e as equalsEnv, s as switchBaseUrl, g as getConfig, a as getCurrentEnv } from "./index-bd0333f7.js";
import { c as arrayValidator } from "./utils-7f9e60bc.js";
import { o as openOptionsPage, a as openChromeUrl, b as getCurrentTab } from "./tabs-05aa9e80.js";
import "./utils-d4ff6b88.js";
const Env_vue_vue_type_style_index_0_scoped_3cbde944_lang = "";
function usePingUrl(url, isStatusError) {
  window.requestIdleCallback(() => {
    setTimeout(() => {
      fetch(url).then((res) => {
        isStatusError.value = res.status !== 200;
      }).catch(() => {
        isStatusError.value = true;
      });
    }, 500);
  });
}
const _sfc_main$4 = defineComponent({
  name: "Env",
  props: {
    env: {
      type: Object,
      required: true,
      validator: isValidEnv
    },
    isSelected: {
      type: Boolean,
      default: false
    }
  },
  components: { ArrowRightIcon },
  emits: ["switch-env"],
  setup(props, context) {
    const switchEnv = (env, newTab) => {
      context.emit("switch-env", { env, newTab });
    };
    const isStatusError = ref(null);
    if (props.env.pingUrl) {
      usePingUrl(props.env.url, isStatusError);
    }
    const shortName = (props.env.shortName || props.env.name).substring(0, 4);
    return {
      hostname: hostnameFromEnv,
      envName: props.env.displayStyle === "grid" ? shortName : props.env.name || shortName,
      switchEnv,
      isStatusError
    };
  }
});
const _hoisted_1$4 = { class: "env-name" };
const _hoisted_2$2 = {
  key: 0,
  class: "domain"
};
const _hoisted_3$2 = {
  key: 0,
  class: "selected-pill"
};
function _sfc_render$4(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_ArrowRightIcon = resolveComponent("ArrowRightIcon");
  return openBlock(), createElementBlock("button", {
    class: normalizeClass(["list-button env-button", {
      selected: _ctx.isSelected,
      "ping-ko": _ctx.isStatusError === true,
      "ping-ok": _ctx.isStatusError === false
    }]),
    onMouseup: _cache[0] || (_cache[0] = withModifiers(($event) => _ctx.switchEnv(_ctx.env, true), ["middle", "exact"])),
    onClick: [
      _cache[1] || (_cache[1] = withModifiers(($event) => _ctx.switchEnv(_ctx.env, true), ["ctrl", "exact"])),
      _cache[2] || (_cache[2] = withModifiers(($event) => _ctx.switchEnv(_ctx.env), ["exact"]))
    ]
  }, [
    createBaseVNode("span", _hoisted_1$4, [
      createTextVNode(toDisplayString(_ctx.envName) + " ", 1),
      _ctx.env.displayDomain && _ctx.env.url ? (openBlock(), createElementBlock("div", _hoisted_2$2, toDisplayString(_ctx.hostname(_ctx.env)), 1)) : createCommentVNode("", true)
    ]),
    _ctx.isSelected || _ctx.isStatusError === true ? (openBlock(), createElementBlock("span", _hoisted_3$2)) : (openBlock(), createBlock(_component_ArrowRightIcon, {
      key: 1,
      height: "14px",
      width: "14px"
    }))
  ], 34);
}
const Env = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$4], ["__scopeId", "data-v-3cbde944"]]);
const EnvList_vue_vue_type_style_index_0_scoped_5804d1e8_lang = "";
const _sfc_main$3 = defineComponent({
  name: "EnvList",
  props: {
    envs: {
      type: Array,
      required: true
    },
    currentEnv: {
      type: Object,
      required: false,
      default: null,
      validator: isValidEnv
    }
  },
  components: { Env },
  emits: ["switch-env"],
  setup() {
    return {
      equalsEnv
    };
  }
});
const _hoisted_1$3 = { class: "env-list" };
function _sfc_render$3(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Env = resolveComponent("Env");
  return openBlock(), createElementBlock("ul", _hoisted_1$3, [
    (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.envs, (env) => {
      return openBlock(), createElementBlock("li", {
        key: env.url
      }, [
        createVNode(_component_Env, {
          env,
          "is-selected": _ctx.equalsEnv(env, _ctx.currentEnv),
          onSwitchEnv: _cache[0] || (_cache[0] = (data) => _ctx.$emit("switch-env", data))
        }, null, 8, ["env", "is-selected"])
      ]);
    }), 128))
  ]);
}
const EnvList = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$3], ["__scopeId", "data-v-5804d1e8"]]);
function mapProjectEnvs(project, envs) {
  return project.envs.map((envId) => envs.find((env) => env.id === envId));
}
function findProjectByEnvId(projects, envId) {
  return projects.find((project) => project.envs.indexOf(envId) >= 0);
}
function isValidProject(project) {
  return project && project.name != null || project.id != null;
}
const Project_vue_vue_type_style_index_0_scoped_e3fe8d4f_lang = "";
const _sfc_main$2 = defineComponent({
  name: "Project",
  components: { EnvList, ArrowRightIcon },
  emits: ["redirect-env", "update:openProjectId"],
  props: {
    envs: {
      type: Array,
      required: true,
      validator: arrayValidator(isValidEnv)
    },
    project: {
      type: Object,
      required: true,
      validator: isValidProject
    },
    openProjectId: {
      type: [Number, String],
      required: true
    }
  },
  setup(props, { emit }) {
    const isOpened = (projectId) => props.openProjectId === projectId;
    const toggleAccordeon = (projectId) => {
      emit("update:openProjectId", isOpened(projectId) ? -1 : projectId);
    };
    const projectEnvsCache = {};
    return {
      isOpened: computed(() => isOpened(props.project.id)),
      toggleAccordeon,
      projectEnvs: (project) => {
        if (projectEnvsCache[project.id] === void 0) {
          projectEnvsCache[project.id] = mapProjectEnvs(project, props.envs);
        }
        return projectEnvsCache[project.id];
      }
    };
  }
});
const _hoisted_1$2 = { class: "project-btn-wrapper" };
const _hoisted_2$1 = {
  key: 0,
  class: "project-envs"
};
const _hoisted_3$1 = {
  key: 1,
  class: "info"
};
function _sfc_render$2(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_ArrowRightIcon = resolveComponent("ArrowRightIcon");
  const _component_EnvList = resolveComponent("EnvList");
  return openBlock(), createElementBlock("div", _hoisted_1$2, [
    createBaseVNode("button", {
      onClick: _cache[0] || (_cache[0] = ($event) => _ctx.toggleAccordeon(_ctx.project.id)),
      class: normalizeClass(["list-button", { "is-opened": _ctx.isOpened }])
    }, [
      createBaseVNode("span", null, toDisplayString(_ctx.project.name || _ctx.project.id), 1),
      createVNode(_component_ArrowRightIcon, {
        height: "14px",
        width: "14px"
      })
    ], 2),
    _ctx.isOpened ? (openBlock(), createElementBlock("div", _hoisted_2$1, [
      _ctx.projectEnvs(_ctx.project).length ? (openBlock(), createBlock(_component_EnvList, {
        key: 0,
        envs: _ctx.projectEnvs(_ctx.project),
        onSwitchEnv: _cache[1] || (_cache[1] = (data) => _ctx.$emit("redirect-env", data))
      }, null, 8, ["envs"])) : (openBlock(), createElementBlock("div", _hoisted_3$1, "No environments has been configured for this project yet."))
    ])) : createCommentVNode("", true)
  ]);
}
const Project = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$2], ["__scopeId", "data-v-e3fe8d4f"]]);
const ProjectList_vue_vue_type_style_index_0_scoped_6ef0849c_lang = "";
const _sfc_main$1 = defineComponent({
  name: "ProjectList",
  components: { Project },
  emits: ["redirect-env", "update:openProjectId"],
  props: {
    projects: {
      type: Array,
      required: true,
      validator: arrayValidator(isValidProject)
    },
    envs: {
      type: Array,
      required: true,
      validator: arrayValidator(isValidEnv)
    }
  },
  setup() {
    return {
      openProjectId: ref(-1)
    };
  }
});
const _hoisted_1$1 = { class: "project-list" };
function _sfc_render$1(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_Project = resolveComponent("Project");
  return openBlock(), createElementBlock("ul", _hoisted_1$1, [
    (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.projects, (project) => {
      return openBlock(), createElementBlock("li", {
        key: project.id
      }, [
        createVNode(_component_Project, {
          project,
          envs: _ctx.envs,
          "open-project-id": _ctx.openProjectId,
          "onUpdate:openProjectId": _cache[0] || (_cache[0] = ($event) => _ctx.openProjectId = $event),
          onRedirectEnv: _cache[1] || (_cache[1] = (data) => _ctx.$emit("redirect-env", data))
        }, null, 8, ["project", "envs", "open-project-id"])
      ]);
    }), 128))
  ]);
}
const ProjectList = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1], ["__scopeId", "data-v-6ef0849c"]]);
const _imports_0 = "/assets/images/favicon-16x16.png";
const Popup_vue_vue_type_style_index_0_lang = "";
const Popup_vue_vue_type_style_index_1_scoped_28541d82_lang = "";
function changeBaseUrlEnv(currentTab) {
  return async ({ env, newTab }, switchOption) => {
    const baseUrl = switchOption ? currentTab.value.url : env.url;
    const newUrl = switchBaseUrl(baseUrl, env.url, {
      appendUrlParams: env.appendUrlParams,
      removeUrlParams: env.removeUrlParams
    });
    openChromeUrl(currentTab.value, newUrl, newTab);
  };
}
async function useCurrentTab() {
  const currentTab = await getCurrentTab();
  return currentTab;
}
async function useConfig(currentTabUrl) {
  const { config } = await getConfig();
  const { envs, projects, options } = config;
  const currentEnv = getCurrentEnv(currentTabUrl, config);
  let currentEnvs = null;
  if (currentEnv) {
    const currentProject = findProjectByEnvId(projects, currentEnv.id);
    currentEnvs = mapProjectEnvs(currentProject, envs);
  } else {
    if (projects && projects.length === 1) {
      currentEnvs = mapProjectEnvs(projects[0], envs);
    }
  }
  return {
    currentEnv,
    currentEnvs,
    envs,
    projects,
    options: options || {}
  };
}
async function useAsyncSetup(config, currentTab, mode, loaded) {
  currentTab.value = await useCurrentTab();
  const localConfig = await useConfig(currentTab.value.url);
  Object.assign(config, localConfig);
  mode.value = config.currentEnv || config.currentEnvs && config.currentEnvs.length > 0 ? "envs" : config.projects && config.projects.length > 0 ? "projects" : "";
  loaded.value = true;
}
const _sfc_main = defineComponent({
  name: "Popup",
  components: { EnvList, ProjectList, ArrowRightIcon },
  setup() {
    const loaded = ref(false);
    const mode = ref("");
    const config = {};
    const currentTab = {};
    useAsyncSetup(config, currentTab, mode, loaded);
    return {
      darkMode: computed(() => isDarkMode(config.options.colorScheme)),
      openOptionsPage,
      changeBaseUrlEnv: changeBaseUrlEnv(currentTab),
      changeMode: (newMode) => mode.value = newMode,
      loaded,
      config,
      mode
    };
  }
});
const _withScopeId = (n) => (pushScopeId("data-v-28541d82"), n = n(), popScopeId(), n);
const _hoisted_1 = {
  key: 0,
  class: "header"
};
const _hoisted_2 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("img", { src: _imports_0 }, null, -1));
const _hoisted_3 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("span", null, " Yet Another Env Switcher ", -1));
const _hoisted_4 = [
  _hoisted_2,
  _hoisted_3
];
const _hoisted_5 = { class: "body" };
const _hoisted_6 = { key: 0 };
const _hoisted_7 = { key: 0 };
const _hoisted_8 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("span", null, "See projects", -1));
const _hoisted_9 = { key: 1 };
const _hoisted_10 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("span", null, "See current env", -1));
const _hoisted_11 = {
  key: 2,
  class: "info"
};
const _hoisted_12 = {
  key: 1,
  class: "footer"
};
const _hoisted_13 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("a", {
  href: "https://github.com/ymenard-dev/yaes",
  target: "_blank"
}, " Homepage ", -1));
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_EnvList = resolveComponent("EnvList");
  const _component_ArrowRightIcon = resolveComponent("ArrowRightIcon");
  const _component_ProjectList = resolveComponent("ProjectList");
  return _ctx.loaded ? (openBlock(), createElementBlock("section", {
    key: 0,
    class: normalizeClass(["popin", { "dark-mode": _ctx.darkMode, "style-grid": _ctx.config.options.displayStyle === "grid" }])
  }, [
    _ctx.config.options.displayHeader !== false ? (openBlock(), createElementBlock("header", _hoisted_1, _hoisted_4)) : createCommentVNode("", true),
    createBaseVNode("section", _hoisted_5, [
      _ctx.mode === "envs" ? (openBlock(), createElementBlock("div", _hoisted_6, [
        _ctx.config.currentEnvs && _ctx.config.currentEnvs.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_7, [
          createVNode(_component_EnvList, {
            envs: _ctx.config.currentEnvs,
            "current-env": _ctx.config.currentEnv,
            onSwitchEnv: _cache[0] || (_cache[0] = (o) => _ctx.changeBaseUrlEnv(o, !!_ctx.config.currentEnv))
          }, null, 8, ["envs", "current-env"]),
          _ctx.config.projects && _ctx.config.projects.length > 1 && _ctx.config.options.displaySeeProjectsLink !== false ? (openBlock(), createElementBlock("button", {
            key: 0,
            class: "switch-env-btn right",
            onClick: _cache[1] || (_cache[1] = ($event) => _ctx.changeMode("projects"))
          }, [
            _hoisted_8,
            createVNode(_component_ArrowRightIcon, {
              class: "arrow",
              height: "12px",
              width: "12px"
            })
          ])) : createCommentVNode("", true)
        ])) : createCommentVNode("", true)
      ])) : _ctx.mode === "projects" ? (openBlock(), createElementBlock("div", _hoisted_9, [
        createVNode(_component_ProjectList, {
          projects: _ctx.config.projects,
          envs: _ctx.config.envs,
          onRedirectEnv: _cache[2] || (_cache[2] = (o) => _ctx.changeBaseUrlEnv(o, !!_ctx.config.currentEnv && _ctx.config.options.switchEnvBetweenProjects))
        }, null, 8, ["projects", "envs"]),
        _ctx.config.currentEnv ? (openBlock(), createElementBlock("button", {
          key: 0,
          class: "switch-env-btn",
          onClick: _cache[3] || (_cache[3] = ($event) => _ctx.changeMode("envs"))
        }, [
          createVNode(_component_ArrowRightIcon, {
            class: "arrow",
            height: "12px",
            width: "12px"
          }),
          _hoisted_10
        ])) : createCommentVNode("", true)
      ])) : (openBlock(), createElementBlock("div", _hoisted_11, " No environments has been configured yet. Click on edit configuration link. "))
    ]),
    _ctx.config.options.displayFooter !== false ? (openBlock(), createElementBlock("footer", _hoisted_12, [
      createBaseVNode("a", {
        href: "#/options",
        onClick: _cache[4] || (_cache[4] = (...args) => _ctx.openOptionsPage && _ctx.openOptionsPage(...args))
      }, " Edit Configuration "),
      _hoisted_13
    ])) : createCommentVNode("", true)
  ], 2)) : createCommentVNode("", true);
}
const Popup = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-28541d82"]]);
async function main() {
  if (!window.Cypress) {
    loadSentry();
  }
  const startApp = () => {
    const app = createApp(Popup);
    queueVueGlobalErrorHandler(app);
    app.mount("#app");
  };
  if (window.Cypress) {
    window.startApp = startApp;
  } else {
    startApp();
  }
}
main();
//# sourceMappingURL=popup.html-21a4672c.js.map
