window.ENV = {
  WITHOUT_RIBBON: true,
};
