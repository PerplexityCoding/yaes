(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else if(typeof exports === 'object')
		exports["content-script"] = factory();
	else
		root["content-script"] = factory();
})((typeof self !== 'undefined' ? self : this), function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__("8f7e");
module.exports = __webpack_require__("fae3");


/***/ }),

/***/ "3c4e":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var isMergeableObject = function isMergeableObject(value) {
	return isNonNullObject(value)
		&& !isSpecial(value)
};

function isNonNullObject(value) {
	return !!value && typeof value === 'object'
}

function isSpecial(value) {
	var stringValue = Object.prototype.toString.call(value);

	return stringValue === '[object RegExp]'
		|| stringValue === '[object Date]'
		|| isReactElement(value)
}

// see https://github.com/facebook/react/blob/b5ac963fb791d1298e7f396236383bc955f916c1/src/isomorphic/classic/element/ReactElement.js#L21-L25
var canUseSymbol = typeof Symbol === 'function' && Symbol.for;
var REACT_ELEMENT_TYPE = canUseSymbol ? Symbol.for('react.element') : 0xeac7;

function isReactElement(value) {
	return value.$$typeof === REACT_ELEMENT_TYPE
}

function emptyTarget(val) {
	return Array.isArray(val) ? [] : {}
}

function cloneUnlessOtherwiseSpecified(value, options) {
	return (options.clone !== false && options.isMergeableObject(value))
		? deepmerge(emptyTarget(value), value, options)
		: value
}

function defaultArrayMerge(target, source, options) {
	return target.concat(source).map(function(element) {
		return cloneUnlessOtherwiseSpecified(element, options)
	})
}

function getMergeFunction(key, options) {
	if (!options.customMerge) {
		return deepmerge
	}
	var customMerge = options.customMerge(key);
	return typeof customMerge === 'function' ? customMerge : deepmerge
}

function getEnumerableOwnPropertySymbols(target) {
	return Object.getOwnPropertySymbols
		? Object.getOwnPropertySymbols(target).filter(function(symbol) {
			return target.propertyIsEnumerable(symbol)
		})
		: []
}

function getKeys(target) {
	return Object.keys(target).concat(getEnumerableOwnPropertySymbols(target))
}

function propertyIsOnObject(object, property) {
	try {
		return property in object
	} catch(_) {
		return false
	}
}

// Protects from prototype poisoning and unexpected merging up the prototype chain.
function propertyIsUnsafe(target, key) {
	return propertyIsOnObject(target, key) // Properties are safe to merge if they don't exist in the target yet,
		&& !(Object.hasOwnProperty.call(target, key) // unsafe if they exist up the prototype chain,
			&& Object.propertyIsEnumerable.call(target, key)) // and also unsafe if they're nonenumerable.
}

function mergeObject(target, source, options) {
	var destination = {};
	if (options.isMergeableObject(target)) {
		getKeys(target).forEach(function(key) {
			destination[key] = cloneUnlessOtherwiseSpecified(target[key], options);
		});
	}
	getKeys(source).forEach(function(key) {
		if (propertyIsUnsafe(target, key)) {
			return
		}

		if (propertyIsOnObject(target, key) && options.isMergeableObject(source[key])) {
			destination[key] = getMergeFunction(key, options)(target[key], source[key], options);
		} else {
			destination[key] = cloneUnlessOtherwiseSpecified(source[key], options);
		}
	});
	return destination
}

function deepmerge(target, source, options) {
	options = options || {};
	options.arrayMerge = options.arrayMerge || defaultArrayMerge;
	options.isMergeableObject = options.isMergeableObject || isMergeableObject;
	// cloneUnlessOtherwiseSpecified is added to `options` so that custom arrayMerge()
	// implementations can use it. The caller may not replace it.
	options.cloneUnlessOtherwiseSpecified = cloneUnlessOtherwiseSpecified;

	var sourceIsArray = Array.isArray(source);
	var targetIsArray = Array.isArray(target);
	var sourceAndTargetTypesMatch = sourceIsArray === targetIsArray;

	if (!sourceAndTargetTypesMatch) {
		return cloneUnlessOtherwiseSpecified(source, options)
	} else if (sourceIsArray) {
		return options.arrayMerge(target, source, options)
	} else {
		return mergeObject(target, source, options)
	}
}

deepmerge.all = function deepmergeAll(array, options) {
	if (!Array.isArray(array)) {
		throw new Error('first argument should be an array')
	}

	return array.reduce(function(prev, next) {
		return deepmerge(prev, next, options)
	}, {})
};

var deepmerge_1 = deepmerge;

module.exports = deepmerge_1;


/***/ }),

/***/ "8f7e":
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {(typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {}).SENTRY_RELEASE={id:"yaes@1.15.2"};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("c8ba")))

/***/ }),

/***/ "c8ba":
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || new Function("return this")();
} catch (e) {
	// This works if the window reference is available
	if (typeof window === "object") g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ "fae3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/@vue/cli-service/lib/commands/build/setPublicPath.js
// This file is imported into lib/wc client bundles.

if (typeof window !== 'undefined') {
  var currentScript = window.document.currentScript
  if (false) { var getCurrentScript; }

  var src = currentScript && currentScript.src.match(/(.+\/)[^/]+\.js(\?.*)?$/)
  if (src) {
    __webpack_require__.p = src[1] // eslint-disable-line
  }
}

// Indicate to webpack that this file can be concatenated
/* harmony default export */ var setPublicPath = (null);

// CONCATENATED MODULE: ./src/services/chrome/storage.js
function storageGet(values, type = "sync") {
  return new Promise(resolve => {
    window.chrome.storage[type].get(values, data => {
      // console.log(data);
      resolve(data);
    });
  });
}

function storageSet(data, type = "sync") {
  return new Promise(resolve => {
    window.chrome.storage[type].set(data, () => {
      // console.log("Value is set to ", data);
      resolve(data);
    });
  });
}

function storageRemove(data, type = "sync") {
  return new Promise(resolve => {
    window.chrome.storage[type].remove(data, () => {
      // console.log("Remove Value ", data);
      resolve();
    });
  });
}

function storageClear(data, type = "sync") {
  return new Promise(resolve => {
    window.chrome.storage[type].clear(() => {
      resolve();
    });
  });
}


// CONCATENATED MODULE: ./src/services/business/storage/defaults.js
const INIT_DEFAULT_CONFIG = {
  version: "1.1.1",
  projects: [],
  envs: [],
  options: {}
};
const DEFAULT_OPTIONS = {
  displayDomain: false,
  displayHeader: true,
  displayFooter: true,
  displaySeeProjectsLink: true,
  displayRibbon: true,
  displayBadge: true,
  badgeOptions: {
    backgroundColor: "#2677c9"
  },
  ribbonOptions: {
    type: "corner-ribbon",
    color: "white",
    backgroundColor: "#2677c9",
    position: "right"
  },
  colorScheme: "system",
  allowBugTrackerReporting: true,
  import: {
    sync: false,
    mergeOptionsMode: "default"
  },
  pingUrl: false
};
// EXTERNAL MODULE: ./node_modules/deepmerge/dist/cjs.js
var cjs = __webpack_require__("3c4e");
var cjs_default = /*#__PURE__*/__webpack_require__.n(cjs);

// CONCATENATED MODULE: ./src/services/business/storage/utils.js


function mergeOptionsDefault(config) {
  config.options = cjs_default()(cjs_default()({}, DEFAULT_OPTIONS), config.options || {});
  return config;
}
async function getAndAssembleConfig(values) {
  try {
    const config = {
      options: values.options ? JSON.parse(values.options) : {},
      projects: values.projects ? JSON.parse(values.projects) : [],
      envs: await loadEnvs(values),
      version: values.version || INIT_DEFAULT_CONFIG.version
    };
    return config;
  } catch (e) {
    console.error(e);
    return null;
  }
}

async function loadEnvs(values) {
  return Object.entries(values).filter(([key]) => /^env-[0-9a-zA-Z-]*$/.exec(key)).reduce((acc, entry) => {
    acc.push(JSON.parse(entry[1]));
    return acc;
  }, []);
}

function mergeOptionsInEnv(config) {
  const envs = config.envs.map(env => {
    return cjs_default()(Object.assign({}, config.options), env);
  });
  return { ...config,
    envs
  };
}
// CONCATENATED MODULE: ./src/services/business/storage/get.js



async function getConfig({
  mergeOptions,
  mergeDefault
} = {
  mergeOptions: true,
  mergeDefault: true
}) {
  let errors = {};
  let values = await storageGet(null);
  let config = await getAndAssembleConfig(values);

  if (config != null) {
    if (mergeDefault) {
      config = mergeOptionsDefault(config);
    }

    if (mergeOptions) {
      config = mergeOptionsInEnv(config);
    }
  } else {
    config = { ...INIT_DEFAULT_CONFIG
    };
  }

  return {
    config,
    errors
  };
}
// CONCATENATED MODULE: ./src/services/business/bo/env.js
function equalsEnv(env1, env2) {
  if (!env1 || !env2) {
    return false;
  }

  return env1.id === env2.id;
}
function hostnameFromEnv(env) {
  return new URL(env.url).hostname;
}
function isValidEnv(env) {
  return env && (env.name != null || env.shortName != null) && env.id != null;
}
// CONCATENATED MODULE: ./src/services/business/url/index.js

function switchBaseUrl(currentUrl, newBaseUrl, {
  appendUrlParams,
  removeUrlParams
}) {
  const baseUrl = new URL(newBaseUrl);
  const url = new URL(currentUrl);
  url.hostname = baseUrl.hostname;
  url.protocol = baseUrl.protocol;
  const searchParams = url.searchParams;

  if (appendUrlParams) {
    const newSearchParams = new URLSearchParams(appendUrlParams);
    newSearchParams.forEach(function (value, key) {
      searchParams.set(key, value);
    });
  }

  if (removeUrlParams) {
    const removeUrlParamsList = removeUrlParams.split(",");
    removeUrlParamsList.forEach(key => {
      searchParams.delete(key.trim());
    });
  }

  return url.href;
}
function getCurrentEnv(url, config) {
  if (!config) {
    return;
  }

  if (url == null || !url.match(/^https?:\/\//)) {
    return null;
  }

  const envsByDomains = getEnvsByDomain(config);
  const currentUrl = new URL(url);
  const currentHostname = currentUrl.hostname;
  const currentSearchParams = currentUrl.searchParams;

  for (const [domain, domainEnvs] of Object.entries(envsByDomains)) {
    if (domain === currentHostname) {
      let mostMatchingEnv = {
        env: null,
        count: -100
      };

      for (const env of domainEnvs) {
        let count = 0;

        if (env.appendUrlParams) {
          const params = new URLSearchParams(env.appendUrlParams);

          for (const [key, value] of params) {
            if (currentSearchParams.get(key) === value) {
              count += 100;
            }

            count--;
          }
        }

        if (count > mostMatchingEnv.count) {
          mostMatchingEnv = {
            env,
            count
          };
        }
      }

      return mostMatchingEnv.env;
    }
  }

  return null;
}

function getEnvsByDomain(config) {
  const envs = config.envs;
  return envs.reduce((result, env) => {
    const envHostname = hostnameFromEnv(env);
    result[envHostname] = result[envHostname] || [];
    result[envHostname].push(env);
    return result;
  }, {});
}
// CONCATENATED MODULE: ./src/components/Ribbon.js
const ribbonCss = `
  .corner-ribbon {
    width: 225px;
    color: #fff;
    position: fixed;
    text-align: center;
    top: 45px;
    line-height: 40px;
    z-index: 99999;
    font-size: 18px;
    box-shadow: 0px 1px 4px #a9a9a9;
    cursor: alias;
  }

  .corner-ribbon.left {
    left: -53px;
    -ms-transform: rotate(-45deg);
    -webkit-transform: rotate(-45deg);
    transform: rotate(-45deg);
  }

  .corner-ribbon.right {
    right: -53px;
    left: auto;
    -ms-transform: rotate(45deg);
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
  }

  .square-ribbon {
    color: #fff;
    position: fixed;
    text-align: center;
    top: 2px;
    z-index: 99999;
    font-size: 18px;
    box-shadow: 0px 2px 5px #2f2f2f;
    padding: 6px 12px;
    cursor: alias;
  }

  .square-ribbon.left {
    left: 2px;
  }

  .square-ribbon.right {
    right: 2px;
    left: auto;
  }
`;

const ribbonH = ({
  name,
  color,
  backgroundColor,
  position,
  type
}) => `
  <div
    class="${type} ${position}"
    style="background-color: ${backgroundColor}; color: ${color};"
  >
    ${name}
  </div>
`;

function renderRibbon(config, env) {
  injectRibbonStyle(ribbonCss);
  renderRibbonHtml(config, env);
}

function renderRibbonHtml(config, env) {
  const elem = document.createElement("div");
  elem.setAttribute("id", "ribbon");
  const ribbonOptions = env.ribbonOptions;
  const backgroundColor = ribbonOptions.backgroundColor;
  const position = ribbonOptions.position;
  const type = ribbonOptions.type;
  const color = ribbonOptions.color;
  elem.innerHTML = ribbonH({
    name: env.name || env.shortName,
    position,
    backgroundColor,
    type,
    color
  });
  elem.addEventListener("click", () => {
    elem.remove();
  });
  document.body.prepend(elem);
}

function injectRibbonStyle(css) {
  const style = document.createElement("style");
  document.head.appendChild(style);
  style.appendChild(document.createTextNode(css));
}

/* harmony default export */ var Ribbon = (renderRibbon);
// CONCATENATED MODULE: ./src/content-script.js




async function main() {
  await verifyCurrentUrl();
}

async function verifyCurrentUrl() {
  const {
    config
  } = await getConfig();
  const env = getCurrentEnv(window.location.href, config);

  if (env != null && env.displayRibbon !== false) {
    Ribbon(config, env);
  }
}

main();
// CONCATENATED MODULE: ./node_modules/@vue/cli-service/lib/commands/build/entry-lib-no-default.js




/***/ })

/******/ });
});
//# sourceMappingURL=content-script.umd.js.map